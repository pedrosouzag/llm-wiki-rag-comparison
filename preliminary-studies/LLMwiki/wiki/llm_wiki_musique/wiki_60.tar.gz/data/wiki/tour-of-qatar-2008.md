# Tour of Qatar 2008

- The 2008 Tour of Qatar was held from 27 January to 1 February 2008.
- The event took place in Qatar.
- It is a multiple stage road cycling race.
- The race took part over six stages.
- The total distance was 712.5 kilometres.
- It is part of the 2007–2008 UCI Asia Tour.