# Sicilian Pizza Characteristics

Sicilian pizza
- Sicilian pizza originated in Sicily, Italy.
- Sicilian pizza is also known as "sfincione" or focaccia with toppings.
- In the United States, "Sicilian pizza" is often synonymous with thick-crust pizza.
- This type of pizza became popular in western Sicily by the mid-19th century.
- It was the type of pizza usually consumed in Sicily until the 1860s.
- The version with tomatoes was not available prior to the 17th century.
- It reached North America in a slightly altered form.
- It has a thicker crust.
- It has a rectangular shape.
- Pizza Hut is an American restaurant chain.