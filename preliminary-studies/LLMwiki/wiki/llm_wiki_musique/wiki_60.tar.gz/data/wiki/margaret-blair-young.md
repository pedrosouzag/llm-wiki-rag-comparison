# Margaret Blair Young

Margaret Blair Young
- Margaret Blair Young was born in 1955.
- Margaret Blair Young is an American author.
- Margaret Blair Young is a filmmaker.
- Margaret Blair Young is a writing instructor.
- Margaret Blair Young taught for thirty years at Brigham Young University.
- Elizabeth Frances Ingram was an American operatic contralto.
- Elizabeth Frances Ingram was born on 5 November 1888.
- Elizabeth Frances Ingram died on 12 April 1974.
- Elizabeth Frances Ingram was of English birth.
- Elizabeth Frances Ingram had an active career in North America during the 1910s and 1920s.
- Ann Grifalconi was born on September 22, 1929.
- Ann Grifalconi is an American author.
- Ann Grifalconi is an American illustrator of children's books.
- Ann Grifalconi was born in New York.
- Ann Grifalconi studied art at the Cooper Union School of Art.
- Ann Grifalconi received a certificate in advertising art in 1950.
- Ann Grifalconi worked in advertising and display for several years.
- Ann Grifalconi taught art and design at the High School of Fashion Industries.
- Ann Grifalconi left to become a full-time illustrator and author.
- Theresa Schwegel was born on July 20, 1975.
- Theresa Schwegel is an American author of crime fiction.
- Theresa Schwegel won the Edgar Award for best first novel from the Mystery Writers of America for "Officer Down" in 2006.
- Theresa Schwegel received the Chicago Public Library Foundation's 21st Century Award for achievement in writing by an author with ties to Chicago in 2008.