# Joni Mitchell - Little Green

Little Green (song)
- "Little Green" is a song composed and performed by Joni Mitchell.
- It is the third track on her 1971 album "Blue".