# Amamoor Forest Reserve

- The Amamoor Forest Reserve is in the Gympie Region in Queensland, Australia.
- The forest is a riverine rainforest.
- The forest is composed of subtropical vegetation.
- The forest is dominated by stands of "Melia azedarach" (white cedar).
- The forest is dominated by stands of "Toona ciliata" (red cedar).
- The forest is dominated by stands of "Araucaria cunninghamii" (hoop pine).
- The forest is dominated by stands of "A. bidwillii" (Bunya pine).
- Amamoor creek within the reserve is a habitat for the platypus.
- Amamoor creek within the reserve is a habitat for several species of endangered frogs.
- The park station is located on Amamoor Creek Road.
- The park station is 180 kilometers north of Brisbane.
- The park station is 20 kilometers southwest of Gym