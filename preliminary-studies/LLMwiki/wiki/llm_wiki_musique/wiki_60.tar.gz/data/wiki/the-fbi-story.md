# The FBI Story

The FBI Story
- The FBI Story is a 1959 American drama film.
- The film stars James Stewart.
- The film was produced and directed by Mervyn LeRoy.
- The screenplay was written by Richard L. Breen and John Twist.
- The screenplay is based on a book by Don Whitehead.
- Elmer, the Great is a 1933 American pre-Code comedy film.
- The film is directed by Mervyn LeRoy.
- The film stars Joe E. Brown.
- The film stars Patricia Ellis.
- Father Brown, Detective is a 1934 American mystery film.
- The film is directed by Edward Sedgwick.
- The film stars Walter Connolly.
- The film stars Paul Lukas.
- The film stars Gertrude Michael.
- It is based on the Father Brown story "The Blue Cross" by G.K. Chesterton.
- A story which also informed the 1954 film "Father Brown" with Alec Guinness and Peter Finch.
- French Connection II is a 1975 action thriller film.
- French Connection II stars Gene Hackman.
- French Connection II is directed by John Frankenheimer.
- It is a fictional sequel to "The French Connection".
- The film expands on the central character of Det. Jimmy "Popeye" Doyle.
- Det. Jimmy "Popeye" Doyle travels to Marseille, France.
- He is attempting to track down Alain Charnier.
- Alain Charnier is a French drug-dealer.
- Hackman won an Academy Award for Best Actor for "The French Connection".
- Fernando Rey is a returning cast member.