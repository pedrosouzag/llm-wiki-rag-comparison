# Party for the Netherlands

Party for the Netherlands is a Dutch right-wing Fortuynist political party.
Party for the Netherlands (PVN) was founded in August 2006.
Party for the Netherlands was founded by Hilbrand Nawijn.
Hilbrand Nawijn is a member of the Dutch House of Representatives.