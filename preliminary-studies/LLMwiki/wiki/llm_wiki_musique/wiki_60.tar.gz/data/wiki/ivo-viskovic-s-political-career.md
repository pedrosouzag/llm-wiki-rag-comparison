# Ivo Visković's Political Career

Ivo Visković was a member of the Civic Alliance of Serbia (1990-1996)
Ivo Visković was a member of the Social Democratic Union from 1996 until 2001
Ivo Visković began his diplomatic career in 2001
Ivo Visković was a member of the European Movement in Serbia
Ivo Visković was chairman of the Forum on International Relations from 2006 to 2008