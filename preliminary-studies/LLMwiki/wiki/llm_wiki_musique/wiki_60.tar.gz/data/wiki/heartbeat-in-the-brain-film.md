# Heartbeat in the Brain Film

Heartbeat in the Brain
- It is a 1970 documentary film.
- It was produced and directed by Amanda Feilding.
- Amanda Feilding is an advocate of trepanation.
- Amanda Feilding was 27 years old at the time.
- She was a student at the time.
- She drilled a hole in her forehead with a dentist's drill.
- The film includes motion studies of Birdie, her pet pigeon.