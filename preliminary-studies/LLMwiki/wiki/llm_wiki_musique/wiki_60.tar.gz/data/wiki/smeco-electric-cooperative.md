# SMECO Electric Cooperative

Southern Maryland Electric Cooperative
- The Southern Maryland Electric Cooperative is an electric distribution cooperative.
- The Southern Maryland Electric Cooperative is headquartered in Hughesville, Maryland.
- SMECO serves approximately 161,000 customers.
- SMECO serves Calvert County.
- SMECO serves Charles County.
- SMECO serves Prince George's County.
- SMECO serves St. Mary's counties of southern Maryland.
- SMECO is a nonprofit cooperative.
- SMECO passes on its costs to its customer-members without markup or profit.
- Southern California Edison is a subsidiary of Edison International.
- Southern California Edison provides electricity to 14 million people.
- Southern California Edison’s service territory is approximately 50,000 square miles.
- The Los Angeles Department of Water and Power serves portions of southern California.
- San Diego Gas & Electric serves portions of southern California.
- Imperial Irrigation District serves portions of southern California.
- Pacific Gas & Electric Company of San Francisco serves the northern part of the state.
- Hughesville is a census-designated place (CDP) in Charles County, Maryland, United States.
- The population of Hughesville was 2,197 at the 2010 census.
- Truman's Place was listed on the National Register of Historic Places in 1988.