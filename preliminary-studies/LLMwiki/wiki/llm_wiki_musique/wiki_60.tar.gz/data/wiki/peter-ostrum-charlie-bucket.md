# Peter Ostrum, Charlie Bucket

Peter Gardner Ostrum
- Peter Gardner Ostrum was born in November 1957.
- Peter Gardner Ostrum is American.
- Peter Gardner Ostrum is a veterinarian.
- Peter Gardner Ostrum played Charlie Bucket in Willy Wonka & the Chocolate Factory.
- Peter Gardner Ostrum’s only film role was in the 1971 motion picture Willy Wonka & the Chocolate Factory.
- The pronunciation of Ostrum is /ˈoʊstrəm/.
- Peter Gardner Ostrum’s pronunciation is /ˈpiːtər ˈoʊstrəm /.
- Peter Gardner Ostrum is a former child actor.
- You Were There for Me is a collaboration studio album.
- You Were There for Me is a collaboration studio album of Peter Rowan and Tony Rice.
- The record marks their first full-fledged cooperation.
- Peter Rowan and Tony Rice had previously appeared on several albums together.