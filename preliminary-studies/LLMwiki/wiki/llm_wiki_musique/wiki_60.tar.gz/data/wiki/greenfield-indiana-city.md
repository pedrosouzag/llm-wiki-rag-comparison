# Greenfield, Indiana City

Greenfield, Indiana
- Greenfield is a city in Hancock County, Indiana.
- Greenfield is the county seat of Hancock County.
- Greenfield is part of the Indianapolis metropolitan area.
- The population was 20,602 at the 2010 census.
- The estimated population in 2016 was 21,709.
- Greenfield lies in Center Township.
- Mark Dismore was born in Greenfield, Indiana.
- Mark Dismore is a former driver in the Indy Racing League.
- Mark Dismore was the 1990 Toyota Pacific champion.
- Mark Dismore won the 1993 24 Hours of Daytona with Dan Gurney's All American Racers.
- Mark Dismore made 3 CART starts in 1991.
- Mark Dismore was badly injured in a practice crash for the Indianapolis 500.
- Mark Dismore suffered a broken neck in the crash.
- Mark Dismore drove for Team Menard in the 1996 Indy 500.