# Essex County Park Building

- The Essex County Park Commission Administration Building is located in Newark, Essex County, New Jersey, United States.
- The building was built in 1916.
- The building was added to the National Register of Historic Places on November 11, 1977.
- The James W. Clise House is a house located within Marymoor Park.
- The James W. Clise House is located in Redmond, Washington, United States.
- The James W. Clise House is listed on the National Register of Historic Places.
- The Mountrail County Courthouse was built in 1914.
- The Mountrail County Courthouse is located in Stanley, North Dakota.
- The Mountrail County Courthouse served Mountrail County as its courthouse continuously since 1914.
- The Mountrail County Courthouse was designed by architects Buechner & Orth.
- The Mountrail County Courthouse is an example of Academic Revival architecture.
- The Mountrail County Courthouse is an example of Late 19th and 20th Century Revivals architecture.
- The Mountrail County Courthouse was listed on the National Register of Historic Places in 1978.
- A area was included in the listing for the Mountrail County Courthouse.