# Kenny Dorham and Ernie Henry

2 Horns / 2 Rhythm
- It is an album by Kenny Dorham.
- Kenny Dorham is an American jazz trumpeter.
- The album features performances with Ernie Henry.
- The album was recorded in 1957.
- The album was released on the Riverside label.
- It was Ernie Henry's last recording session.
- This was Henry's last recording session.
- Jazz Contemporary is an album by American jazz trumpeter Kenny Dorham.
- The album featuring performances was recorded in 1960.
- The album was released on the Time label.
- The album features the recording debut of pianist Steve Kuhn.