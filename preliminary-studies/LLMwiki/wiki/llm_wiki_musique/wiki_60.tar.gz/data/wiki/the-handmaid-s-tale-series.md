# The Handmaid's Tale (series)

- The Handmaid's Tale is an American web television series.
- It was created by Bruce Miller.
- It is based on the 1985 novel by Margaret Atwood.
- It was ordered by Hulu.
- Hulu ordered 10 episodes.
- Production began in late 2016.
- The plot follows a dystopian future.
- A Second American Civil War occurred.
- Women are called ``Handmaids''.
- Handmaids are forced into sexual and child - bearing servitude.