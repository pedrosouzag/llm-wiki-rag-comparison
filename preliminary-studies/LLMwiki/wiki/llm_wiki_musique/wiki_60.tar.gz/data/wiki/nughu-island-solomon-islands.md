# Nughu Island, Solomon Islands

- Nughu is an island in the Solomon Islands
- Nughu is located in Guadalcanal Province
- The estimated terrain elevation above sea level is some 12 metres
- Bansaan is a boomerang-shaped island
- Bansaan is located off the mid-northern coast of Bohol Island
- Bansaan is part of the municipality of Talibon
- Bansaan is in the province of Bohol