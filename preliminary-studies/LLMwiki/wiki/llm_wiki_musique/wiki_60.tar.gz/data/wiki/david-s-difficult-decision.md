# David's difficult decision

The Memory Keeper's Daughter
- The story begins in early March of 1964.
- Dr. David Henry delivers his wife Norah's twins.
- Caroline Gill helps Dr. David Henry deliver the twins.
- Their first child is a boy named Paul.
- Paul is a healthy, perfect child.
- Their second child is a girl named Phoebe.
- Phoebe has Down syndrome.
- David's younger sister June died at the age of twelve.
- June had a heart defect.
- David decides Phoebe will be placed in an institution.
- Theo Carver is the newborn son of Abe Carver and Lexie Carver.
- Dena Higley created the character.
- Chase and Tyler Johnson appeared in the role from 2003 to 2004.
- Kavi Faquir appeared in the role from 2006 to 2007.
- Amyrh Harris appeared in the role from 2007.
- Terrell Ransom, Jr. appeared in the role in 2008.
- Theo was diagnosed with autism in 2008.
- Theo's autism diagnosis was his most significant storyline.
- Theo had a close friendship with Ciara Brady.
- Terrell Ransom