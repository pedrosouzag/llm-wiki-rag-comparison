# Mick Taylor Biography

Mick Taylor
- Birth name is Michael Kevin Taylor
- Also known as Little Mick
- Date of birth is 17 January 1949
- Age is 69
- Place of birth is Welwyn Garden City, England
- Genres include Rock and Blues
- Occupations include Musician, singer, and songwriter
- Instruments include Guitar
- Years active are 1964 -- present
- Labels include Columbia, Decca, Rolling Stones, Atlantic, EMI, Virgin, CBS, Maze Records
- Associated acts include John Mayall's Bluesbreakers, The Rolling Stones, The Jack Bruce Band, Carla Olson, The Gods, Mike Oldfield