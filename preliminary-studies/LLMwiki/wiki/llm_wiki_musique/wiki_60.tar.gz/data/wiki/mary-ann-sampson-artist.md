# Mary Ann Sampson, Artist

Mary Ann Sampson is an American artist.
Mary Ann Sampson lives and works in Ragland, Alabama.
Mary Ann Sampson is a book artist.
Mary Ann Sampson specializes in miniatures.
Mary Ann Sampson specializes in broadsides.
Most of Mary Ann Sampson’s works are "uniques" or "one-of-a-kinds."
Mary Ann Sampson explores the book as a means of expressing visual ideas.
Mary Ann Sampson’s visual ideas stem from recollections of personal events.
Mary Ann Sampson’s visual ideas stem from experiences derived from living in Alabama.
Mary Ann Sampson lives in a rural environment of Alabama.