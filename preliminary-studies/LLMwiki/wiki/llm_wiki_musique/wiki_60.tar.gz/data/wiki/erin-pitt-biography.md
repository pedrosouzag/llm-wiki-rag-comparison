# Erin Pitt Biography

Erin Pitt
- Erin Pitt was born in Hamilton, Ontario
- Erin Pitt is one of six siblings
- Erin Pitt has two sisters
- Erin Pitt has three brothers
- Erin Pitt has attended the Hamilton Academy of Performing Arts
- Erin Pitt studies acting
- Erin Pitt studies singing
- Erin Pitt studies dancing
- Erin Pitt has performed with the Hamilton City Ballet