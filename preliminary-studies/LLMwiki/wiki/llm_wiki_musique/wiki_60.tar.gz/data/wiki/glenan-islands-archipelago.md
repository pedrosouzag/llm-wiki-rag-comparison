# Glénan Islands Archipelago

- The Glénan islands are an archipelago.
- The Glénan islands are located off the coast of France.
- They are located in the south of Finistère.
- They are near Concarneau.
- They are near Fouesnant.
- The Glénan islands comprise nine major islands.
- The nine major islands are Saint-Nicolas, the Loc'h, Penfret, Cigogne, Drenec, Bananec, Brunec, Guiriden and Guéotec.
- There are over a dozen smaller islets.
- Quignénec is a smaller islet.
- Brilimec is a smaller islet.
- Kastell Bargain is a smaller islet.
- Île aux Moutons is considered to be a part of the archipelago.
- The islands belong to the commune of Fouesnant.