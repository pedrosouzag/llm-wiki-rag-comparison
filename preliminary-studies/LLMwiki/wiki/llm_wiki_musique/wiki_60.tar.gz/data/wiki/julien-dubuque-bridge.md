# Julien Dubuque Bridge

- The Julien Dubuque Bridge crosses the Mississippi River.
- It joins the cities of Dubuque, Iowa, and East Dubuque, Illinois.
- The bridge is part of U.S. Route 20 route.
- The Dubuque–Wisconsin Bridge three miles (5 km) north links Dubuque with Wisconsin.
- It is listed in the National Register of Historic Places.