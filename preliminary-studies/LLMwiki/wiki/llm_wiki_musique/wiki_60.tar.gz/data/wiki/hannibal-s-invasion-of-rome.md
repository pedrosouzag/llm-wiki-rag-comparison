# Hannibal's Invasion of Rome

Hannibal is a 1995 novel by Ross Leckie.
The novel is about Hannibal's invasion of Rome beginning in 218 BC.
The story is narrated by Hannibal in his retirement.
It is the first book in the "Carthage" trilogy.
The trilogy covers the Punic Wars.
The novel received mixed reviews.
Reviews criticized the extreme violence in the narrative.
Hannibal is a historical novel.
Hannibal is by a Scottish writer.
- Sempronia (170 BC – after 101 BC) was a Roman noblewoman.
- Sempronia was the sister of Tiberius Gracchus (died 133 BC) and Gaius Gracchus (died 121 BC).
- Sempronia was the wife of a Roman general Scipio Aemilianus.
- Sempronia lived in the Middle and Late Roman Republic.
- Hannibal is an American television series.
- Hannibal is a psychological horror–thriller television series.
- Hannibal was developed by Bryan Fuller for NBC.
- The series is based on characters and elements appearing in Thomas Harris' novels "Red Dragon", "Hannibal" and "Hannibal Rising".
- The series focuses on the relationship between Will Graham and Dr. Hannibal Lecter.
- Will Graham is an FBI special investigator (played by Hugh Dancy).
- Dr. Hannibal Lecter is a forensic psychiatrist (played by Mads Mikkelsen).
- Dr. Hannibal Lecter is destined to become Will Graham's most cunning enemy.
- Dr. Hannibal Lecter is the only person who can understand
- Scipio's father, Publius Scipio, was killed at the Battle of the Upper Baetis in 211 BC.
- Scipio's uncle, Gnaeus Cornelius Scipio Calvus, was killed at the Battle of the Upper Baetis in 211 BC.
- Hasdrubal Barca was Hannibal's brother.
- Hasdrubal was a general of the Carthaginian forces in Hispania.
- Mago was a general of the Carthaginian forces in Hispania.
- Hasdrubal Gisco was a general of the Carthaginian forces in Hispania.
- Scipio was 25 years old when he arrived in Hispania.
- The Punica is a Latin epic poem in seventeen books.
- The Punica is written in dactylic hexameter.
- The Punica was written by Silius Italicus (c. 28 – c. 103 AD).
- The Punica comprises some twelve thousand lines (12,202).
- The Punica's theme is the Second Punic War.
- The Punica focuses on the conflict between Hannibal and Scipio Africanus.
- The Punica was re-discovered in either 1416 or 1417 by Poggio Bracciolini.
- The Punica is the longest surviving Latin poem from antiquity.
- Red Dragon is a 2002 horror film.
- Anthony Hopkins stars as psychiatrist and serial killer Dr. Hannibal Lecter.
- It is a prequel to The Silence of the Lambs (1991) and Hannibal (2001).
- The novel was originally adapted into the film Manhunter (1986).
- The Battle of Cissa was part of the Second Punic War.
- The battle was fought in the fall of 218 BC.
- The battle was fought near the Greek town of Tarraco in north-eastern Iberia.
- Gnaeus Cornelius Scipio Calvus defeated an outnumbered Carthaginian army under Hanno.
- The Romans gained control of the territory north of the Ebro River.
- Hannibal had subdued the territory north of the Ebro River a few months prior in the summer of 218 BC.
- This was the first battle that the Romans had ever fought in Iberia.
- Colonel John ``Hannibal ''Smith is a fictional character.
- Colonel John ``Hannibal ''Smith is one of the four protagonists of the 1980s action - adventure television series The A-Team.
- The producers originally had James Coburn in mind to play the part of Hannibal.
- It eventually ended up going to George Peppard.
- Hannibal Day served as an officer in the regular army before and during the American Civil War.
- Hannibal Day briefly commanded a brigade in the Army of the Potomac.
- Fëanor () is a fictional character from J. R. R. Tolkien's legendarium.
- Fëanor plays an important part in "The Silmarillion".
- He was the eldest son of Finwë, the High King of the Noldor, and his first wife Míriel Serindë.
- Fëanor's mother, Míriel, died shortly after giving birth, having given all her strength and essence to him.
- "For Fëanor was made the mightiest in all parts of body and mind: in valour, in endurance, in beauty, in understanding, in skill, in strength and subtlety alike: of all the Children of Ilúvatar