# Grant Green - Grant's First Stand

Grant's First Stand is an album.
Grant Green is an American jazz guitarist.
Grant Green performs on the album.
The album was released in 1961.
The album was released on the Blue Note label.
Earlier recordings by Grant Green were released as "First Session" in 2001.
- Jazz Contemporary is an album by American jazz trumpeter Kenny Dorham.
- The album was recorded in 1960.
- The album was released on the Time label.
- The album features the recording debut of pianist Steve Kuhn.