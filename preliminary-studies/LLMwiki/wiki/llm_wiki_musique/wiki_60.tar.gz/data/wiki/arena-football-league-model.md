# Arena Football League Model

Arena Football League
- The league runs under a single-entity model.
- The league owns the rights to the teams, players, and coaches.
- The single-entity model was adopted in 2010.
- The league emerged from bankruptcy in 2010.
- Prior to 2010, the league followed the franchise model.
- Each team essentially operated as its own business.
- The league provided rules, officials, scheduling, and organizational structure.
- A pool of money is allotted to teams to aid in travel costs.
- Tom Benson announced that the New Orleans VooDoo were ceasing operations.
- The New Orleans VooDoo were folding "based on circumstances currently affecting the league and the team".
- The AFL had a tentative agreement to sell a $100 million stake in the league to Platinum Equity.
- Platinum Equity would create a centralized, single-entity business model.
- Platinum Equity would streamline league and team operations.
- Platinum Equity would allow the league to be more profitable.
- Benson's move to shut down the VooDoo came during the Platinum Equity conference call.
- There was speculation that Benson had folded because of the deal.
- The 2015 AFL Grand Final was an Australian rules football match.
- The match was contested between the Hawthorn Football Club and the West Coast Eagles.
- The match was held at the Melbourne Cricket Ground on 3 October 2015.
- It was the 119th annual Grand Final of the Australian Football League.
- The match was attended by 98,632 spectators.
- Hawthorn won the match by a margin of 46 points.
- Hawthorn won their third consecutive premiership.
- Hawthorn won their thirteenth VFL/AFL premiership victory overall.
- Cyril Rioli was awarded the Norm Smith Medal.