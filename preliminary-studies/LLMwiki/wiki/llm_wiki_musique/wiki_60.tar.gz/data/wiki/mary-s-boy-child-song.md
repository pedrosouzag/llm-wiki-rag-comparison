# Mary's Boy Child Song

Mary's Boy Child
- "Mary's Boy Child" is a 1956 Christmas song.
- It was written by Jester Hairston.
- It is widely performed as a Christmas carol.