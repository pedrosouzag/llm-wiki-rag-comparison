# Circus Time (TV Program)

Circus Time was a variety program.
Circus Time was presented in the United States.
Circus Time was part of ABC's 1956-57 season.