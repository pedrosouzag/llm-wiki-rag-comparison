# Handel's Messiah Structure

- The work has a three-part structure.
- The three parts approximate to Handel's three-act operas.
- Jennens subdivided the parts into scenes.
- Each scene is a collection of individual numbers or movements.
- Movements take the form of recitatives, arias and choruses.
- There are two instrumental numbers.
- The opening Sinfony is in the style of a French overture.
- The pastoral Pifa is often called the pastoral symphony.
- The pastoral Pifa is at the mid-point of Part I.