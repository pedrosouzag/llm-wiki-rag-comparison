# Adobe LiveCycle Designer

Adobe LiveCycle Designer
- It is a forms authoring tool
- It is published by Adobe Systems
- It renders XML forms as PDF or HTML files
- It is a one-stop design tool