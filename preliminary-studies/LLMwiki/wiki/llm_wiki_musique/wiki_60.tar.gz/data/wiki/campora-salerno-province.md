# Campora, Salerno Province

Campora
- Campora is a town
- Campora is a "comune"
- Campora is in the province of Salerno
- Campora is in Campania
- Campora is in the territory of Cilento
- Campora's population was 810 in 2009
- The Palazzo Corner Spinelli is a palace
- The Palazzo Corner Spinelli is in Venice
- The Palazzo Corner Spinelli is in northern Italy
- The Palazzo Corner Spinelli is located on the Grand Canal
- The Palazzo Corner Spinelli is in the sestiere of San Marco
- The Palazzo Corner Spinelli stands across the canal from the Palazzo Querini Dubois