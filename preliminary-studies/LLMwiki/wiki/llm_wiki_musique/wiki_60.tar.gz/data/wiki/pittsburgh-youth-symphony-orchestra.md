# Pittsburgh Youth Symphony Orchestra

Pittsburgh Youth Symphony Orchestra
- It is one of the oldest youth orchestra programs in the United States.
- It performed its first concert in 1945.
- The first concert was under the direction of Stanley H. Levin.
- The first concert was at Carnegie Music Hall.
- The first concert was in the Oakland neighborhood of Pittsburgh, PA.
- The idea originated with student musicians in the Music Festival of the In-and-About Pittsburgh Music Educators Club.
- It is often represented by its initials, PYSO.
- Members, alumni and supporters affectionately pronounce “PYSO” as “Pie-So”.