# RCBC Plaza Design & Construction

RCBC Plaza
- The RCBC Plaza was designed by Skidmore, Owings & Merrill, LLP.
- Skidmore, Owings & Merrill, LLP cooperated with W.V. Coscolluela & Associates.
- The structural design was provided by Skilling Ward Magnusson Barkshire.
- Skilling Ward Magnusson Barkshire cooperated with R.S. Caparros Associates & Company.
- Project management services was provided by Bovis Lend Lease.
- Construction management works were provided by Pacific Orient Consultants & Management, Inc.
- The Main Contractor was ECW Joint Venture.
- ECW Joint Venture consisted of EEI Corporation (Philippines).
- ECW Joint Venture consisted of Concrete Constructions (Australia).
- ECW Joint Venture consisted of Walter Bau (Germany).
- ECW JV self performed the superstructure construction works.
- EEI Corporation is a part of the Yuchengco Group of Companies.