# Taktin Oey Biography

Taktin Oey
- He graduated from West Windsor-Plainsboro High School North in 2004.
- He graduated from Harvard University in 2008.
- He received the 1999 ASCAP First Prize.
- He received the 1996 ASCAP First Prize.
- He won First Prize for his Piano Quartet in the European Region’s Young Composers’ Competition in 2000.
- He was born in Hugo, Oklahoma, February 5, 1933.
- He is an American writer, author, poet, and photojournalist.
- He has received numerous awards, prizes, and