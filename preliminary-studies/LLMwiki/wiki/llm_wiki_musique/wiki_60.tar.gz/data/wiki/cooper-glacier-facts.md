# Cooper Glacier Facts

Cooper Glacier
- It is a tributary glacier
- It flows northeast between Butchers Spur and the Quarles Range
- It enters the south side of Axel Heiberg Glacier
- It is in the Queen Maud Mountains
- R. Admiral Byrd discovered it in November 1929
- It was named by R. Admiral Byrd for Kent Cooper
- Kent Cooper was an official of the Associated Press
- Hangin' with Mr. Cooper is an American television sitcom.
- It originally aired on ABC from September 22, 1992 to August 30, 1997.
- It starred Mark Curry and Holly Robinson.
- The show took place in Oakland, California.
- It was produced by Jeff Franklin Productions.
- It was produced in association with Warner Bros. Television.
- It was originally produced by Lorimar Television for the first season.
- It was produced by Bickley - Warren Productions by the third season.
- It originally aired on Tuesdays in prime time after Full House.
- It was part of the TGIF Friday night lineup on ABC from September