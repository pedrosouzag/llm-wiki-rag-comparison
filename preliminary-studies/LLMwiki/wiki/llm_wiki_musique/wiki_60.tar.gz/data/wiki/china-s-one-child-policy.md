# China's One-Child Policy

One-child policy
- It was a population planning policy of China.
- It was introduced in 1979.
- It began to be formally phased out in 2015.
- It allowed exceptions for ethnic minorities.
- In 2007, 36% of China's population was subject to a strict one-child restriction.
- An additional 53% were allowed to have a second child if the first child was a girl.
- Provincial governments imposed fines for violations.
- Local and national governments created commissions to raise awareness.
- Local and national governments carried out registration and inspection work.
- The one - child policy, a part of the family planning policy, was a population planning policy of China.
- It began to be formally phased out near the end of 2015 and the beginning of 2016.
- The policy was only enforced on Han Chinese.
- It allowed exceptions for many groups, including ethnic minorities.
- China's first imperial dynasty was the Qin dynasty (221–206 BC).
- Qin unified the Chinese Warring States by conquest.
- Xiang Yu (d. 202 BC) of Chu was a former rebel leader.
- Liu Bang (d. 195 BC) of Han was a former rebel leader.
- Liu Bang defeated Xiang Yu at Battle of Gaixia (202 BC).
- Liu Bang assumed the title "emperor" (huangdi).
- Liu Bang is known posthumously as Emperor Gaozu (r. 202–195 BC).
- Chang'an was chosen as the new capital of