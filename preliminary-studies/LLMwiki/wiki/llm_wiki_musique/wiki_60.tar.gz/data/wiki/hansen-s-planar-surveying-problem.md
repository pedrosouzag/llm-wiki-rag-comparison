# Hansen's Planar Surveying Problem

Hansen's Problem
- It is a problem in planar surveying.
- It is named after Peter Andreas Hansen.
- Peter Andreas Hansen lived from 1795 to 1874.
- Peter Andreas Hansen worked on the geodetic survey of Denmark.
- There are two known points "A" and "B".
- There are two unknown points "P" and "P".
- An observer measures angles to each of the other three points from "P" and "P".
- The problem is to find the positions of "P" and "P".
- The angles measured are ("α", "β", "α", "β").