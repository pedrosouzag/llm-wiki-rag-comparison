# Vice Admiral Christy

Harley H. Christy
- Harley Hannibal Christy was born on 18 September 1870.
- Harley Hannibal Christy died on 4 June 1950.
- Harley Hannibal Christy served in the United States Navy.
- Harley Hannibal Christy served in the Spanish–American War.
- Harley Hannibal Christy served in World War I.