# Jan Hendrik van den Berg

Jan Hendrik van den Berg
- Jan Hendrik van den Berg was born on June 11, 1914.
- Jan Hendrik van den Berg died on September 22, 2012.
- Jan Hendrik van den Berg was Dutch.
- Jan Hendrik van den Berg was a psychiatrist.
- Jan Hendrik van den Berg worked in phenomenological psychotherapy.
- Jan Hendrik van den Berg worked in metabletics.
- Jan Hendrik van den Berg is the author of "A different existence".
- Jan Hendrik van den Berg is the author of "The changing nature of man".
- Jan Hendrik van den Berg wrote numerous articles.
- Jan Hendrik van den Berg wrote numerous books.
- Jan Hendrik van den Berg was notable for his work in phenomenological psychotherapy (cf. phenomenology).
- Jan Hendrik van den Berg was notable for his work in metabletics, or "psychology of historical change."