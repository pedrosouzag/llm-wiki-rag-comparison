# Oak Lawn, Illinois

Oak Lawn, Illinois
- Oak Lawn is a suburb of Chicago
- It is located southwest of Chicago
- It shares borders with the city in two areas
- It is surrounded mostly by other suburbs
- The 2018 Illinois gubernatorial election takes place as part of the 2018 Illinois general election.
- The election elects the Governor of Illinois.
- Democratic and Republican general primary elections will take place on March 20, 2018.
- The general election will take place on November 6, 2018.