# Green Lake, Chisago City

Green Lake (Chisago City, Minnesota)
- Green Lake is in Chisago City, Minnesota.
- Green Lake is in the United States.
- Green Lake is sometimes referred to as "Big Green Lake".
- Little Green Lake is connected to Green Lake by a channel.
- The waters of Green Lake are green.
- The waters of Green Lake are green because of high algae content.