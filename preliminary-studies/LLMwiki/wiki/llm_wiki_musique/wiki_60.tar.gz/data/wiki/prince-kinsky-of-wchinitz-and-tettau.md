# Prince Kinsky of Wchinitz and Tettau

- Ulrich, 10th Prince Kinsky of Wchinitz and Tettau (; 15 August 189319 December 1938) was the titular pretender Prince Kinsky of Wchinitz and Tettau.
- Ulrich was born on 15 August 1893.
- Ulrich died on 19 December 1938.
- Ulrich was the titular pretender Prince Kinsky of Wchinitz and Tettau.
- The Ulrich Walser House is located at 711 North 2nd Street in Alma, Wisconsin, United States.
- The Ulrich Walser House was constructed in 1895 by Ulrich Walser.
- The Ulrich Walser House was placed on the National Register of Historic Places in 1982.
- Ulrich Joseph Franzen (January 15, 1921 – October 6, 2012) was a German-born American architect.
- Ulrich Joseph Franzen was known for his "fortresslike" buildings.
- Ulrich Joseph Franzen was known for his Brutalist style.
- Daniel Bremer Juell was born in Siljord in 1808.
- Daniel Bremer Juell’s father was district stipendiary magistrate ("sorenskriver") Ole Juell.
- Daniel Bremer Juell’s mother was Caroline Kathrine née Bremer.
- Daniel Bremer Juell married Caroline Boeck.
- Caroline Boeck was the daughter of captain Cæsar Boeck.
- Daniel Bremer Juell and Caroline Boeck had three children.