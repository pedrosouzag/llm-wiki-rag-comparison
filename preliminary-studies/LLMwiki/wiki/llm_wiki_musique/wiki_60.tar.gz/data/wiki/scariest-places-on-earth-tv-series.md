# Scariest Places on Earth (TV series)

Scariest Places on Earth
- Scariest Places on Earth is an American paranormal reality television series.
- The show originally aired from October 23, 2000, to October 29, 2006.
- It originally aired on Fox Family.
- It later aired on ABC Family.
- The show was hosted by Linda Blair.
- Zelda Rubinstein provided narration.
- The show featured reported cases of the paranormal.
- The show detailed the location's history.
- The show sent an ordinary family to visit the location in a reality TV-style vigil.