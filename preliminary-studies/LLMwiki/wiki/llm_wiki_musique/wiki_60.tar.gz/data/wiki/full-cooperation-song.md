# Full Cooperation (song)

Full Cooperation is a song by Def Squad
Def Squad is an American hip hop group
"El Niño" is an album
"El Niño" was released in 1998
"Full Cooperation" was released on April 14, 1998
"Full Cooperation" was released in promotion of "El Niño"
"Full Cooperation" is the only single from "El Niño"