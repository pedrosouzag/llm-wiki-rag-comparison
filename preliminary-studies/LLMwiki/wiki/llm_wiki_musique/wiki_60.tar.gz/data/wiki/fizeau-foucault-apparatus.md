# Fizeau–Foucault apparatus

- Fizeau–Foucault apparatus is used to measure the speed of light.
- The term refers to two types of instrument.
- Hippolyte Fizeau and Léon Foucault were friends and collaborators.
- Fizeau and Foucault used the Daguerreotype process to take images of the Sun between 1843 and 1845.
- Fizeau and Foucault characterized absorption bands in the infrared spectrum of sunlight in 1847.