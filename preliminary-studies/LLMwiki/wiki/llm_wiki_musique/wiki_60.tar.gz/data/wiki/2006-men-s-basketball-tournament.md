# 2006 Men's Basketball Tournament

2006 NCAA Division I Men's Basketball Tournament
- LSU scored 45 points.
- UCLA scored 59 points.
- UCLA scored 57 points.
- Florida scored 73 points.
- Florida scored 73 points.
- George Mason scored 58 points.
- The Sacramento Kings are an American professional basketball team.
- The Sacramento Kings are based in Sacramento, California.
- The Sacramento Kings compete in the National Basketball Association (NBA).
- The Sacramento Kings are a member of the Western Conference's Pacific Division.
- The Sacramento Kings are the only team in the major professional North American sports leagues located in Sacramento.
- The Sacramento Kings play their home games at the Golden 1 Center.