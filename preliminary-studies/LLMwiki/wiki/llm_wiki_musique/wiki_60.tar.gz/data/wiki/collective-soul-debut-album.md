# Collective Soul Debut Album

Hints Allegations and Things Left Unsaid is the debut studio album by Collective Soul.
It was released on Rising Storm Records in 1993.
The track "Shine" gained the band attention.
They later signed with Atlantic Records.
The album was released on CD in 1994 under the Atlantic label.
- Soul Fixin' Man is an album by American blues guitarist Luther Allison.
- It was released in 1994 by Alligator Records.
- It is also known as "Bad Love".
- Some editions have a different track listing.
- Three for Shepp is the debut album by American saxophonist Marion Brown.
- It features performances recorded in 1966 for the Impulse! label.