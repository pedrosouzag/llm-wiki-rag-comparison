# Ciudad Deportiva Nuevo Laredo

Ciudad Deportiva (Nuevo Laredo)
- The Ciudad Deportiva is a sports complex in Nuevo Laredo, Mexico.
- It is home to the Tecolotes de Nuevo Laredo Mexican Baseball League team.
- It is home to the Toros de Nuevo Laredo Mexican professional basketball team from the Liga Nacional de Baloncesto Profesional.
- The Ciudad Deportiva's Estadio Nuevo Laredo can seat up to 12,000 fans at a baseball game.
- The Nuevo Laredo Multidisciplinary Gymnasium can seat 4,000 fans at a basketball game.
- It is a multi-use stadium in Tarma, Peru.
- It is currently used mostly for football matches.
- It is the home stadium of Asociación Deportiva Tarma of the Copa Perú.
- The stadium holds 9,000 spectators.
- The Stadio Giuseppe Grezar was a multi-use stadium in Trieste, Italy.
- It was inaugurated in 1932 as the Stadio Littorio.
- It was initially used as the stadium of U.S. Triestina Calcio matches.
- The capacity of the stadium was 8,000.
- It hosted the match between Czechoslovakia and Romania during the 1934 FIFA World Cup.