# Lago District, Mozambique

Lago District
- Lago District is a district of Niassa Province
- Lago District is in north-western Mozambique
- The principal town is Metangula
- Lago District is bordered to the west by Lake Nyasa
- Lago District is bordered on the south by Lichinga
- Lago District is bordered on the east by Sanga District
- Lago District shares its northern boundary with Tanzania