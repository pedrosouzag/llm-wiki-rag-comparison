# A Little Bit of Love (song)

- "A Little Bit of Love" is a song written by Andreas Johnson and Peter Kvint.
- Andreas Johnson performed "A Little Bit of Love" at Melodifestivalen 2007.
- The song participated in the semifinale in Gävle on 24 February 2007.
- The song headed directly to the finals inside the Stockholm Globe Arena on 10 March 2007.
- The song finished second.
- The single was released on 5 March 2007.
- The single peaked at third position at the Swedish singles chart.
- The song became a major radio hit at Sveriges Radio.
- The song became a major radio hit at the commercial stadions.