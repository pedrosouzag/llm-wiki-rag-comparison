# Mian Haji Sahib, Pakistan

Mian Haji Sahib
- Mian Haji Sahib is a town.
- It is in the Islamabad Capital Territory of Pakistan.
- It is located at 33° 22' 50N 73° 20' 40E.
- It has an altitude of 479 metres.
- It has an altitude of 1574 feet.