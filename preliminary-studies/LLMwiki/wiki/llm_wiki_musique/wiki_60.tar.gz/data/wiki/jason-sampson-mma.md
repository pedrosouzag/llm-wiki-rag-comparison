# Jason Sampson (MMA)

Jason Sampson
- Jason Sampson was born on February 21, 1982.
- Jason Sampson is an American professional mixed martial artist.
- Jason Sampson currently competes in the flyweight division of Legacy FC.
- Jason Sampson has been a professional competitor since 2009.
- Jason Sampson has previously competed for Bellator.
- Jason Sampson has previously competed for Shark Fights.
- Timothy Wallace Credeur II was born on July 9, 1977.
- Tim Credeur is a retired American mixed martial artist.
- Tim Credeur was a cast member of SpikeTV's "The Ultimate Fighter 7".
- Tim Credeur was defeated by Jesse Taylor in the semi-finals of "The Ultimate Fighter 7".
- Tim Credeur was brought back into the competition following the disqualification of Jesse Taylor.
- Tim Credeur lost to C.B. Dollaway via decision.