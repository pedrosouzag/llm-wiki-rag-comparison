# No Escape (1936 film)

No Escape (1936 film)
- No Escape is a 1936 British thriller film.
- The film was directed by Norman Lee.
- The film stars Valerie Hobson.
- The film stars Leslie Perrins.
- The film stars Robert Cochran.
- The screenplay concerns a man who attempts to hide his friend for a month.