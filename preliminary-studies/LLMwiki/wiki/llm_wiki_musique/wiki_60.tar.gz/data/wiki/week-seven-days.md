# Week - Seven Days

Week
- A week is a time unit equal to seven days.
- A week is used for cycles of rest days in most parts of the world.
- A week is used alongside the Gregorian calendar.