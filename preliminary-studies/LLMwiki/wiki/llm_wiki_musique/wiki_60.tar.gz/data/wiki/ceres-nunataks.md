# Ceres Nunataks

- The Ceres Nunataks are a group of three nunataks
- The Ceres Nunataks are located east of the base of Shostakovich Peninsula
- The Ceres Nunataks are in southern Alexander Island, Antarctica
- The Ceres Nunataks were mapped by the Directorate of Overseas Surveys
- The mapping used satellite imagery supplied by the U.S. National Aeronautics and Space Administration
- The mapping was in cooperation with the U.S. Geological Survey
- The UK Antarctic Place-Names Committee named the Ceres Nunataks
- The Ceres Nunataks were named after Ceres
- Ceres is one of the asteroids
- Ceres lies between the orbits of the planets Mars and Jupiter
- Amundsen Icefall is a steep and turbulent icefall.
- The Amundsen Icefall is where the Axel Heiberg Glacier descends from the polar plateau between Mount Fridtjof Nansen and Mount Don Pedro Christophersen.
- The Amundsen Icefall is in the Queen Maud Mountains of Antarctica.
- The Southern Party of the New Zealand Geological Survey Antarctic Expedition (1961–62) named the Amundsen Icefall.
- Captain Roald Amundsen ascended Axel Heiberg Glacier en route to the South Pole in 1911.
- The Amundsen Icefall was named for Captain Roald Amundsen.