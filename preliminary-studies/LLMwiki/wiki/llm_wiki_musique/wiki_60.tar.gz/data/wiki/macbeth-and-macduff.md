# Macbeth and Macduff

Macbeth
- A battle culminates in Macduff's confrontation with Macbeth.
- Macbeth kills Young Siward in combat.
- English forces overwhelm Macbeth's army.
- English forces overwhelm Macbeth's castle.
- Macbeth boasts he can not be killed by any man born of woman.
- Macduff was ``from his mother's womb / Untimely ripp'd''.
- Macduff is not`` of woman born''.
- Macduff fulfills the second prophecy.
- Macbeth misinterpreted the witches' words.
- Macbeth realises he is doomed.
- Macduff kills and beheads Macbeth.
- Macduff fulfills the remaining prophecy.
- Macbeth is initially a valorous and loyal general to the elderly King Duncan.
- The play is based mainly upon Raphael Holinshed's account.
- Macbeth's wife flattered him.
- Macbeth rationalizes that murdering his king and usurping the throne is the right thing to do.
- The prophecies of the witches prove misleading.
- Macbeth alienates the nobility of Scotland.
- Macbeth's wife and children had earlier been murdered by Macbeth's death squads.
- Macbeth at first refuses to duel Macduff.
- Macbeth vows, ``I will not yield to kiss the ground before young Malcolm's feet, to be baited by a rabble's curse.''
- Prince
- Macduff charges into the main castle and confronts Macbeth.
- Macduff presents Macbeth's head to Malcolm.
- Macduff calls on the other thanes to declare their allegiance with him.