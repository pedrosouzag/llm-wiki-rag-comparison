# National Cycle Route 57

- National Cycle Route 57 is part of the United Kingdom's National Cycle Network.
- It will run west to east when complete.
- It will run from Farmington, Gloucestershire near Northleach.
- It will run to Welwyn Garden City in Hertfordshire.
- The National Cycle Network is the national cycling route network of the United Kingdom.
- It was established to encourage cycling throughout Britain, as well as for the purposes of bicycle touring.
- It was created by the charity Sustrans.
- Sustrans were aided by a £42.5 million National Lottery grant.
- In 2017, the 16,575 mile network was used for over 786 million trips.