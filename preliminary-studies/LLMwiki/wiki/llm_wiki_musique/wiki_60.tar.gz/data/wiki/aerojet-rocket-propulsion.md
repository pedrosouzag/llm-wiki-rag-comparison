# Aerojet Rocket Propulsion

Aerojet was an American rocket and missile propulsion manufacturer
Aerojet was based primarily in Rancho Cordova, California
Aerojet had divisions in Redmond, Washington
Aerojet had divisions in Orange, Virginia
Aerojet had divisions in Gainesville, Virginia
Aerojet had divisions in Camden, Arkansas
Aerojet was owned by GenCorp
In 2013, Aerojet was merged with Pratt & Whitney Rocketdyne
The merged company was named Aerojet Rocketdyne