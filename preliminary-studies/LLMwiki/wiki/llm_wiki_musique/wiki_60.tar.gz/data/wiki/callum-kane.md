# Callum Kane

Callum Kane is a fictional character.
Callum Kane is from the British Channel 4 soap opera "Hollyoaks".
Callum Kane is played by Laurie Duncan.
Callum Kane's character and Duncan's casting was announced on 25 August 2011.
Callum was introduced along with five other regular characters.
Callum made his first screen appearance on 6 September 2011.
Callum appeared in the sixth series of "Hollyoaks Later" in October 2013.
Callum was killed off in October 2013.
Callum's exit was part of a "cast cull".
Callum's exit coincided with the show's 18th anniversary.
Duncan's departure from the show was kept secret.
Laurie Duncan cried when he learned he was leaving.