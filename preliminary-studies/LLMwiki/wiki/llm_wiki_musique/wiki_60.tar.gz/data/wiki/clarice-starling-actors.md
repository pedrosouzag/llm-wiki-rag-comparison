# Clarice Starling Actors

Clarice Starling
- She was played by Jodie Foster in the film adaptation of The Silence of the Lambs.
- She was played by Julianne Moore in the film adaptation of Hannibal.
- Hannibal is a 2001 American psychological horror film.
- It is directed by Ridley Scott.
- It is adapted from the novel of the same name by Thomas Harris.
- It is the sequel to the 1991 film The Silence of the Lambs.
- Anthony Hopkins returns to his role as Hannibal Lecter.
- Julianne Moore co-stars as FBI Special Agent Clarice Starling.
- Gaspard Ulliel is a French actor and model.
- He was born on 25 November 1984.
- He is best known for portraying serial killer Hannibal Lecter in "Hannibal Rising" (2007).
- He portrayed fashion mogul Yves Saint Laurent in the biopic "Saint Laurent" (2014).
- He is the face of the Chanel men's fragrance, Bleu de Chanel.