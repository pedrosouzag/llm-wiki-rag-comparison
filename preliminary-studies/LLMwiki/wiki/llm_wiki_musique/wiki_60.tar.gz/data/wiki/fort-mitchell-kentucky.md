# Fort Mitchell, Kentucky

Fort Mitchell, Kentucky
- Fort Mitchell is a home rule-class city
- Fort Mitchell is in Kenton County, Kentucky
- Fort Mitchell is in the United States
- The population of Fort Mitchell was 8,207 at the 2010 census
- Snappy Tomato Pizza is a pizza chain that started in Fort Mitchell, Kentucky
- The chain has over 60 locations nationwide
- Its headquarters are in Burlington, Kentucky
- The chain specializes in pizza, but also serves calzones, hoagies, salads, pasta, dessert and appetizers