# Ofu Airport, American Samoa

Ofu Airport
- Ofu Airport is located one mile (2 km) southeast of the village of Ofu.
- Ofu Airport is located on the island of Ofu.
- Ofu Airport is located in American Samoa.
- American Samoa is an unincorporated territory of the United States.
- Ofu Airport is publicly owned by Government of American Samoa.