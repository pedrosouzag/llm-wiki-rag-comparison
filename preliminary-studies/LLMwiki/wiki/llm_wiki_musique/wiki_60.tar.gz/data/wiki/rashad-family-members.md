# Rashad Family Members

Phylicia Rashād is an actress.
Phylicia Rashād is a director.
Phylicia Rashād is a singer.
Debbie Allen is Phylicia Rashād’s older sister.
Debbie Allen is married to Norm Nixon.
Norm Nixon is a former NBA basketball player.
Phylicia Rashād was married to Victor Willis.
Victor Willis is a former lead singer of the group Village People.
Phylicia Rashād was married to Ahmad Rashād.
Ahmad Rashād is a former NFL football player.
Ahmad Rashād is a sportscaster.
Phylicia Rashād and Ahmad Rashād are the parents of Condola Rashād.
Condola Rashād is an actress.
- Morris Mike Medavoy was born January 21, 1941.
- Mike Medavoy is an American film producer.
- Mike Medavoy is an American film executive.
- Mike Medavoy is a co-founder of Orion Pictures (1978).
- Mike Medavoy was former chairman of TriStar Pictures.
- Mike Medavoy was former head of production for United Artists (1974–1978).
- Mike Medavoy is current chairman and CEO of Phoenix Pictures.
- Marshall Eriksen is a How I Met Your Mother character.
- Marshall Eriksen had a first appearance in ``Pilot``.
- Marshall Eriksen had a last appearance in ``Last Forever``.
- Marshall Eriksen was created by Carter Bays and Craig Thomas.
- Marshall Eriksen was portrayed by Jason Segel.
- Marshall Eriksen’s father is Marvin Eriksen (deceased).
- Marshall Eriksen’s mother is Judy Eriksen.
- Marshall Eriksen is married to Lily Aldrin (2007 -- present).
- Marshall Eriksen has children Marvin Waitforit Eriksen, Daisy Eriksen, and an unnamed third child.
- Marshall Eriksen is American.
- Marshall Eri
- Andrea Kremer was born February 25, 1959 in Philadelphia, Pennsylvania.
- Andrea Kremer is an American television sports journalist.
- Andrea Kremer has won multiple Emmy Awards.
- Andrea Kremer currently calls "Thursday Night Football" games for Amazon Prime Video.
- Andrea Kremer is the first all-women booth to call any major men's team sport, not just football.
- Andrea Kremer is Chief Correspondent for the NFL Network.
- Andrea Kremer previously led the network's coverage and in-depth reporting on health and safety.
- Andrea Kremer is a correspondent for HBO's "Real Sports with Bryant Gumbel".
- Andrea Kremer
- Meg Griffin is a Family Guy character.
- Meg Griffin first appeared in 1998.
- Meg Griffin first appeared in ``Pilot Pitch of Family Guy (Early version)``.
- Meg Griffin first appeared in ``Death Has a Shadow ``(Official version).
- Meg Griffin was created by Seth MacFarlane.
- Meg Griffin was voiced by Lacey Chabert (1999 -- 2000, 2011, 2012).
- Meg Griffin was voiced by Mila Kunis (1999 -- present).
- Meg Griffin was voiced by Tara Strong (singing voice).
- Meg Griffin is a high school student.
- Meg Griffin
- Angelica Sue Page is an American actress.
- Angelica Sue Page is an American director.
- Angelica Sue Page is an American producer.
- Angelica Sue Page is an American screenwriter.
- Angelica Sue Page (née Torn)
- Angelica Page legally and professionally changed her name in September 2011.
- Rip Torn is Angelica Page’s father.
- Geraldine Page is Angelica Page’s mother.
- Angelica was credited as Angelica Torn in her early career.
- Angelica Page was born February 17, 1964.
- Melissa Reeves was born March 14, 1967.
- Melissa Reeves’s other names are Melissa Brennan, Missy Brennan, Melissa B. Reeves, and Melissa Brennan Reeves.
- Melissa Reeves’s occupation is actress.
- Melissa Reeves has been active since 1983.
- Melissa Reeves married Scott Reeves in 1990.
- Melissa Reeves has children.