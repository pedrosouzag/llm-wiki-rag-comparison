# Shiromaniam Madhavan

Shiromaniam Madhavan
- Shiromaniam Madhavan (1944 - 29 June 1994)
- He was the son of a founding member of the National Federation Party (NFP).
- He served in the Labasa Town Council.
- He served in the House of Representatives.
- He contested numerous elections for different political parties.