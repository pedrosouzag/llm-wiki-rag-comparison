# Van Buren Township, Brown County

Van Buren Township
- Van Buren Township is one of four townships in Brown County, Indiana.
- As of the 2010 census, its population was 2,008.
- It contained 941 housing units.
- The township includes the southern portion of Brown County State Park.
- Liberty Township is one of the twelve townships of Van Wert County, Ohio, United States.
- The 2000 census found 1,696 people in the township.
- 912 of those people lived in the unincorporated portions of the township.
- Culberson County-Allamoore Independent School District is a public school district.
- The district is based in Van Horn, Texas (USA).
- The district serves all of Culberson County.
- The district serves eastern portions of Hudspeth County.
- The district was created in 1995.
- The district was created by the consolidation of the Culberson County and Allamore districts.