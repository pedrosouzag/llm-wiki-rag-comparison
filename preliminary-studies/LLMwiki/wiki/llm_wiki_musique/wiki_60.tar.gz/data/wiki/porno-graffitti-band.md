# Porno Graffitti (band)

Porno Graffitti is a Japanese rock band
Porno Graffitti is from Onomichi, Hiroshima Prefecture, Japan
Porno Graffitti was formerly from Innoshima
Porno Graffitti got their name from the album "Pornograffitti" by the band Extreme
Porno Graffitti records under the SME Records label
Porno Graffitti's agency is Amuse, Inc.