# Stan Tekiela Naturalist

Stan Tekiela
- Stan Tekiela is a naturalist.
- Stan Tekiela is an author.
- Stan Tekiela is a wildlife photographer.
- Stan Tekiela has a Bachelor of Science degree in Natural History from the University of Minnesota.
- Stan Tekiela has been an active professional naturalist for more than 25 years.
- Stan Tekiela is a member of the Minnesota Ornithologists' Union.
- Stan Tekiela is a member of the North American Nature Photography Association.
- Stan Tekiela is a member of Canon Professional Services.
- Stan Tekiela studies and photographs wildlife throughout the United States.
- Stan Tekiela has received various national and regional awards for his books and photographs.
- Stan Tekiela is a columnist.
- Stan Tekiela is a radio personality.
- Stan Tekiela's syndicated column appears in more than 25 newspapers.
- Stan Tekiela can be heard on a number of Midwest radio