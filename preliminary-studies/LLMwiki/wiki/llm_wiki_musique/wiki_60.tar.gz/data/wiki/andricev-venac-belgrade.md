# Andrićev Venac, Belgrade

- Andrićev Venac is a street.
- Andrićev Venac is an urban neighborhood.
- Andrićev Venac is located in Belgrade.
- Andrićev Venac is located in the municipality of Stari Grad.
- The official seat of the President of Serbia is located in Andrićev Venac.
- Andrićev Venac became synonymous for the politics of the president.
- San Marino has an embassy in Belgrade.
- Ubaldo Livolsi is the Ambassador of San Marino to Serbia.
- Ambassador Livolsi presented his Letters of Credence on February 2, 2005.
- The Ambassador of Serbia to Italy accredited on non-residential basis to San Marino is Sanda Rašković Ivić.