# Grant Green - The Main Attraction

- The Main Attraction is an album.
- The album is by Grant Green.
- Grant Green is an American jazz guitarist.
- The album was recorded in 1976.
- The album was released on the Kudu label.
- Peter Andreas Morén is a Swedish musician.
- He was born on 5 May 1976 in Mora, Sweden.
- He is the guitarist and vocalist of the indie rock trio Peter Bjorn and John.
- He is a founding member of the Stockholm-based artist collective INGRID.
- The Main Attraction is an album by American jazz guitarist Grant Green featuring performances recorded in 1976 and released on the Kudu label.
- The album features performances recorded in 1976.
- The album features performances.
- Soundsigns is an album.
- The album is by the American jazz saxophonist Dewey Redman.
- The album was recorded in 1978.
- The album was released on the Galaxy label.