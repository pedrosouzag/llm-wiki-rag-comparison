# Pirate Party Belgium

Pirate Party (Belgium)
- The Pirate Party of Belgium is a political party in Belgium.
- It is based on the model of the Swedish Pirate Party.
- It supports reform of copyright law.
- It supports the abolition of patents.
- It supports respect for privacy.
- It was a founding member of Pirate Parties International.
- The Green Party of Tennessee is a state-level political party in Tennessee.
- It is a member of the Green Party of the United States.
- The party formed in 2001.