# Alice Cooper - Fistful of Alice

A Fistful of Alice
- A Fistful of Alice is a live album by Alice Cooper.
- It was released in 1997.
- It was recorded in 1996.
- It was recorded at Sammy Hagar's Cabo Wabo club in Cabo San Lucas, Mexico.
- Slash plays guitar for part of the album.
- Cooper guested on "The Garden" in 1991.
- "The Garden" is on the Guns N' Roses album "Use Your Illusion I".
- Cooper says "Desperado" was written about Jim Morrison.
- Jim Morrison died in 1971.
- Cooper wrote the song "Desperado" in 1971.
- Rob Zombie is on vocals in the album.
- Sammy Hagar is on guitar in the album.
- The title track from 1991's "Hey Sto