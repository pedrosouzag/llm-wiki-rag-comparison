# Piping Technology and Products

Piping Technology and Products is privately owned.
Piping Technology and Products is a pipe support manufacturing and engineering company.
Piping Technology and Products is headquartered in Houston, Texas.
Piping Technology and Products is located in the United States.
US Bellows is a wholly owned subsidiary of Piping Technology and Products.
Sweco Fab is a wholly owned subsidiary of Piping Technology and Products.
Fronek Anchor/Darling Enterprise is a wholly owned subsidiary of Piping Technology and Products.
Pipe Shields is a wholly owned subsidiary of Piping Technology and Products.
Companies provide pipe supports.
Companies provide expansion joints.
Companies provide shock and vibration controls.
Companies provide pre-insulated supports.
Industries served include LNG.
Industries served include chemical.
Industries served include petrochemical.
Industries served include pulp & paper.
Industries served include aerospace.