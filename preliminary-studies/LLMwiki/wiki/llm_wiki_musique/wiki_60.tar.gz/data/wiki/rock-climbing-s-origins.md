# Rock Climbing's Origins

Rock climbing was an important component of Victorian mountaineering in the Alps.
Rock climbing began in the last quarter of the 19th century.
Rock climbing began in the Elbe Sandstone Mountains near Dresden.
Rock climbing began in the north of England.
Rock climbing began in the Peak district.
Rock climbing began in the Lake District.
Rock climbing began in the Dolomites in Italy.
Rock climbing evolved gradually from an alpine necessity to an athletic sport.
It is imprudent to cite a primogenitor of rock climbing in each of the three locales.
There is some general agreement on the following facts.
- As of 2017, 22 performers have been inducted twice or more.
- Fourteen performers have been recognized as a solo artist and with a band.
- Seven performers have been inducted with two separate bands.
- Eric Clapton is the only one to be inducted three times.
- Clyde McPhatter was the first to ever be inducted twice.
- Clyde McPhatter is one of three artists to be inducted first as a solo artist and then as a member of a band.
- Neil Young is one of three artists to be inducted first as a solo artist and then as a member of a band.
- Rod Stewart is one of three artists to be inducted first as a