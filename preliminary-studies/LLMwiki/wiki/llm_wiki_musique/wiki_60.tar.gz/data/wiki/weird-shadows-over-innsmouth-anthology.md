# Weird Shadows Over Innsmouth (anthology)

Weird Shadows Over Innsmouth
- It is an anthology of Cthulhu Mythos stories.
- It was edited by Stephen Jones.
- It was published by Fedogan & Bremer.
- It was published in 2005.
- The edition size was 2,100 copies.
- 100 of the copies were signed.
- It contains a discarded draft of "The Shadow Over Innsmouth."
- It contains stories by other authors.
- The stories are sequels to "The Shadow Over Innsmouth."
- Eight of the stories are original to this collection.
- Other stories first appeared in "The Acolyte."
- Other stories first appeared in "The Spook."
- Other stories first appeared in anthologies.
- Insanely Twisted Shadow Planet is a shooter puzzle video game.
- It was developed by Shadow Planet Productions (Fuelcell Games/Gagne International).
- It was published by Microsoft Studios.
- It was released for Xbox 360 and Microsoft Windows.
- A self-published DRM-free version with soundtrack included was featured in the Humble Indie Bundle 13.