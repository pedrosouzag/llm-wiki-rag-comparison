# Martha Creek Provincial Park

Martha Creek Provincial Park
- It is a provincial park in British Columbia, Canada
- It is located on the Lake Revelstoke Reservoir
- It is north of the city of Revelstoke
- Pine Mountain State Resort Park is located in Bell County, Kentucky, United States.
- The park opened in 1924 as Kentucky's first state park.
- Each spring, the park hosts the annual Kentucky Mountain Laurel Festival, as it has since 1933.
- A portion of the park is a legally dedicated nature preserve by the Office of Kentucky Nature Preserves.
- It is located in the Canadian Rockies
- It is on the border of Alberta and British Columbia
- It is northwest of Kicking Horse Pass
- It straddles the shared border of Banff National Park with Yoho National Park
- It was named in 1903 after George Morris Bosworth
- George Morris Bosworth was an executive and long-time employee of the Canadian Pacific Railway