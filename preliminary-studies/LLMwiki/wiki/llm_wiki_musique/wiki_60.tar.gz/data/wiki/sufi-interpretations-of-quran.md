# Sufi Interpretations of Quran

Quran
- Sulami (d. 1021) is an author of esoteric interpretation.
- Haqaiq al-tafsir is a book named by Sulami.
- Haqaiq al-tafsir is a compilation of commentaries of earlier Sufis.
- Qushayri (d. 1074) wrote commentaries from the 11th century onwards.
- Daylami (d. 1193) wrote commentaries from the 11th century onwards.
- Shirazi (d. 1209) wrote commentaries from the 11th century onwards.
- Suhrawardi (d. 1234) wrote commentaries from the 11th century onwards.
- Maybudi (d. 1135) wrote in Persian.
- Kash al-asrar is a work written by Maybudi.
- Kash al-
- Islamic education is rooted in the teachings of the Quran.
- Islamic education and Muslim education are not the same.
- Islamic education has epistemological integration founded on Tawhid.
- Tareq M Zayed wrote "A Qur’anic Methodology for Integrating Knowledge and Education: Implications for Malaysia’s Islamic Education Strategy".
- Tareq M Zayed authored "Knowledge of Shariah and Knowledge to Manage ‘Self’ and ‘System’: Integration of Islamic Epistemology with the Knowledge and Education".
- Rumi (d. 1273) wrote a vast amount of mystical poetry in his book Mathnawi.
- Rumi makes heavy use of the Quran in his poetry.
- Some translations of Rumi's work omit the feature of Rumi making heavy use of the Quran.
- A large number of Quranic passages can be found in Mathnawi.
- Some consider Mathnawi a kind of Sufi interpretation of the Quran.
- Rumi does mention Quran more frequently than others.
- Simnani (d. 1336) wrote two influential works of esoteric exegesis on the Quran.
- Simnani reconciled notions of God's manifestation through