# Swan Miara, Mansehra District

Swan Miara
- Swan Miara is a village.
- Swan Miara is a union council.
- Swan Miara is in Mansehra District.
- Swan Miara is in Khyber-Pakhtunkhwa province.
- Swan Miara is located south of the district.
- Swan Miara borders Abbottabad District.
- Swan Miara is an administrative subdivision.
- Swan Miara is an administrative subdivision.