# Vermont Lady Voltage Soccer

Vermont Lady Voltage
- Vermont Lady Voltage was a professional American women’s soccer team.
- The team was founded in 2005.
- The team is a member of the United Soccer Leagues W-League.
- Voltage played in the Northern Division of the Central Conference.
- They play their home games at the Collins-Perley Sports Complex.
- The Collins-Perley Sports Complex is in St. Albans, Vermont.
- St. Albans, Vermont is 27 miles north of Burlington.
- Burlington is the state's largest city.
- The team's colors are black and white, and gold and blue.
- The team was a sister organization of the Vermont Voltage team.
- The Vermont Voltage team plays in the USL Premier Development League.
- Jenny Benson was born on January 25, 1978.
- Jenny Benson was born in Fountain Valley, California.
- Jenny Benson is a retired American soccer midfielder/defender.
- Jenny Benson was a member of the United States women's national soccer team.