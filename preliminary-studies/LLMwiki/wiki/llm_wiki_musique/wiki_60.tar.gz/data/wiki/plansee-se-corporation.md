# Plansee SE Corporation

Plansee SE
- Plansee SE is a corporation.
- Plansee SE’s head office is in Reutte, Austria.
- Plansee SE is a fully owned division of the Plansee Group.
- Plansee SE is a privately owned company.
- Plansee SE manufactures products based on high-performance materials.
- These materials are made from refractory metals.
- Refractory metals include molybdenum, tungsten, tantalum, niobium, chromium and their alloys.
- Plansee SE’s products are used in the lighting sector.
- Plansee SE’s products are used in the electronics sector.
- Plansee SE’s products are used in the medical sector.
- Plansee SE’s products are used in the coatings sector.
- Plansee SE’s products are used in the energy transmission and distribution sector.
- Plansee SE’s products are used in the system and furnace construction sectors.