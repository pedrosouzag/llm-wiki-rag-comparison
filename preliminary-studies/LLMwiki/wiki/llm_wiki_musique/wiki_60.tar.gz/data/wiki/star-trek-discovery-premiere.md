# Star Trek: Discovery Premiere

Star Trek: Discovery premiered on September 19, 2017.
Star Trek: Discovery premiered at ArcLight Hollywood.
Star Trek: Discovery debuted on CBS and All Access on September 24.
The first season has 15 episodes.
The first season episodes are streaming weekly on All Access.
The series' release led to record subscriptions for All Access.
Critics highlighted Martin-Green's performance.
A second season was ordered in October 2017.
- Positive reviews from critics highlighted Martin-Green's performance.
- WCCO-TV is a CBS owned-and-operated television station.
- WCCO-TV is licensed to Minneapolis, Minnesota.
- WCCO-TV serves the Twin Cities television market.
- WCCO-TV is owned by the CBS Television Stations subsidiary of CBS Corporation.
- WCCO-TV's studios are located on South 11th Street along Nicollet Mall in downtown Minneapolis.
- WCCO-TV's transmitter is located at the Telefarm complex in Shoreview, Minnesota.