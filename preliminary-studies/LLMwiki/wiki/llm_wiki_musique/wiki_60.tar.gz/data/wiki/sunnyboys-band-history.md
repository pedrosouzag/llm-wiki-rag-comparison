# Sunnyboys Band History

Sunnyboys
- Sunnyboys first formed in 1979.
- Sunnyboys broke up in June 1984.
- Jeremy Oxley formed various incarnations of the band throughout the 1980s.
- Jeremy Oxley was the only original member in the band's incarnations.
- The original line-up reunited for a one-off show in 1998.
- The 1998 reunion was for the Mushroom 25 Concert.
- The original line-up reunited for a surprise show in 2012.
- The 2012 reunion was in Sydney.
- The 2012 reunion was part of the Dig It Up concert series.
- The 2012 reunion was billed as "Kids In Dust".
- The original line-up played sporadic shows in 2013.
- The original line-up continues to
- Jeremy Saxon Oxley was born in 1961.
- Jeremy Saxon Oxley was born in Kingscliff, New South Wales.
- Jeremy Saxon Oxley is a songwriter.
- Jeremy Saxon Oxley is a singer.
- Jeremy Saxon Oxley is a guitarist.
- Jeremy Saxon Oxley fronted the band Sunnyboys.