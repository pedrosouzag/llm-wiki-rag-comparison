# Thomas Nabbes Biography

Thomas Nabbes was born in Worcestershire.
Thomas Nabbes was educated at Exeter College, Oxford in 1621.
Thomas Nabbes left the university without taking a degree.
Thomas Nabbes began a career in London as a dramatist around 1630.
Thomas Nabbes was employed at some point in the household of a nobleman near Worcester.
Thomas Nabbes seemed to have been of a convivial disposition.
Thomas Nabbes had at least two children, Bridget and William.
Bridget died within two years of Thomas Nabbes' death.
William died within two years of Thomas Nabbes' death.
Thomas Nabbes, Bridget, and William were buried at St Giles in the Fields.
- François Ponsard was a French dramatist.
- François Ponsard was a poet.
- François Ponsard was an author.
- François Ponsard was a member of the Académie française.
- François Ponsard was born on 1 June 1814.
- François Ponsard died on 7 July 1867.