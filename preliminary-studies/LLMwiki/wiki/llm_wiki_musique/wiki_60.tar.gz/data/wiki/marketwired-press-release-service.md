# Marketwired Press Release Service

Marketwired
- Marketwired is a press release distribution service
- Marketwired is headquartered in Toronto, Ontario, Canada
- Marketwired was founded in 1993
- Marketwired was incorporated in the U.S. in 1999
- Marketwired distributes press releases via the Associated Press
- Marketwired distributes press releases via Bloomberg
- Marketwired distributes press releases via new media methods
- Marketwired distributes press releases via other services