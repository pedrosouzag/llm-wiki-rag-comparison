# Windjammer Cable Company

Windjammer Cable serves 80,000 customers.
Windjammer Cable serves rural areas.
Windjammer Communications formed Windjammer Cable.
Time Warner Cable acquired systems from Adelphia.
Adelphia was bankrupt.
MAST Capital Management is a Boston private-equity concern.
Communications Construction Services (CCS) is based in Jupiter, Fla.
Windjammer Cable was formed specifically for this deal.
Windjammer Cable consists of 25 systems.
Windjammer Communications is a small cable company.