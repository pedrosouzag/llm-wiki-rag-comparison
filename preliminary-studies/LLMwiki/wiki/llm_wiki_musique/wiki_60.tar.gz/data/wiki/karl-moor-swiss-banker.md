# Karl Moor (Swiss banker)

- Karl Moor was born on 11 December 1852 in Fribourg.
- Karl Moor died on 14 June 1932 in Berlin.
- Karl Moor was a Swiss communist.
- Karl Moor was a channel for German financing of the 19th-century European Bolshevik movement.
- Yosyf Zisels was a member of the Ukrainian Helsinki group (UHG).
- Yosyf Zisels was involved in the samizdat movement.
- Yosyf Zisels was a human rights activist.
- Yosyf Zisels was a prominent activist in the Jewish movement in Ukraine.
- Yosyf Zisels was a political prisoner.
- William Bross Lloyd was born on February 24, 1875.
- William Bross Lloyd died on June 30, 1946.
- William Bross Lloyd was an American attorney.
- William Bross Lloyd was a political activist.
- William Bross Lloyd was the son of Henry Demarest Lloyd and Jessie Bross.
- William Bross Lloyd was the son of William Bross.
- William Bross Lloyd was a founding member of the Communist Labor Party of America.
- William Bross Lloyd was a financial angel of the Communist Labor Party of America.
- William Bross Lloyd was a forerunner of the Communist Party USA.