# A Prisoner of Birth

- A Prisoner of Birth is a mystery novel.
- Jeffrey Archer is the author of A Prisoner of Birth.
- A Prisoner of Birth was first published on 6 March 2008.
- A Prisoner of Birth was published by Macmillan.
- A Prisoner of Birth is a retelling of "The Count of Monte Cristo" by Dumas.
- Archer returned to the first place in the fiction best-seller list for the first time in a decade.
- Cornelius Clifford places Athanasius of Alexandria’s birth no earlier than 296 and no later than 298.
- Athanasius indicates no first hand recollection of the Maximian persecution of 303.
- The Arians accused Athanasius of not having yet attained the canonical age (30).
- Athanasius could not have been properly ordained as Patriarch of Alexandria in 328.
- The Orthodox Church places his year of birth around 297.