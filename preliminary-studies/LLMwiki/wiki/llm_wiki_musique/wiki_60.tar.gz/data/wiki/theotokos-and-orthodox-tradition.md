# Theotokos and Orthodox Tradition

Mary, Mother of Jesus
- Orthodox Christianity has traditions regarding the Ever Virgin Mary.
- Orthodox Christians believe she was a virgin before and after Christ's birth.
- Theotokia are an essential part of the Divine Services in the Eastern Church.
- Theotokia are hymns to the Theotokos.
- The Theotokos is in the most prominent place after Christ in the liturgical sequence.
- The order of the saints in the Orthodox tradition begins with The Theotokos.
- The Theotokos has precedence over the angels.
- She is proclaimed as the "Lady of the Angels".