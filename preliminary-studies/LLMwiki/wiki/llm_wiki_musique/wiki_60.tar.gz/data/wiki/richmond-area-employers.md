# Richmond Area Employers

Richmond, Virginia
- Other Fortune 500 companies have a major presence in the area.
- SunTrust Bank is based in Atlanta.
- Capital One Financial Corporation is officially based in McLean, Virginia.
- Capital One was founded in Richmond.
- Capital One has its operations center in the Richmond area.
- Capital One has most of its employees in the Richmond area.
- McKesson is based in San Francisco.
- Capital One and Philip Morris USA are two of the largest private Richmond-area employers.
- DuPont maintains a production facility in South Richmond.
- The production facility is known as the Spruance Plant.
- UPS Freight has its corporate headquarters in Richmond.
- UPS Freight is the less-than-truckload division of UPS.
- UPS Freight was formerly known as Overnite Transportation.
- WKHK is a Country formatted broadcast radio station.
- WKHK is licensed to Colonial Heights, Virginia.
- WKHK serves Richmond and Petersburg in Virginia.
- WKHK is owned and operated by SummitMedia.
- WKHK's studios and offices are located west of Richmond proper in unincorporated Chesterfield County.
- WKHK's transmitter is located in Bensley, Virginia.