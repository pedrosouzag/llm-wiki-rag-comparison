# Philae Lander Mission

- The lander is named after the Philae obelisk.
- The Philae obelisk bears a bilingual inscription.
- The Philae obelisk was used to decipher Egyptian hieroglyphs.
- "Philae" was monitored from DLR's Lander Control Center in Cologne, Germany.
- Ulrich Walter was selected to join the German astronaut team in 1987.
- Ulrich Walter completed basic training at the German Aerospace Center from 1988 to 1990.
- Ulrich Walter was nominated to be in the prime crew for the second German Spacelab mission.
- Ulrich Walter held two post-doc positions at the Argonne National Laboratory, Chicago, Illinois.
- Ulrich Walter held a post-doc position at the University of California at Berkeley, California.