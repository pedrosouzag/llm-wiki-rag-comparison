# Ivanhoe, Sampson County

Ivanhoe, North Carolina
- Ivanhoe is a census-designated place.
- Ivanhoe is in Sampson County, North Carolina.
- Ivanhoe is in the United States.
- The population of Ivanhoe was 311 at the 2000 census.