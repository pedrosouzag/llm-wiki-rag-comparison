# Constance of Burgundy

Constance of Burgundy
- Constance of Burgundy was born on May 8, 1046.
- She was the daughter of Duke Robert I of Burgundy and Helie de Semur-en-Brionnais.
- She was Queen consort of Castile and León.
- She married Alfonso VI of León and Castile.
- She was the granddaughter of King Robert II of France.
- King Robert II of France was the second monarch of the French Capetian dynasty.
- She was the mother of Urraca of León.
- Urraca of León succeeded her father in both Castile and León.
- Childebrand I (678, Heristal - 751) was a Frankish duke.
- He was the son of Pepin of Heristal and Alpaida.
- He was the brother of Charles Martel.
- He married Emma of Austrasia.
- He was given Burgundy by his father.
- He distinguished himself in the expulsion of the Saracens from France.
- Maria de las Mercedes of Orléans was born on June 24, 1860.
- She died on June 26, 1878.
- She was Queen of Spain.
- She was the first wife of King Alfonso XII.
- Her father was Antoine of Orléans, Duke of Montpensier.
- Her mother was Infanta Luisa Fernanda of Spain.
- Sigrid Eskilsdotter (Banér) died in 1527.
- She was a Swedish noble.
- She was the mother of Christina Gyllenstierna.
- She was the maternal grandmother of King Gustav Vasa of Sweden.