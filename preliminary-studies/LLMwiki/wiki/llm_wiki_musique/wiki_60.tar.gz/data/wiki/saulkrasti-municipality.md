# Saulkrasti Municipality

Saulkrasti Municipality
- Saulkrasti Municipality is in Vidzeme, Latvia.
- The municipality was formed in 2009.
- The municipality was formed by reorganization of Saulkrasti town with its countryside territory.
- The administrative centre of the municipality is Saulkrasti.
- In 2010 Saulkrasti parish was created.
- Saulkrasti parish was created from the countryside territory of Saulkrasti town.
- Hylestad is in Aust-Agder county, Norway.
- Hylestad is in the southern part of the present-day municipality of Valle.
- Hylestad is in the traditional region of Setesdal.
- Hylestad existed from 1915 until 1962.
- The administrative centre was the village of Rysstad.
- The Hylestad Church was located in Rysstad.
- Saulkrasti Municipality () is a municipality in Vidzeme, Latvia.
- The municipality was formed in 2009 by reorganization of Saulkrasti town with its countryside territory, with the administrative centre being Saulkrasti.
- In 2010 Saulkrasti parish was created from the countryside territory of Saulkrasti town.
- Steinshamn is the administrative centre of Sandøy Municipality.
- Steinshamn is in Møre og Romsdal county, Norway.
- The village is located at the northern end of the island of Harøya.
- There is a causeway that connects Steinshamn to the neighboring island of Finnøya to the northeast.