# Amulya's Filmography

Amulya
- Her first film was "Khushi Khushiyagi" in 2015.
- She was paired opposite Ganesh for the third time in "Khushi Khushiyagi".
- Critics praised her performance as Nandini in "Khushi Khushiyagi".
- G. S. Kumar of "The Times of India" wrote about shades of 'Shravani Subramanya' in her role.
- In "Male", she played a tomboyish role as Varsha.
- She was paired opposite Prem Kumar in "Male".
- In "Ram-Leela", she played Chandrakala, the sister of a don.
- In "Ram-Leela", she played the love interest of Chiranjeevi Sarja.
- "Ram-Leela" received mixed response from critics.
- In "Maduveya Mamatheya Kareyole", she portrayed "a meaty character that