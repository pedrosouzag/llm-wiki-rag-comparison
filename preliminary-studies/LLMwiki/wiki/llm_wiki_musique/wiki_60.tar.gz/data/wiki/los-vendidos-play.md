# Los Vendidos Play

- Los Vendidos is a one-act play.
- Los Vendidos means The Sold Ones or The Sellouts in Spanish.
- Luis Valdez is a Chicano playwright.
- Luis Valdez is a founding member of El Teatro Campesino.
- The play was written in 1967.
- The play was first performed at the Brown Beret junta in Elysian Park, East Los Angeles.
- The play examines stereotypes of Latinos in California.
- The play examines how Latinos are treated by local, state, and federal governments.