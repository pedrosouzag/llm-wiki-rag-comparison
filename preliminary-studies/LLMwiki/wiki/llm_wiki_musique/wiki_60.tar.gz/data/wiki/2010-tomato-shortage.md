# 2010 Tomato Shortage

- The 2010 United States tomato shortage occurred between March and April 2010
- The shortage was caused by unseasonably cold weather in Florida in January 2010
- The cold weather destroyed 60-70% of Florida's tomato crop
- There was a tomato shortage over the new year holiday
- The new year shortage was caused by the Californian harvest finishing before the Florida harvest began