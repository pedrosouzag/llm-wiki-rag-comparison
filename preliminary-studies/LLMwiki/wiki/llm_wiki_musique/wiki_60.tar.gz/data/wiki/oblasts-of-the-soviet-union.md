# Oblasts of the Soviet Union

- Oblasts were second-level entities of the Soviet Union.
- Oblasts were first-level entities of the republics of the Soviet Union.
- Kis-Küküllő was an administrative county of the Kingdom of Hungary.
- Its territory is now in central Romania (central Transylvania).
- Kis-Küküllő is the Hungarian name for the Târnava Mică River.
- The capital of the county was "Dicsőszentmárton" (now Târnăveni).
- The oblasts of the Soviet Union were second-level entities of the Soviet Union.
- The oblasts of the Soviet Union were first-level entities of the republics of the Soviet Union.
- Motru Coal Mine is an open-pit mining exploitation.
- It is one of the largest in Romania.
- It is located in Motru, Gorj County.
- The legal entity managing the Motru mine is the National Company of Lignite Oltenia.
- The National Company of Lignite Oltenia was set up in 1997.