# Dust on the Bottle (single)

- Dust on the Bottle is a single by David Lee Murphy.
- It is from the album Out with a Bang B.
- The B-side is Mama 'n Them.
- It was released on August 7, 1995.
- It was released in the format of a cassette single.
- The genre is country, country rock.
- The length is 3:44.
- The label is MCA.
- David Lee Murphy is the songwriter.
- Tony Brown and David Lee Murphy are producers.
- It followed the single Party Crowd.
- It preceded the single Out with a Bang.