# Algeria as French Territory

French Algeria

- Shortly after the 1848 revolution, the Second Republic ended Algeria's status as a colony.
- The 1848 Constitution declared the occupied lands an integral part of France.
- Alger, Oran, and Constantine were organized as Departments of France.
- Departments of France were local administrative units.
- French citizens in the civil territories elected their own councils and mayors.
- Muslims could not hold more than one-third of council seats.
- Muslims could not serve as mayors or assistant mayors.
- The administration of territories outside the zones settled by colons remained under the French Army.
- Local Muslim administration was allowed to continue under the supervision of French Army commanders.
- French Army commanders were charged with maintaining order in newly pacified regions.
- The bureaux arabes supervised local Muslim administration.
- These areas were theoretically closed to European colonization.