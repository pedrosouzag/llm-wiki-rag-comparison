# Angelīna Kučvaļska Biography

Angelīna Kučvaļska
- Angelīna Kučvaļska was born on 6 December 1998
- Angelīna Kučvaļska was born in Saldus, Latvia
- Her father died when she was 12 years old
- She is a student at Riga 1st secondary school
- Bùi Bích Phương was born in 1971.
- Bùi Bích Phương was born in Hanoi.
- Bùi Bích Phương was crowned Miss Vietnam in 1988.
- Bùi Bích Phương was a first year English student at the University of Hanoi.
- Bùi Bích Phương was the first person ever to be crowned Miss Vietnam.
- Bùi Bích Phương was 17 years old when she won the title.
- Bùi Bích Phương is 5'2" tall.
- Bùi Bích Phương can speak fluent English, Korean and Vietnamese.
- Bùi Bích Phương is a successful business woman.
- Bùi
- Rachael Finch was born on 8 July 1988
- Rachael Finch is an Australian TV host
- Rachael Finch is an Australian model
- Rachael Finch was awarded the 'People's Choice Award' for the 2006 Miss Teen Australia
- Rachael Finch finished as 3rd runner-up at Miss Universe 2009