# Jean-Michel Oughourlian Biography

Jean-Michel Oughourlian
- Jean-Michel Oughourlian was born on 20 August 1940.
- He was born in Beirut, Lebanon.
- His father was Armenian.
- His father fled the 1915-1922 genocide.
- His mother was Colombian.
- He arrived in France at the age of ten.