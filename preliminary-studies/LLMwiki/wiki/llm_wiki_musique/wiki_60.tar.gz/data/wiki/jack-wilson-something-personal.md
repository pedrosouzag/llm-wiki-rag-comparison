# Jack Wilson - Something Personal

Something Personal
- It is an album by Jack Wilson
- Jack Wilson is an American jazz pianist
- It was recorded in 1967
- It was released on the Blue Note label
- It is an album by jazz trumpeter Freddie Hubbard
- It was recorded in 1971
- It features string arrangements by Don Sebesky
- It was his third album released on Creed Taylor's CTI label
- It features performances by Herbie Hancock
- It features performances by Eric Gale
- It features performances by George Benson
- It features performances by Ron Carter
- It features performances by Jack DeJohnette
- It features performances by Airto Moreira
- It features performances by Richard Wyands
- It is part of a loose trilogy including "Red Clay" and "Straight Life"
- It won a 1972 Grammy Award for "Best Jazz