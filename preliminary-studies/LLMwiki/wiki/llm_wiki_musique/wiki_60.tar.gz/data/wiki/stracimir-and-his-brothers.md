# Stracimir and His Brothers

Stracimir Zavidović
- In 1167/1168, Stracimir was expelled to Byzantium.
- Stracimir was a brother of Tihomir.
- Stracimir was a brother of Miroslav.
- Stracimir continued to rule his lands.
- Stracimir attacked the forces of Doclean ruler Mihailo.
- Stracimir and Miroslav attacked the forces of Doclean ruler and kinsman Mihailo.
- Catherine was born in Kraków.
- Catherine was the youngest daughter of King Sigismund I the Old of the Polish-Lithuanian Commonwealth and his wife Bona Sforza of Milan.
- Catherine became the spouse of King John III of Sweden.
- Catherine was the mother of Sigismund III Vasa, King of Poland.
- Catherine and her sisters Anna and Sophia moved to Masovia with their mother after the death of their father in 1548.
- Catherine and her sisters lived in Masovia alone after their mother's departure to Italy in 1558.
- Catherine's sisters were Anna and Sophia.
- Catherine's brother was