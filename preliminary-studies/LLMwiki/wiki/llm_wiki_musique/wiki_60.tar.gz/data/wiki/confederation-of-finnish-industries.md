# Confederation of Finnish Industries

Confederation of Finnish Industries
- It is the largest employers' association in Finland.
- It is known as EK.
- It was formed at the beginning of 2005.
- It formed from the merger of "Palvelutyönantajat" and "Teollisuuden ja Työnantajain Keskusliitto".
- Member companies contribute over 70% of Finland's GDP.
- Member companies contribute over 95% of Finland's exports.
- It has considerable negotiating power.
- Finland has universal validity of collective labour agreements.
- A national income policy agreement is often reached.