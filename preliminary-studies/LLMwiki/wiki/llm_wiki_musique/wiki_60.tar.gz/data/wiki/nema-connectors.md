# NEMA Connectors

- NEMA connectors are power plugs and receptacles
- NEMA connectors are used for AC mains electricity
- NEMA connectors are used in North America
- NEMA connectors are used in other countries
- Standards for NEMA connectors are set by the US National Electrical Manufacturers Association
- NEMA wiring devices are made in current ratings from 15 to 60 amperes (A)
- NEMA wiring devices are made in voltage ratings from 125 to 600 volts (V)
- Different combinations create non-interchangeable connectors
- Connectors are unique for each combination of voltage
- Connectors are unique for each combination of electric current carrying capacity
- Connectors are unique for each combination of grounding system.