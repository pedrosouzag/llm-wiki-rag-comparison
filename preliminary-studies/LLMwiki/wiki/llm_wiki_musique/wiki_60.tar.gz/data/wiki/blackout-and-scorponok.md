# Blackout and Scorponok

Transformers (film)
- Blackout attacks and destroys a United States military base in Qatar.
- Blackout's attempt is to hack the military network.
- The network search is for information on Megatron.
- The network search is also for the AllSpark.
- Captain William Lennox leads a team of Army Rangers.
- The team escapes across the desert.
- The team is pursued by Scorponok.
- Scorponok is a drone.
- Aerial reinforcements aid in fighting off Scorponok.
- Scorponok's armor is damaged by sabot rounds.
- John Keller is the Secretary of Defense.
- Keller leads the investigation into the attack.
- Maggie Madsen is a sound analyst.
- Frenzy is another Decepticon.
- Frenzy is hacking into the military network.
- Frenzy is onboard Air Force One.
- The hack is thwarted.
- Frenzy downloads files on Archibald
- Harlow Shapley stated in 1918 that the halo of globular clusters surrounding the Milky Way seemed to be centered on the star swarms in the constellation of Sagittarius.
- Dark molecular clouds in the area blocked the view for optical astronomers.
- Walter Baade at Mount Wilson Observatory took advantage of wartime blackout conditions in nearby Los Angeles.
- Baade conducted a search for the center with the 100 inch Hooker Telescope.
- Baade found a one - degree - wide void in the interstellar dust lanes near the star Alnasl (Gamma Sagittarii).
- The gap has been known as Baade's Window.