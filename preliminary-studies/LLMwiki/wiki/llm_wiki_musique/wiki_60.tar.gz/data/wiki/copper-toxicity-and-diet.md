# Copper Toxicity and Diet

Copper Toxicity
- Copper salts have been taken in suicide attempts.
- Copper salts produce acute copper toxicity in humans.
- Copper toxicity may be due to redox cycling.
- Copper toxicity may be due to the generation of reactive oxygen species.
- Copper toxicity damages DNA.
- 30 mg/kg of copper salts are toxic in animals.
- A minimum dietary value for healthy growth in rabbits is at least 3 ppm.
- Higher concentrations of copper (100 ppm) may favorably influence feed conversion efficiency.
- Higher concentrations of copper (200 ppm) may favorably influence growth rates.
- Higher concentrations of copper (500 ppm) may favorably influence carcass dressing percentages.