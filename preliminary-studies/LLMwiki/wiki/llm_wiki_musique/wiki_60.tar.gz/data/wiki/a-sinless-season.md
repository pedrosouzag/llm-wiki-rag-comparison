# A Sinless Season

A Sinless Season
- It is a novel by South African author Damon Galgut.
- It was published in 1982.
- The author was seventeen when it was published.
- It details the interactions between Scott, Raoul, and Joseph.
- Scott, Raoul, and Joseph are three young inmates at the Bleda reformatory.