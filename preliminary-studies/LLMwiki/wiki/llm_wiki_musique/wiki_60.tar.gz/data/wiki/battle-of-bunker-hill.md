# Battle of Bunker Hill

Battle of Bunker Hill
- Part of the American Revolutionary War
- Death of General Warren occurred at the Battle of Bunker Hill
- The Battle of Bunker Hill took place on June 17, 1775
- The location was Charlestown, Massachusetts
- Coordinates are 42° 22′ 34.9''N 71° 3′ 38.8'' W
- The result was a Pyrrhic British victory
- The British captured the Charlestown Peninsula
- Belligerents included the United Colonies
- Belligerents included Connecticut
- Belligerents included Massachusetts
- Belligerents included New Hampshire
- Belligerents included Rhode Island
- Belligerents included Great Britain
- Commanders and leaders included William Prescott
- Commanders and leaders included Israel Putnam
- Commanders and leaders included Joseph Warren
- Commanders and leaders included John Stark
- Commanders and leaders included William Howe
- Commanders and leaders