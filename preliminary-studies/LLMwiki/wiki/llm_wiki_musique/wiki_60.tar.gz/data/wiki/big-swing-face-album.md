# Big Swing Face (album)

Big Swing Face
- It is the eighth album by Bruce Hornsby.
- It was released by American singer and pianist Bruce Hornsby.
- It was Hornsby's first studio album with the Noisemakers.
- It was Hornsby's last album for RCA Records.
- It is the tenth studio album by Bruce Hornsby.
- It was Hornsby's third studio album with his touring band, Bruce Hornsby and the Noisemakers.
- It was his first release with Verve Records.