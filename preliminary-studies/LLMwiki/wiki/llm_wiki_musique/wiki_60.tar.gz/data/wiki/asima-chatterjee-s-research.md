# Asima Chatterjee's Research

Asima Chatterjee
- Asima Chatterjee (23 September 1917 – 22 November 2006)
- She was an Indian organic chemist.
- She was noted for her work in organic chemistry.
- She was noted for her work in phytomedicine.
- Her work includes research on vinca alkaloids.
- Her work includes the development of anti-epileptic drugs.
- Her work includes the development of anti-malarial drugs.
- She authored a considerable volume of work on medicinal plants of the Indian subcontinent.
- She was the first woman to receive a Doctorate of Science from an Indian university.
- Her most notable work includes research on vinca alkaloids.
- Her most notable work includes the development of anti-epileptic drugs.
- Her most notable work includes development of anti-malarial drugs.