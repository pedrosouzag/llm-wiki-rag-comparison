# Blood Stain Child

- Blood Stain Child is a Japanese heavy metal band.
- The band is from the city of Osaka.
- The band's musical style combines melodic death metal with electronic and trance.
- The band formed under the name "Visionquest" in 1999.
- The band changed their name to Blood Stain Child in 2000.
- Visionquest was stylised as "VISIONQUEST".
- BLOOD STAIN CHILD is a stylisation of the band's name.