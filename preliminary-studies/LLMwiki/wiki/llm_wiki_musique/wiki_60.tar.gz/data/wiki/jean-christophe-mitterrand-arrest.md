# Jean-Christophe Mitterrand Arrest

Jean-Christophe Mitterrand was freed on 11 January 2001.
Danielle Mitterrand posted a bail of 5 million francs (€762,000) to secure his release.
He was indicted again on July 4, 2001.
The charges against him were "complicity of arms traffic".
Magistrates Philippe Courroye and Isabelle Prévost-Desprez handled his case.
Alain Richard, the Socialist Minister of Defence, filed a complaint in January 2001.