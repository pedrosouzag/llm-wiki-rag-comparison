# Britney Spears - Radar Song

Radar (song)
- "Radar" is a song recorded by Britney Spears.
- It is for her fifth studio album, "Blackout" (2007).
- It was written and produced by Bloodshy & Avant and The Clutch.
- Henrik Jonback did additional writing.
- It was a record that did not relate to her personal problems at the time.
- The recording sessions took place the day after Spears filed for divorce from Kevin Federline.
- Members of The Clutch claimed to be surprised by her work ethic.
- "Radar" was originally planned to be released as the third single from "Blackout".
- "Break the Ice" was chosen instead of "Radar" as the third single.
- "Radar" was then planned as the fourth single.
- The release was cancelled as Spears began recording "Circus" (2008).
- "Radar" was later included as a bonus track on