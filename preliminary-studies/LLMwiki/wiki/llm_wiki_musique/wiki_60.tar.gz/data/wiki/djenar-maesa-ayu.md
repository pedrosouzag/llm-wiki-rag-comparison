# Djenar Maesa Ayu

Djenar Maesa Ayu was born on 14 January 1973.
Djenar Maesa Ayu was born in Jakarta, Indonesia.
Djenar Maesa Ayu is also known as Nay.
Djenar Maesa Ayu is an Indonesian novelist.
Djenar Maesa Ayu is a short story writer.
Djenar Maesa Ayu is an actress.
Djenar Maesa Ayu is a screenwriter.
Djenar Maesa Ayu is a filmmaker.
Djenar Maesa Ayu's work has been described as "provocative and lurid".
Djenar Maesa Ayu's work has been described as unique and brave.
Djenar Maesa Ayu is considered a member of the informal movement labeled sastra wangi.