# Sjernarøy (Municipality)

- Sjernarøy is a former municipality in Rogaland county, Norway.
- Sjernarøy existed from 1868 until 1965.
- Sjernarøy was located in the Boknafjorden.
- Sjernarøy was in the present-day municipality of Finnøy.
- The administrative centre was on the island of Kyrkjøy.
- The Sjernarøy Church is located on the island of Kyrkjøy.