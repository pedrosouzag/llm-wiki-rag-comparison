# Sant Martí d'Empúries

Sant Martí d'Empúries
- Sant Martí d'Empúries is an entity of the town of L'Escala.
- It is located next to the ruins of Empúries or Empòrion.
- Ancient Greeks established the settlement in the 6th century BC.
- It was the county seat until 1079.
- Empúries moved to Castelló d'Empúries in 1079.
- Empúries moved to Castelló d'Empúries place less exposed to attack.