# Door Creek, Wisconsin

Door Creek, Wisconsin
- Door Creek is also known as Buckeye.
- Door Creek is also known as Deer Creek.
- Door Creek is located in the town of Cottage Grove.
- Door Creek is located in Dane County.
- Door Creek is located in Wisconsin.
- Door Creek is an unincorporated community.
- Indian Heights is located on Lake Koshkonong.
- Indian Heights is located east-northeast of Edgerton.
- Indian Heights is located in the town of Albion.
- Indian Heights is located in the United States.
- The population of Dane was 968 at the 2000 census.
- The unincorporated community of Lutheran Hill is located partially in the town.