# Take It to the Limit

Take It to the Limit (Eagles song)
- The song was written by Randy Meisner, Don Henley and Glenn Frey.
- Randy Meisner sang lead on the song.
- Meisner says the song began as his solo composition.
- Henley and Frey assisted Meisner in completing the song.
- The song was to be included on the One of These Nights album.
- Meisner's performance of the song was popular with the audience in Eagles' concerts.
- Disputes over Meisner's reluctance to perform it would directly lead to Meisner's departure from the band.