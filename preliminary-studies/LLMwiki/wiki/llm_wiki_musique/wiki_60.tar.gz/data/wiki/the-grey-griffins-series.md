# The Grey Griffins Series

The Revenge of the Shadow King is the first volume of the Grey Griffins series.
The Grey Griffins series is written by Derek Benz and J.S. Lewis.
Derek Benz is an American author.
J.S. Lewis is an American author.
The Revenge of the Shadow King is published by Orchard Books.
Orchard Books is an imprint of Scholastic Inc.
Four friends form The Order of the Grey Griffin.