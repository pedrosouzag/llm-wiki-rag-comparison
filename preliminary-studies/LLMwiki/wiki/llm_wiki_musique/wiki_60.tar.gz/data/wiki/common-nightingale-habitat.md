# Common Nightingale Habitat

- The common nightingale is a migratory insectivorous species.
- It breeds in forest and scrub in Europe and south - west Asia.
- It winters in sub-Saharan Africa.
- It is not found naturally in the Americas.
- Its distribution is more southerly than the thrush nightingale Luscinia luscinia.
- It nests on or near the ground in dense vegetation.
- Research in Germany found that favoured breeding habitat of nightingales was defined by a number of geographical factors.