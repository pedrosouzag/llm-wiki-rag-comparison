# Bhanwar Singh Dangawas

* Bhanwar Singh Dangawas (7 June 1929 – 2 July 2012)
            * Was a member of the 14th Lok Sabha
            * Represented the Nagaur constituency
            * Was a member of the Bharatiya Janata Party (BJP) political party