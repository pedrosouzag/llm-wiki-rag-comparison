# Sołtan argument

Sołtan argument
- It is an astrophysical theory.
- It was outlined in 1982.
- It was outlined by Polish astronomer Andrzej Sołtan.
- It maintains that quasars were powered by accretion onto a supermassive black hole.
- It states that supermassive black holes must exist in our local universe.
- It calls these supermassive black holes "dead" quasars.