# Comanche and Texans Conflict

Comanche were known as the ``Lords of the Plains. ''
The Comanche occupied territory in the area.
The Comancheria was the most powerful entity.
The Comancheria was persistently hostile to the Spanish.
The Comancheria was persistently hostile to the Mexicans.
The Comancheria was persistently hostile to the Texans.
This article covers conflicts from 1820.
Mexico gained independence from Spain before 1820.
The last free band of Plains Indians, the Comanches, surrendered in 1875.
Quanah Parker was a Quahadi warrior.
The Comanches led by Quanah Parker moved to the Fort Sill reservation in Oklahoma.
- The Comanche were known as the ``Lords of the Plains. ''
- This article covers the conflicts from 1820, just before Mexico gained independence from
- The Basotho National Party is a political party in Lesotho.
- The Basotho National Party was founded in 1959 as the Basutoland National Party.
- Leabua Jonathan founded the Basotho National Party.
- Leabua Jonathan was Prime Minister from 1965 until the coup of 1986.
- Quahadi warrior Quanah Parker led the Comanches.
- The Comanches moved to the Fort Sill reservation in Oklahoma.
- The article covers the conflicts from 1820 until 1875.
- Mexico gained independence from Spain just before 1820.
- This article covers the conflicts from 1820 until 1875.