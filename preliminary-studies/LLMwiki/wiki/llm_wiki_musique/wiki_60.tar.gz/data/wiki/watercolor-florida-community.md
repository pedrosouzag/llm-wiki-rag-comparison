# Watercolor, Florida Community

WaterColor, Florida
- WaterColor is an unincorporated master-planned community.
- It is located in Seagrove Beach.
- It is located on the Northwest Gulf Coast of Florida.
- It is near Destin.
- It was planned by Cooper, Robertson & Partners.
- It was planned under the direction of The St. Joe Company.
- The St. Joe Company has owned the land since 1927.
- It is located in Walton County.
- Benson Junction is located in southwest Volusia County, Florida.
- Benson Junction is within the city limits of DeBary.
- It is the former location of the Ox Fibre Brush Company.
- It is presently an industrial location.
- It is located just west of U.S. Highway 17-92 (Charles Richard Beall Blvd.).
- It is located along Benson Junction Road.