# Homewood, South Carolina

Homewood, South Carolina
- Homewood is a small unincorporated community
- Homewood is in Horry County, South Carolina
- Homewood is just north of Conway
- Homewood is in the northeastern part of the state
- Homewood is at the junction of South Carolina Highway 319 and U.S. Highway 701
- There is an elementary school in the community
- Many inhabitants make a living from family farms
- They grow tobacco
- They grow corn
- They grow soybeans
- They grow tomatoes