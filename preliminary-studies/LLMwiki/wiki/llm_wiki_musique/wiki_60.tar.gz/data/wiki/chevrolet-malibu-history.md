# Chevrolet Malibu History

Chevrolet Malibu
- The Chevrolet Malibu is a mid-size car.
- It is manufactured and marketed by Chevrolet.
- It was manufactured from 1964 to 1983.
- It has been manufactured since 1997.
- The Malibu began as a trim level of the Chevrolet Chevelle.
- It became its own model line in 1978.
- Originally, it was a rear-wheel-drive intermediate.
- GM revived the Malibu nameplate in 1997.
- The revived Malibu was a front-wheel-drive car.
- Chevrolet has won 39 NASCAR Championship titles.
- Ford has won 15 NASCAR