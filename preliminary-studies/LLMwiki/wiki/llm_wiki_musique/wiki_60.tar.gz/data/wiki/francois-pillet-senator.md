# François Pillet, Senator

François Pillet
- François Pillet was born on 13 May 1950.
- François Pillet is a member of the Senate of France.
- François Pillet represents the Cher department.
- François Pillet is a member of the Union for a Popular Movement.
- Le calife de Bagdad ("The Caliph of Baghdad") is an "opéra comique" in one act by François-Adrien Boieldieu.
- Claude Godard d'Aucourt de Saint-Just wrote the libretto for Le calife de Bagdad.
- Le calife de Bagdad was first performed at the Opéra-Comique, Paris on 16 September 1800.
- Le calife de Bagdad became highly popular throughout Europe.
- It was Boieldieu's first major triumph.
- Luigi Cherubini reproached Boieldieu, "Aren't you ashamed of such a great success,
- "Un jour, un enfant" is one of four winning songs in the Eurovision Song Contest 1969.
- Frida Boccara sang "Un jour, un enfant" in French.
- Frida Boccara represented France with "Un jour, un enfant".
- Salomé represented Spain with "Vivo cantando".
- Lulu represented the United Kingdom with "Boom Bang-a-Bang".
- Lenny Kuhr represented the Netherlands with "De troubadour".
- Jean-Michel Boucheron was born on December 15, 1946 in Angoulême, Charente.
- Jean-Michel Boucheron is a French politician.
- Jean-Michel Boucheron was a member of the National Assembly of France (1978-1988).
- Jean-Michel Boucheron was mayor of Angoulême.
- Jean-Michel Boucheron was briefly Secretary of State for Local Authorities.
- Jean-Michel Boucheron represented a portion of the Charente department in the Assembly.
- Jean-Michel Boucheron is a member of the Socialist Party.