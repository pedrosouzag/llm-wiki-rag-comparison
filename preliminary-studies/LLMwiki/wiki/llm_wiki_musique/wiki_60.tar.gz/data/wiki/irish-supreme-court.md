# Irish Supreme Court

Supreme Court
- The Supreme Court is the highest court in Ireland.
- It has authority to interpret the constitution.
- It can strike down laws and activities of the state.
- It can find laws and activities of the state to be unconstitutional.
- It is the highest authority in the interpretation of the law.
- Its further appellate jurisdiction from lower courts is defined by law.
- The Irish Supreme Court consists of the Chief Justice and seven other judges.
- Judges of the Supreme Court are appointed by the President.
- Judges of the Supreme Court are appointed in accordance with the binding advice of the Government.
- The Supreme Court sits in the Four Courts in Dublin.