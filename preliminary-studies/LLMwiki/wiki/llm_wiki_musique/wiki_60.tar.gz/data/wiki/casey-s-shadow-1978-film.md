# Casey's Shadow (1978 film)

Casey's Shadow
- Casey's Shadow is a 1978 film.
- The film is a drama.
- The film is in Metrocolor.
- The film was directed by Martin Ritt.
- The film stars Walter Matthau.
- The film was based on a short story in "Ruidoso".
- "Ruidoso" was published on April 29, 1974.
- "Ruidoso" was published in The New Yorker magazine.
- The short story was written by John McPhee.
- Much of the exterior shots were done in Opelousas, LA.
- Opelousas, LA is 20 miles north of Lafayette, LA.