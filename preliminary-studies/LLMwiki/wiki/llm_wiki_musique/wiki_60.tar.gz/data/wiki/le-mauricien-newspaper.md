# Le Mauricien Newspaper

- Le Mauricien is a French-language newspaper.
- Le Mauricien is based and distributed in Mauritius.
- The newspaper was founded in 1908.
- The newspaper is released daily.
- Le Mauricien is one of the most read newspapers in Mauritius.
- The publishers are Le Mauricien Ltd.
- Le Mauricien Ltd. also publishes "Week-End".
- Le Mauricien Ltd. also publishes "Week-End Scope".
- Le Mauricien Ltd. also publishes "Turf Magazine".
- It is an independent newspaper.