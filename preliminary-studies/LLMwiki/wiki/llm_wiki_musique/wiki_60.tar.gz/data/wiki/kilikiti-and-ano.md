# Kilikiti and Ano

- Tuvalu is a country.
- Kilikiti is a sport played in Tuvalu.
- Kilikiti is similar to cricket.
- Ano is a sport specific to Tuvalu.
- Ano is played with two round balls.
- The balls used for Ano are 12 cm (5 in) in diameter.
- Ano is a localised version of volleyball.
- The balls used for Ano are made from pandanus leaves.
- Team members try to stop the Ano hitting the ground.
- Traditional sports in the late 19th century included foot racing.
- Traditional sports in the late 19th century included lance throwing.
- Traditional sports in the late 19th century included quarterstaff fencing.
- Traditional sports in the late 19th century included wrestling.
- Christian missionaries disapproved of traditional sports.