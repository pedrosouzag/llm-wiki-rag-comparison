# Iditarod Awards and Prizes

Iditarod Trail Sled Dog Race
- The ``Golden Harness '' is frequently given to the lead dog or dogs of the winning team.
- The ``Golden Harness '' is decided by a vote of the mushers.
- In 2008, the ``Golden Harness '' was given to Babe.
- Babe was the lead dog of Ramey Smyth.
- Ramey Smyth finished 3rd in the 2008 race.
- Babe was almost 11 years old when she finished the race.
- It was Babe's ninth Iditarod.
- The`` Rookie of the Year'' award is given to the musher who places the best among those finishing their first Iditarod.
- A red lantern signifying perseverance is awarded to the last musher to cross the finish line.
- The total purse for the 2013 race was US $600,000.
- The