# Darial, Pakistan Town

Darial, Pakistan
- Darial is a town in the Islamabad Capital Territory of Pakistan.
- It is located at 33° 23' 35N 73° 19' 45E.
- Its altitude is 494 metres.
- Its altitude is 1624 feet.