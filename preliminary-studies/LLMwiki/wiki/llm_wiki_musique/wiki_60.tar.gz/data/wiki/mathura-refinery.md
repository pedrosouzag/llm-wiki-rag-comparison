# Mathura Refinery

Mathura Refinery
- Mathura Refinery is one of the biggest oil refineries of Asia
- Mathura Refinery has 8.0 MMTPA refining capacity
- Mathura Refinery is an oil refinery of the Indian Oil Corporation
- Mathura Refinery is a highly technologically advanced oil refinery
- Mathura Refinery provides local employment opportunities
- Mathura Refinery is located in the city