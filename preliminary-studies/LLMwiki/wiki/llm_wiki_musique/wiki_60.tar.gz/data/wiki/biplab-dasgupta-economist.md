# Biplab Dasgupta (Economist)

Biplab Dasgupta
- Biplab Dasgupta (1938 – 17 July 2005) was a Marxian economist.
- He was a former member of Rajya Sabha.
- He was a member of the Bengal state committee of the CPI(M).
- He was the author of several books on the agrarian economy of India.
- Dilipkumar Mansukhlal Gandhi was born on 9 May 1951.
- He is an Indian politician.
- He is a member of the Bharatiya Janata Party (BJP) political party.
- He is a current member of the 16th Lok Sabha of India.