# File Time Stamps and Time Zones

Daylight Saving Time
- The text mentions Daylight Saving Time in relation to seasonal time.