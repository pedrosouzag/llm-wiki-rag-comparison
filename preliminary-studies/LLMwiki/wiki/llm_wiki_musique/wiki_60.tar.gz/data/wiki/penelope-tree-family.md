# Penelope Tree Family

Penelope Tree
- Penelope Tree is the only child of Ronald and Marietta Peabody Tree.
- Ronald was a British journalist, investor and Conservative MP.
- Marietta Peabody Tree was a U.S. socialite and political activist.
- She is the great-granddaughter of Marshall Field.
- She is the great-granddaughter of Endicott Peabody.
- She is the half-sister of Jeremy Tree.
- She is the half-sister of Frances FitzGerald.
- She is a niece of Endicott Peabody.