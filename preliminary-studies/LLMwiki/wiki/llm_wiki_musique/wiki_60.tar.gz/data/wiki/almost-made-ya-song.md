# Almost Made Ya Song

Almost Made Ya
- It is an R&B song by American duo Ali & Gipp
- It is on the album "Kinfolk" (2007)
- It samples Brandy's "Almost Doesn't Count"
- It is about a relationship between a female and a male
- LeToya sings that she is "almost done" with her man
- LeToya sings that "they" need to improve the relationship
- The men say about the situation they've been passing
- It leaked on April 13, 2007
- It was officially released on Sunday, June 13, 2007
- It was written by LeToya Luckett
- It was written by Jermaine Dupri
- It was written by Ali Vaskabi-Waski-Jones
- It was written by Cameron Gipp
- It was written by Shelly Peiken
- It was
- Kinfolk is the debut and only album by American rap duo Ali & Gipp
- It was released on August 14, 2007
- It was released through Derrty Entertainment and Universal Records
- "Go 'Head" featuring Chocolate Tai was the first single off the album
- "N da Paint" featuring Nelly is the second single
- "Work Dat, Twerk Dat" featuring Murphy Lee is the third single
- "Almost Made Ya" featuring LeToya Luckett is the fourth and final single
- "The Horse" is an American instrumental song by Cliff Nobles and Company.
- It was released as the B-side of the single "Love is All Right".
- It peaked at #2 on the US "Billboard" Hot 100 chart (in June 1968).
- It peaked at #2 on the US "Billboard" R&B chart.