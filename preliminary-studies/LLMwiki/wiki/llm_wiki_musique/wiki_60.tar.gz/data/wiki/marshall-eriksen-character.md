# Marshall Eriksen Character

Marshall Eriksen
- Marshall Eriksen is a How I Met Your Mother character.
- Jason Segel portrayed Marshall Eriksen in 2011.
- Marshall Eriksen first appeared in the ``Pilot'' episode.
- Marshall Eriksen's last appearance was in the ``Last Forever'' episode.
- Marshall Eriksen was created by Carter Bays and Craig Thomas.
- Marshall Eriksen's gender is male.
- Marshall Eriksen's occupation was Lawyer (2005 -- 2018).
- Marshall Eriksen's occupation is Judge (2018 --).
- Marshall Eriksen's father was Marvin Eriksen (deceased).
- Marshall Eriksen's mother is Judy Eriksen.
- Marshall Eriksen's spouse is Lily Aldrin (2007 -- present).
- Marshall Eriksen has a child named Marvin Waitforit Eriksen.
- Marshall Eriksen has