# Confederation of Regions Party

Confederation of Regions Party of Canada
- The Confederation of Regions Party (CoR) was a right-wing federal political party in Canada.
- It was founded in 1984 by Elmer Knutson.
- It was founded as a successor to the Western Canada Federation (West-Fed).
- West-Fed was a non-partisan organization.
- The CoR aimed to fight the Liberal Party of Canada.
- The CoR aimed to fill the void on the right of the political spectrum.
- The Social Credit Party of Canada declined.
- Westerners were growing unpopular with the Progressive Conservative Party of Canada under Brian Mulroney.
- Islamic Iran Solidarity Party (; "Hezb-e Hambastegi-e Iran-e Eslami") is an Iranian reformist political party.
- It was founded in 1998 by 10 members of Parliament of Iran.
- It is a member of Council for coordinating the Reforms Front.
- It publishes newspaper "Hambastegi".
- Ali Asghar Ahmadi is currently the General Secretary.
- Ebrahim Asgharzadeh previously held the office of General Secretary.
- Mohamadreza Raahchamani previously held the office of General Secretary.
- They have supported Mohammad Khatami in 2001 election.
- They have
- The Congress of the New Right (, Nowa Prawica or just KNP) is an economically libertarian, socially conservative and Eurosceptic political party in Poland.
- It was founded on 25 March 2011 by Janusz Korwin-Mikke.
- It was formed from the merger of the Liberty and Lawfulness (WiP) with several members of the Real Politics Union (UPR).
- Janusz Korwin-Mikke was ousted from the party in 2015.
- The party assumed the official name Congress of the New Right on 12 May 2011.