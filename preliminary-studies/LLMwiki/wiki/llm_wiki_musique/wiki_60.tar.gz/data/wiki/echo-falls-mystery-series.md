# Echo Falls Mystery Series

- Down The Rabbit Hole is the first book in the Echo Falls mystery series.
- Peter Abrahams is the author of Down The Rabbit Hole.
- Ingrid is in the wrong place at the wrong time.
- Ingrid's shoes are in the wrong place at the wrong time.
- Getting Ingrid's shoes back will mean getting tangled up in a murder investigation.
- The murder investigation is complicated.
- Sherlock Holmes is Ingrid's idol.
- Ingrid has soccer practice.
- Ingrid has schoolwork.
- Ingrid has the lead role in her town's production of Alice in Wonderland.
- Ingrid realizes she must solve the murder on her own.
- Things in Echo Falls keep getting curiouser and curiouser.