# The Key to the Golden Firebird

The Key to the Golden Firebird is a novel by Maureen Johnson.
Maureen Johnson is a young adult author.
The book was first published in 2004.
The American Library Association listed it as a Best Books for Young Adults in 2005.
- The Shadow of Saganami is a science fiction novel.
- David Weber is an American writer.
- The book was published in 2004.
- It is set in the Honorverse.
- It has been billed as the first in the "Saganami Island" series.
- The book is spun off from the main Honor Harrington series.
- The book debuted at #16 on "The New York Times" best seller list for hardcover fiction.