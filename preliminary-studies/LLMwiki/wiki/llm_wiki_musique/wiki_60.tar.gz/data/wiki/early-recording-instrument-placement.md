# Early Recording Instrument Placement

Phonograph Record
- Drums could be effectively used and heard on early jazz and military band recordings if placed properly
- The loudest instruments, such as drums and trumpets, were positioned farthest from the collecting horn
- Lillian Hardin Armstrong was a member of King Oliver's Creole Jazz Band
- King Oliver's Creole Jazz Band recorded at Gennett Records in 1923
- Louis Armstrong was a young second trumpet in King Oliver's Creole Jazz Band
- Initially, Oliver and Louis Armstrong stood next to each other and Oliver's horn could not be heard
- Louis Armstrong was placed fifteen feet away in the corner
- Some performers were placed on a moveable platform
- A moveable platform could draw performers nearer or further away as required