# Peter Blum, Afrikaans Poet

Peter Emil Julius Blum
- Peter Emil Julius Blum was born on 4 May 1925.
- Peter Emil Julius Blum was born in Trieste, Kingdom of Italy.
- Peter Emil Julius Blum died on 5 December 1990.
- Peter Emil Julius Blum died in London, England, UK.
- Peter Emil Julius Blum was an Afrikaans poet.
- Peter Emil Julius Blum emigrated to the Union of South Africa with his family as a child.
- Peter Emil Julius Blum was able to speak several languages from an early age.
- Peter Emil Julius Blum spoke German.
- Peter Emil Julius Blum spoke Italian.
- Johan Ludvig Heiberg was born on 14 December 1791.
- Johan Ludvig Heiberg was born in Copenhagen.
- Johan Ludvig Heiberg was a Danish poet.
- Johan Ludvig Heiberg was a playwright.
- Johan Ludvig Heiberg was a literary critic.
- Johan Ludvig Heiberg was a literary historian.
- Johan Ludvig Heiberg died on 25 August 1860.
- Johan Ludvig Heiberg promoted Hegelian philosophy.
- Johan Ludvig Heiberg introduced vaudeville to Denmark.
- Johan Ludvig Heiberg was the son of Peter Andreas Heiberg.
- Johan Ludvig Heiberg was the son