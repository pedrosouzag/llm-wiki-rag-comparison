# GeminiJets Model Airplanes

GeminiJets
- GeminiJets is a diecast model airplane manufacturer
- GeminiJets is based in Las Vegas, Nevada, United States
- GeminiJets was founded in 1998
- GeminiJets was originally named SkyJets
- ADI (Airliners Distributing Inc.) is the founding company
- ADI holds production licenses from Boeing
- ADI holds production licenses from Airbus
- ADI holds production licenses from McDonnell Douglas
- ADI holds production licenses from Embraer
- ADI makes and markets aircraft in several different scales