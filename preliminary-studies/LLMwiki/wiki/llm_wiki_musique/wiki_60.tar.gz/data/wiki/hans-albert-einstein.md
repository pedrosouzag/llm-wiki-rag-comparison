# Hans Albert Einstein

Hans Albert Einstein
- Hans Albert Einstein was born on May 14, 1904.
- Hans Albert Einstein died on July 26, 1973.
- Hans Albert Einstein was the second child of Albert Einstein and Mileva Marić.
- Hans Albert Einstein was the first son of Albert Einstein and Mileva Marić.
- Hans Albert Einstein was a Swiss-American engineer.
- Hans Albert Einstein was an educator.
- Hans Albert Einstein was a long-time professor of Hydraulic Engineering at the University of California, Berkeley.
- Barry Onouye is a structural engineer.
- Barry Onouye is an author of multiple textbooks on structural engineering and design.
- Barry Onouye is an emeritus faculty member in the Department of Architecture at the University of Washington.