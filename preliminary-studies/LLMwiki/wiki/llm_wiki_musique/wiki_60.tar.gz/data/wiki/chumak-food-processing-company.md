# Chumak Food Processing Company

Chumak (company)
- Chumak is a Swedish-Ukrainian food processing company.
- It is located in Kakhovka, Kherson Oblast.
- It is one of Ukraine's biggest food processing companies.
- It has commercial offices in Kiev.
- It has commercial offices in Minsk.
- It has commercial offices in Moscow.
- Its products include ketchup.
- Its products include mayonnaise.
- Its products include pasta.
- Its products include salad dressings.
- Its products include cooking sauces.
- Its products include canned vegetables.
- Its products include marinated vegetables.
- Its products include tomato juice.
- Its products include sunflower oil.
- Chumak is the largest tomato processing company in Central and Eastern Europe.
- The company employs about 1200 people (2010).
- The company has a revenue of about 48 million Euros (2010).