# Def Squad rap group

Def Squad
- Def Squad is a rap supergroup.
- It consists of Erick Sermon, Redman and Keith Murray.
- Jamal is an honorary member of the Def Squad.
- They had each been featured on tracks by each other before forming as a group.
- The Def Squad was formed following the disbandment of the Hit Squad.
- The Hit Squad broke up after struggles between EPMD members Erick Sermon and Parrish Smith.