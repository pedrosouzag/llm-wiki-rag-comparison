# Kris Benson Career

- Kris Benson was drafted first overall by the Pittsburgh Pirates in 1996.
- Benson had a strong rookie season in 1999.
- Benson had an even stronger season in 2000.
- Benson underwent Tommy John surgery after the 2000 season.
- Benson posted three more good seasons from 2004 to 2006.
- Benson played for the Pittsburgh Pirates, the New York Mets, and the Baltimore Orioles.
- Benson underwent rotator cuff surgery.
- Benson was never again an effective Major League pitcher after rotator cuff surgery.