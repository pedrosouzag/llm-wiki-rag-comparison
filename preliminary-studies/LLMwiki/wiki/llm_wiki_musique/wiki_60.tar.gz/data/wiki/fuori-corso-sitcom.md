# Fuori corso sitcom

Fuori corso
- Fuori corso was an Italian sitcom
- It was written by Vincenzo Coppola
- It was written by Ciro Ceruti
- It was written by Ciro Villano
- Ciro Ceruti and Ciro Villano starred in the comedy.