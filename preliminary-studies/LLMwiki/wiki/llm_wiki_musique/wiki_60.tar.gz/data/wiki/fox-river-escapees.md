# Fox River Escapees

Prison Break Season 2
- The season begins eight hours after the escape.
- Paul Scheuring describes the second season as "The Fugitive times eight."
- The season is likened to the "second half of The Great Escape."
- The eight escapees split up and journey across the country.
- Brad Bellick gets fired from the prison.
- Brad Bellick chases after the inmates for the reward money.
- Charles Westmoreland buried a large cache of money long ago.
- Alexander Mahone is assigned to track down the eight fugitives.
- Alexander Mahone is working for The Company.
- The Company wants all eight men dead.
- Governor Frank Tancredi has been killed.
- Sara remains with Michael.
- The brothers try to bring down now-President Reynolds.
- Sara allows herself to be arrested and faces trial.
- Paul Kellerman's testimony exonerates Lincoln and Sara.
- Half of