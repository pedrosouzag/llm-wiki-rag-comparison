# Gmina Włodawa

Gmina Włodawa
- Gmina Włodawa is a rural gmina
- Gmina Włodawa is in Włodawa County
- Gmina Włodawa is in Lublin Voivodeship
- Gmina Włodawa is in eastern Poland
- Gmina Włodawa is on the border with Belarus
- Gmina Włodawa is on the border with Ukraine
- The seat of Gmina Włodawa is the town of Włodawa
- The town of Włodawa is not part of the territory of the gmina.
- The seat of Gmina Włodawa is the town of Włodawa, although the town is not part of the territory of the gmina.
- Kis-Küküllő was an administrative county of the Kingdom of Hungary.
- Kis-Küküllő is in central Romania.
- Kis-Küküllő is in central Transylvania.
- Kis-Küküllő is the Hungarian name for the Târnava Mică River.
- The capital of the county was "Dicsőszentmárton" (now Târnăveni).
- Gmina Włodawa is a rural gmina (administrative district)
- Its seat is the town of Włodawa, although the town is not part of the territory of the gmina.