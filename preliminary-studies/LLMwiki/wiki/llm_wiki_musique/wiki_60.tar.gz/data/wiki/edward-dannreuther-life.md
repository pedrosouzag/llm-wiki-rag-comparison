# Edward Dannreuther: Life

Edward George Dannreuther was born on 4 November 1844 in Strasbourg.
Edward George Dannreuther died on 12 February 1905 in Hastings.
Edward George Dannreuther was a German pianist.
Edward George Dannreuther was a writer on music.
Edward George Dannreuther resided in England from 1863.
Edward George Dannreuther’s father established a piano manufacturing business in Cincinnati.
Edward George Dannreuther’s father had crossed the Atlantic.
Edward George Dannreuther went to Leipzig in 1859.
Edward George Dannreuther’s father wanted him to enter banking as a career.
Edward George Dannreuther found the prospect of banking uncongenial.