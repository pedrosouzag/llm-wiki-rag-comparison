# The Bruce Lee Band

Bruce Lee Band is also known as B. Lee Band.
The Bruce Lee Band includes Mike Park and his backing band.
The backing band has included Less Than Jake.
The backing band has included the Rx Bandits.