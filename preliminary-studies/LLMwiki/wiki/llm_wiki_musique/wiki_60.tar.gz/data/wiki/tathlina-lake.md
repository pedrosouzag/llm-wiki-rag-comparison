# Tathlina Lake

- Tathlina Lake is a large lake
- Tathlina Lake is a shallow lake
- Tathlina Lake is located in the Northwest Territories, Canada
- An outcropping of the Kakisa Formation occurs along the side of Tathlina Lake
- Kakisa Lake is fed by the Kakisa River
- Kakisa Lake is near the community of Kakisa