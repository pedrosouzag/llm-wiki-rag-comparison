# Nizampatnam Mandal, Guntur District

- Nizampatnam mandal is one of the 57 mandals in Guntur district.
- Nizampatnam mandal is in the state of Andhra Pradesh, India.
- It is under the administration of Tenali Revenue Division.
- The headquarters are located at Nizampatnam.
- The mandal is bounded by Repalle mandals.
- The mandal is bounded by Nagaram mandals.
- The mandal is bounded by Pittalavanipalem mandals.
- The mandal is bounded by Karlapalem mandals.
- The mandal lies on the shore of Bay of Bengal.
- A portion of the mandal lies on the banks of Krishna River.