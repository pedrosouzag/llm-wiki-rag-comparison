# Chicago - All the Years Song

All the Years is a song
All the Years was recorded by the rock band Chicago
All the Years was released on the 2008 album Stone of Sisyphus
It was written by Robert Lamm
It was written by Bruce Gaitsch
Bruce Gaitsch is a studio session musician
Bruce Gaitsch was the guitarist from the "Night & Day Big Band" album