# The Learning Company

The Learning Company was owned by Houghton Mifflin Harcourt.
The Learning Company produced a grade-based system of learning software.
The Learning Company produced tools to improve productivity.
Products for preschoolers through second graders included "Reader Rabbit".
Software for more advanced students included "The ClueFinders".
The Learning Company published licensed educational titles featuring Arthur.
The Learning Company published licensed educational titles featuring Scooby-Doo.
The Learning Company published licensed educational titles featuring "Zoboomafoo".
The Learning Company published licensed educational titles featuring "Caillou".