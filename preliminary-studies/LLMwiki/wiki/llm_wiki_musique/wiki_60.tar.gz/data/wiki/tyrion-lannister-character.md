# Tyrion Lannister Character

Tyrion Lannister
- Tyrion Lannister is a character in A Song of Ice and Fire.
- Tyrion Lannister is a character in Game of Thrones.
- Peter Dinklage portrays Tyrion in Game of Thrones.
- Tyrion first appeared in the novel A Game of Thrones (1996).
- Tyrion first appeared in the television show ``Winter Is Coming`` (2011).
- Tyrion first appeared in the video game ``Iron From Ice`` (2014).
- Tyrion was created by George R.R. Martin.
- Peter Dinklage voices Tyrion in the video game.
- Tyrion is nicknamed The Imp.
- Tyrion is nicknamed The Halfman.
- Tyrion is nicknamed Yollo.
- Tyrion is nicknamed Hugor Hill.
- Tyrion is male.
- Tyrion's title is Hand of the King.
- Tyrion'
- Don Draper is a character in Mad Men.
- Jon Hamm portrays Don Draper.
- Don Draper first appeared in ``Smoke Gets in Your Eyes`` (1.01).
- Don Draper last appeared in ``Person to Person`` (7.14).
- Don Draper was created by Matthew Weiner.
- Don Draper's full name is Donald Francis Draper.
- Don Draper's nickname is Don.
- Don Draper's nickname is Dick.
- Don Draper's alias is Richard Whitman (birth name).
- Don Draper is a Senior Partner and Creative Director at Sterling Cooper & Partners.
- Don Draper is a Founding Partner at Sterling Cooper Draper Pryce.
- Don Draper