# The Haves and Have Nots

The Haves and the Have Nots is a soap opera.
The Haves and the Have Nots is a crime thriller.
The Haves and the Have Nots was created by Tyler Perry.
The Haves and the Have Nots was written by Tyler Perry.
The Haves and the Have Nots was directed by Tyler Perry.
The Haves and the Have Nots stars Tika Sumpter.
The Haves and the Have Nots stars Crystal Fox.
The Haves and the Have Nots stars Tyler Lepley.
The Haves and the Have Nots stars Renee Lawless.
The Haves and the Have Nots stars Aaron O'Connell.
The Haves and the Have Nots stars Peter Parros.
The Haves and the Have Nots stars Angela Robinson.
The Haves and the Have Nots stars Gavin Houston.
The Haves and the Have Nots stars Eva Tamargo.
- The Young and the Restless is an American television soap opera.
- The Young and the Restless was created by William J. Bell and Lee Phillip Bell.
- The Young and the Restless first aired on March 26, 1973.
- Doug Davidson portrays private investigator Paul Williams.
- Doug Davidson has portrayed Paul Williams since May 23, 1978.
- Jeanne Cooper portrayed Katherine Chancellor.
- Jeanne Cooper portrayed Katherine Chancellor from November 1973 until her death in May 2013.
- Melody Thomas Scott portrays Nikki Newman.
- Eric Braeden portrays Victor Newman.
- Melody Thomas Scott joined in February 197