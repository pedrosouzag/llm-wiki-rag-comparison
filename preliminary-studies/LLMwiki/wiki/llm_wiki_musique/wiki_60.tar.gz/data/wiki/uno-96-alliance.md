# UNO-96 Alliance

- UNO-96 Alliance was a center-right Nicaraguan political party
- UNO-96 Alliance was founded in 1996
- Alfredo César Aguirre founded UNO-96 Alliance
- Alfredo César Aguirre was a member of the National Opposition Union
- Alfredo César Aguirre was a campaign advisor to Violeta Barrios de Chamorro
- UNO-96 Alliance obtained a seat in the National Assembly in the 1996 Nicaraguan general elections