# Italian Eritrea's Industrial Center

Eritrea
- In 1922, Benito Mussolini's rise to power in Italy brought profound changes to the colonial government in Italian Eritrea.
- In May 1936, Benito Mussolini declared the birth of the Italian Empire.
- Italian Eritrea was enlarged with northern Ethiopia's regions.
- Italian Eritrea and Italian Somaliland were merged with Ethiopia.
- The merger created the new Italian East Africa administrative territory.
- The Fascist period was characterized by imperial expansion.
- The Fascist period was in the name of a "new Roman Empire".
- The Italian government chose Eritrea to be the industrial center of Italian East Africa.
- After "il Duce" declared the birth of Italian Empire in May 1936, Italian Eritrea (enlarged with northern Ethiopia's regions) and Italian Somaliland were merged with the just conquered Ethiopia in the new Italian East Africa ("Africa Orientale Italiana") administrative territory.
- This Fascist period was characterized by imperial expansion in the name of a "new Roman Empire".
- Benito Mussolini's rise to power in Italy in 1922 brought profound changes to the colonial government in Eritrea.
- Eritrea was chosen by the Italian government to be the industrial center of Italian East Africa.