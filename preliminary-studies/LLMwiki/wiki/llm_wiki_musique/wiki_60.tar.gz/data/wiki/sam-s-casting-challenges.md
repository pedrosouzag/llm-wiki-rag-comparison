# Sam's Casting Challenges

Casablanca (film)
* Dooley Wilson played Sam.
* Dooley Wilson was one of the few American-born members of the cast.
* Dooley Wilson had to fake playing the piano.
* Wallis considered dubbing over Dooley Wilson's voice for the songs.
* Wallis considered changing the character to a woman.
* Wallis considered casting Hazel Scott.
* Wallis considered casting Lena Horne.
* Wallis considered casting Ella Fitzgerald.