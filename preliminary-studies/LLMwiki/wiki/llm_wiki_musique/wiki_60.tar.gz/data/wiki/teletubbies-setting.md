# Teletubbies setting

Teletubbies
- The programme takes place in a grassy, floral landscape.
- Rabbits populate the landscape.
- Bird calls are audible in the background.
- The main shelter of the four Teletubbies is an earth house.
- The earth house is known as the ``Tubbytronic Superdome''.
- The Tubbytronic Superdome is implanted in the ground.
- The Tubbytronic Superdome is accessed through a hole at the top.
- The Tubbytronic Superdome is accessed through a semicircular door at the dome's foot.
- The Teletubbies co-exist with strange contraptions.
- The Noo-noo is an anthropomorphic blue vacuum cleaner.
- The Noo-noo is the group's vacuum cleaner.
- The show has Voice Trumpets.
- The setting was designed to appeal to the attention spans of infants.
- The setting was designed