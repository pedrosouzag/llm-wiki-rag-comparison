# Pettai Village, Karaikal

Pettai
- Pettai is a panchayat village.
- Pettai is a revenue village.
- Pettai is in Pondicherry Union Territory, India.
- Pettai is under the Thirunallar Taluk.
- Pettai was formerly under the Thirunallar Commune Panchayat.
- Pettai is in Karaikal District, Pondicherry Union Territory.
- Pettai is situated on the banks of the Arasalar River.
- Pettai is to the west of Karaikal town.
- Pettai is south of Thirunallar.