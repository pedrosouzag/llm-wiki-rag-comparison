# Alamnagar (community development block)

Alamnagar (community development block)
- Alamnagar is an administrative division of Madhepura district.
- Alamnagar is in the Indian state of Bihar.
- The block headquarters are located 58 km from Madhepura.
- The name of Alamnagar is named for Shah Alamgir.
- The block headquarters are located at a distance of 58 km from the district headquarters, namely, Madhepura.
- The block headquarters are located at a distance of 58 km from the district headquarters, namely, Madhepura.
- Alamnagar (community development block) is one of the administrative divisions of Madhepura district in the Indian state of Bihar.