# Catalan and Romance Languages

Catalan language
- Catalan shares many traits with its neighboring Romance languages.
- Catalan is mostly situated in the Iberian Peninsula.
- Catalan differs from Iberian Romance in terms of vocabulary.
- Catalan differs from Iberian Romance in terms of pronunciation.
- Catalan differs from Iberian Romance in terms of grammar.
- Catalan differs more from Iberian Romance than from Gallo-Romance.
- These similarities are most notable with Occitan.
- The ascription of Catalan to the Occitano-Romance branch of Gallo-Romance languages is not shared by all linguists and philologists.
- Ramón Menéndez Pidal is a Spanish linguist and philologist who does not share this ascription.
- Victim of Romance is singer and songwriter Michelle Phillips' first and only solo album.
- Victim of Romance was released in February 1977.
- The record was unsuccessful.
- Michelle Phillips was previously with The Mamas & the Papas.
- The front cover photography was by Terry O'Neill.