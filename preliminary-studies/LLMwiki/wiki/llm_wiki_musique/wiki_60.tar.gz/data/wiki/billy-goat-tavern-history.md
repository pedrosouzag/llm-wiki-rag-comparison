# Billy Goat Tavern History

Billy Goat Tavern
- The first location opened in 1934.
- William ``Billy Goat ''Sianis bought the Lincoln Tavern.
- William ``Billy Goat ''Sianis bought the Lincoln Tavern for $205.
- He made good on a bounced check with the proceeds from the first weekend.
- The Lincoln Tavern was near Chicago Stadium.
- He posted a sign saying ``No Republicans allowed'' during the 1944 Republican National Convention.
- The place was packed with Republicans demanding to be served.
- Sianis took advantage of the publicity.