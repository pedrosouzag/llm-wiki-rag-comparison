# Utah State Route 264

State Route 264 connects Sanpete County to Carbon County.
State Route 264 runs through Flat Canyon.
State Route 264 runs through Boulger Canyon.
State Route 264 runs through Upper Huntington Canyon.
State Route 264 runs through Eccles Canyon.
State Route 264 is part of The Energy Loop.
State Route 264 is a state highway.
State Route 264 is in central Utah.
The Energy Loop is a National Scenic Byway.