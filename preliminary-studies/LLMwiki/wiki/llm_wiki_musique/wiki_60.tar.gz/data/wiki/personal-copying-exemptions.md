# Personal Copying Exemptions

Copyright Infringement

- Some countries require content being copied to be obtained legitimately.
- The personal copying exemption in some countries requires content to be from authorized sources.
- The Netherlands previously allowed copying from file-sharing networks.
- The Dutch government had assumed the personal copying exemption applied to any copying, even from file-sharing networks.
- In April 2014, the Court of Justice of the European Union ruled against legislation that made no distinction between lawful and unlawful sources.
- Downloading from file-sharing networks is no longer legal in the Netherlands.