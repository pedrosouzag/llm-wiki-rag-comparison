# Billy Joel - Don't Ask Me Why

- "Don't Ask Me Why" is a Billy Joel song.
- "Don't Ask Me Why" was released in 1980.
- The track contains acoustic and Latin percussion instruments.
- The instruments perform in an Afro-Cuban rhythmic style.
- The song features an instrumental "Latin Ballroom" piano solo.
- The piano solo is played over the bridge section after the second verse.
- Joel overdubbed fifteen pianos on top of each other in the midsection.
- The song spent two weeks at number one on the Adult Contemporary chart.
- The song peaked at number nineteen on the "Billboard" Hot 100.
- "Brown Eyed Girl" is a song by Northern Irish singer and songwriter Van Morrison.
- Written by Morrison and recorded in March 1967 for Bang Records owner and producer Bert Berns.
- It was released as a single in June 1967 on the Bang label.
- It featured the Sweet Inspirations singing back-up vocals.
- It has remained a staple on classic rock radio.
- It has been covered by hundreds of bands over the decades.