# Pangi Territory

- Pangi Territory is in Maniema Province.
- Pangi Territory is an administrative area.
- The headquarters of Pangi Territory is the town of Pangi.
- Pangi Territory is in the Democratic Republic of the Congo.
- Swan Miara is a village.
- Swan Miara is a union council.
- Swan Miara is in Mansehra District.
- Swan Miara is in Khyber-Pakhtunkhwa province.
- Swan Miara borders Abbottabad District.
- It is located south of the district.
- Pangi Territory is an administrative area in Maniema Province of the Democratic Republic of the Congo.
- The headquarters is the town of Pangi.
- Kiri Territory is an administrative region.
- Kiri Territory is in the Mai-Ndombe District.
- Kiri Territory is in Bandundu Province.
- The headquarters of Kiri Territory is the town of Kiri.