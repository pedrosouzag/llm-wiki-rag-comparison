# Love and War in the Apennines

Love and War in the Apennines
- It is a 1971 memoir.
- It is a Second World War memoir.
- It has some changes of names and people and places.
- It has some composite characters.
- It was dramatised as the 2001 film "In Love and War".
- The film "In Love and War" starred Callum Blue.
- The film "In Love and War" starred Barbora Bobuľová.
- It was written by Eric Newby.
- Trevor Stamp was the son of Josiah Stamp, 1st Baron Stamp.
- He succeeded his brother and father as Baron Stamp when they were killed during the war by German bombing.
- He was a member of the Liberal Party in the House of Lords but later became a cross-bencher.