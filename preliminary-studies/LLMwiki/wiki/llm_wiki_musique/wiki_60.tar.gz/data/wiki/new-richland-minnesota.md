# New Richland, Minnesota

New Richland, Minnesota
- New Richland is a city in Waseca County, Minnesota, United States.
- The city was founded in 1877.
- The population was 1,203 at the 2010 census.
- New Richland is located in rural south-central Minnesota.
- New Richland is a small town with a strong agricultural base.
- In 2013, the NRHEG High School Women's Basketball team won the State Tournament.
- Emmaville is an unincorporated community in Hubbard County, Minnesota, United States.
- Emmaville is located half way between Park Rapids and Lake George.
- Emmaville is located at the junction of Hubbard County Roads 4 and 24.
- Emmaville is located within Clay Township and Lake Emma Township.
- Population estimates have been listed between 4 and 29.