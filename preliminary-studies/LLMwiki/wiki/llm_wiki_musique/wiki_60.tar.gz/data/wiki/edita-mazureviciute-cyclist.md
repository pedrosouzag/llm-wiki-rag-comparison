# Edita Mazurevičiūtė (cyclist)

Edita Mazurevičiūtė
- Edita Mazurevičiūtė was born on 10 January 1996.
- Edita Mazurevičiūtė is a track cyclist from Lithuania.
- She represented Lithuania at the 2015 UCI Track Cycling World Championships.