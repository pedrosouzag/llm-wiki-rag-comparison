# Mart Stam's New Objectivity

Mart Stam
- His style of design has been classified as New Objectivity.
- New Objectivity was an art movement formed during the depression in 1920's Germany.
- New Objectivity was a counter-movement.
- New Objectivity was an outgrowth of Expressionism.