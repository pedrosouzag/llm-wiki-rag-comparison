# Viscount Exmouth (1811-1876

- Edward Pellew, 3rd Viscount Exmouth was born on 14 February 1811.
- Edward Pellew, 3rd Viscount Exmouth died on 11 February 1876.
- Edward Pellew, 3rd Viscount Exmouth was a British peer.
- Edward Pellew, 3rd Viscount Exmouth inherited the title of Viscount Exmouth from his father.
- Edward Pellew, 3rd Viscount Exmouth held the title for 42 years.
- Edward Pellew, 3rd Viscount Exmouth was the grandson of Edward Pellew, 1st Viscount Exmouth.