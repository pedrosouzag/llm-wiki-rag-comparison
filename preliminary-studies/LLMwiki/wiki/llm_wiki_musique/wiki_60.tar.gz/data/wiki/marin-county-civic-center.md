# Marin County Civic Center

Marin County Civic Center
- The Marin County Civic Center is located in San Rafael, California.
- The Marin County Civic Center was designed by Frank Lloyd Wright.
- The Marin County Civic Center is in the United States.
- Groundbreaking for the Civic Center Administration Building took place in 1960.
- Aaron Green was Wright's protégé.
- The Civic Center Administration Building was completed in 1962.
- The Hall of Justice was begun in 1966.
- The Hall of Justice was completed in 1969.
- Veterans Memorial Auditorium opened in 1971.
- The Exhibit Hall opened in 1976.
- The Walter V. Davidson House is located at 57 Tillinghast Place in Buffalo, New York.
- The Walter V. Davidson House was designed by Frank Lloyd Wright.
- The Walter V. Davidson House was built in 1908.
- The Walter V. Davidson House is an example of Wright's Prairie School architectural style.
- The Walter V. Davidson House is a contributing property to the Parkside East Historic District.
- Frederick Law Olmsted laid out the Parkside East Historic District in 1876.
- Isabel Roberts House is a classic 1908 Prairie House.
- Isabel Roberts House is located at 603 Edgewood Place in River Forest, Illinois.
- It was built for Isabel Roberts and her widowed mother, Mary Roberts.
- The Isabel Roberts House is from the studio of Frank Lloyd Wright.