# Tennis on CBS Branding

Tennis on CBS
- It is the branding used for broadcasts of professional tennis tournaments.
- It was produced by CBS Sports.
- CBS Sports is the sports division of the CBS television network.
- CBS held the broadcast rights to the U.S. Open.
- CBS held the broadcast rights to the U.S. Open Series.
- CBS held the broadcast rights to the Sony Ericsson Open.
- CBS also televised the French Open from 1980 to 1982.
- CBS had broadcast agreements with the United States Tennis Association (USTA).
- The network's broadcast agreements with the USTA ended in 2014.