# The Dream Life of Balso Snell

The Dream Life of Balso Snell
- The Dream Life of Balso Snell is a novel.
- The novel was published in 1931.
- The author is Nathanael West.
- Nathanael West is an American author.
- It presents a young man's search for meaning.
- The search takes place in a series of dreamlike encounters.
- The encounters take place inside the entrails of the Trojan Horse.
- It is West's first novel.