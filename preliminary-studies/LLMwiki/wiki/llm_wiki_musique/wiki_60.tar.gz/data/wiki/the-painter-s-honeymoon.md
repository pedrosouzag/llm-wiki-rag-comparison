# The Painter's Honeymoon

The Painter's Honeymoon
- The Painter's Honeymoon is a painting by Frederic Leighton, 1st Baron Leighton.
- The painting is currently housed at the Museum of Fine Arts, Boston.
- Frederic Leighton was 1st Baron Leighton.
- Portrait of a Young Englishman ("Portrait of a Young Man with Grey Eyes") is a 1540–45 portrait by Titian.
- The painting is now held in the Palazzo Pitti.
- Its subject is unidentified.
- The subject may be Henry Howard.
- The subject may be Ottavio Farnese.
- The subject may be Ippolito Rominaldi.
- Mother with a Child and a Chambermaid is an oil on canvas painting
- Mother with a Child and a Chambermaid is by the Dutch painter Pieter de Hooch
- Mother with a Child and a Chambermaid is an example of Dutch Golden Age painting
- Mother with a Child and a Chambermaid is part of the collection of the Amsterdam Museum.