# Elk Ridge, Maryland

Elk Ridge is a mountain ridge
Elk Ridge is part of the Blue Ridge Mountains
Elk Ridge is located west of South Mountain
Elk Ridge runs roughly parallel to South Mountain
Elk Ridge runs from Rohrersville in the north
Elk Ridge runs to the Potomac River across from Harpers Ferry, West Virginia, in the south
The ridge continues as Blue Ridge Mountain in Virginia and West Virginia
The southern end of the ridge is known as Maryland Heights
Maryland Heights is part of Harpers Ferry National Historical Park