# Canonical Alien Trilogy

Alien (franchise)
- Novelizations of each of the six films have been released.
- Some comic books have been released.
- Original canonical novels based on the franchise have been released.
- The original novels include Alien: Out of the Shadows.
- The original novels include Alien: Sea of Sorrows.
- The original novels include Alien: River of Pain.
- Alien: Out of the Shadows and River of Pain were adapted into audio dramas.
- The audio dramas were released on Alien Day.
- Alan Dean Foster published Alien: Covenant -- Origins.
- Alien: Covenant -- Origins is set between the events of Prometheus and Alien: Covenant.
- Aliens: Bug Hunt is a short story collection.
- The original novels are marketed as the Canonical Alien Trilogy.