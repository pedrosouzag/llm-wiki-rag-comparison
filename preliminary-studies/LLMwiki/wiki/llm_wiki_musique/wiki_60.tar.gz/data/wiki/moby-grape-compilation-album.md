# Moby Grape Compilation Album

The Place and the Time
- The Place and the Time is a compilation album.
- The album contains demos.
- The album contains outtakes.
- The album contains alternative versions.
- The album contains live versions.
- The album is by Moby Grape.
- The album was released by Sundazed Records.
- The album was released in 2009.
- The album was released in CD format.
- The album was released in double LP format.
- Great Grape is a compilation album.
- Great Grape was released by Columbia Records in 1972.
- Great Grape compiles songs from three of Moby Grape's Columbia albums - "Moby Grape", "Wow", and "Moby Grape '69".
- Columbia's decision to release Great Grape was based on trying to capitalize on any interest generated in Moby Grape by the then-recent release of a new studio album, "20 Granite Creek", on Reprise Records.