# Pangasinan School of Arts Trades

- Pangasinan School of Arts and Trades is also referred to as PSAT.
- Pangasinan School of Arts and Trades is a government institution.
- Pangasinan School of Arts and Trades is of technical vocation education and training higher learning.
- Pangasinan School of Arts and Trades is located in Alvear Street, Lingayen, Pangasinan, Philippines.
- Pangasinan School of Arts and Trades is registered by the Technical Education and Skills Development Authority.
- All PSAT programs are accredited by the Technical Education and Skills Development Authority (TESDA).