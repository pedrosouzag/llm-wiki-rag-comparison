# Schlage Locks

Schlage
- Schlage was founded in 1920 by Walter Schlage.
- Schlage is a lock manufacturer.
- Schlage was headquartered in San Francisco from its inception.
- Schlage relocated to Colorado Springs, Colorado in 1997.
- Schlage produces Primus key and cylinder lines.
- Schlage produces Everest key and cylinder lines.
- Schlage produces Everest Primus XP key and cylinder lines.
- Schlage is a popular brand of consumer and commercial locks in the United States.
- Medical Center of the Rockies is located in Loveland, Colorado.
- Medical Center of the Rockies is a sister hospital of Poudre Valley Hospital.
- Poudre Valley Hospital is located in Fort Collins, Colorado.
- Both Medical Center of the Rockies and Poudre Valley Hospital are operated by UCHealth.
- Medical Center of the Rockies is home to a regional heart center.
- Open heart surgery is performed at Medical Center of the Rockies.
- Medical Center of the Rockies is home to a regional neurosciences center.
- Medical Center of the Rockies cares for victims of head and back injury.
- Medical Center of the Rockies cares for victims of stroke.
- Medical Center of the Rockies cares for victims of