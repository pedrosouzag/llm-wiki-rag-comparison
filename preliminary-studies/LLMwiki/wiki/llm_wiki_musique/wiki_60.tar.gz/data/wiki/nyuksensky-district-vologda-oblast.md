# Nyuksensky District, Vologda Oblast

Nyuksensky District
- Nyuksensky District is an administrative and municipal district (raion)
- It is one of the twenty-six in Vologda Oblast, Russia
- It is located in the northeast of the oblast
- It borders with Ustyansky District of Arkhangelsk Oblast in the north
- It borders with Velikoustyugsky District in the east
- It borders with Kichmengsko-Gorodetsky District in the southeast
- It borders with Babushkinsky District in the south
- It borders with Totemsky District in the southwest
- It borders with Tarnogsky District in the west
- The area of the district is
- Its administrative center is the rural locality of Nyuksenitsa
- The population of the district is 11,714 (2002 Census)
- The population of Nyuksenitsa accounts for 43.7% of the