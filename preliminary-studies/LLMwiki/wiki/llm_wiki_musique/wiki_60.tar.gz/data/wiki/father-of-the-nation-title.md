# Father of the Nation Title

Father of the Nation
- "Father of the nation" was a title used by leaders in postcolonial Africa.
- Leaders used the title to refer to their role in the independence movement.
- Leaders used the title as a source of legitimacy.
- Leaders used paternalist symbolism as a source of continued popularity.
- Joseph Stalin was bestowed with the title "Father of Nations" in 1949.
- Stalin was given the title for his establishment of "people's democracies".
- The title "Father of the Nation" is sometimes politically contested.
- The 1972 Constitution of Bangladesh declared Sheikh Mujibur Rahman to be "father of the nation".
- The BNP government removed the declaration in 2004.
- Sheikh Hasina led the Awami League, which protested the removal.
- A motion to proclaim Andrej Hlinka "father of the nation" failed in Slovakia in September 200
- André Duchesne was a French geographer and historian.
- André Duchesne (sometimes spelled "Du Chesne", Latinized "Andreas Chesneus", "Andreas Quercetanus", or "Andreas Querneus").
- André Duchesne (May 1584 – May 30, 1640).
- André Duchesne is generally styled the father of French history.
- There is no formal provision that recipients of the Bharat Ratna should be Indian citizens.
- Mother Teresa was awarded the Bharat Ratna in 1980.
- Khan Abdul Ghaffar Khan of Pakistan was awarded the Bharat Ratna in 1987.
- Nelson Mandela, the former South African president, was awarded the Bharat Ratna in 1990.
- Sachin Tendulkar became the youngest person and first athlete to receive the honour.
- Dhondo Keshav Karve was awarded on his 100th birthday in a special ceremony on 18 April 1958.
- As of 2015, the award has been conferred upon