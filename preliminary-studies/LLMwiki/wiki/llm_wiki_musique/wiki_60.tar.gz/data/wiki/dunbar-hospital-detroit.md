# Dunbar Hospital, Detroit

Dunbar Hospital
- It was the first hospital for the black community in Detroit, Michigan.
- It is located at 580 Frederick Street.
- It is the administrative headquarters of the Detroit Medical Society.
- It was listed on the National Register of Historic Places in 1979.
- It is currently the administrative headquarters of the Detroit Medical Society.