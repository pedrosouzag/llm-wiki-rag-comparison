# Moorea-Maiao Commune

Moorea-Maiao
- Moorea-Maiao is a commune of French Polynesia.
- French Polynesia is an overseas territory of France.
- Moorea-Maiao is located in the Pacific Ocean.
- Moorea-Maiao is in the Windward Islands.
- In 2017, Moorea-Maiao had a population of 17,816.
- The commune is in the administrative subdivision of the Windward Islands.
- The commune is in the administrative subdivision of the Windward Islands.
- Poum is a commune in the North Province of New Caledonia.
- Poum is an overseas territory of France.
- Poum is located in the Pacific Ocean.
- The town of Poum is located at Latitude: 20° 13' 59" south, longitude: 164° 1' 23" east.
- Poum is located on the southern part of Banare Bay.
- Mouac Island is just offshore from Poum.
- Huahine is an island.
- Huahine is located among the Society Islands.
- Huahine is part of the Leeward Islands group "(Îles sous le Vent)."
- In 2017, Huahine had a population of 6,075.