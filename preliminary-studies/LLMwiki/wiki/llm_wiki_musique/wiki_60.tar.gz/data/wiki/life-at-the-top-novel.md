# Life at the Top (Novel)

Life at the Top
- It is the third novel by John Braine.
- It was first published in 1962.
- It was published by Eyre & Spottiswoode in the UK.
- It was published by Houghton Mifflin & Co. in the US.
- It continues the story of Joe Lampton.
- Joe Lampton is an ambitious young man of humble origins.
- A 1965 film adaptation of the novel was made.
- Laurence Harvey starred in the 1965 film adaptation.
- A two-part television adaptation was broadcast by BBC television in September 2012.
- Matthew McNulty was in the lead role in the television adaptation.
- The television adaptation had been delayed because of copyright difficulties.
- It is a novel by Donald Hamilton.
- It was first published in 1964.
- It continues the exploits of Matt Helm.
- It was the seventh novel of the series.
- "Happily Ever After" is Part 6 in the 6 issue story arc of Archie Marries Veronica / Archie Marries Betty.
- The story arc was originally presented in Archie # 605.
- The story features a futuristic look into the life of Archie Andrews and Betty Cooper.
- Archie Andrews and Betty Cooper raise a pair of fraternal twins.