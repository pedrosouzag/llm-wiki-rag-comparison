# NORC at the University of Chicago

NORC at the University of Chicago
- NORC at the University of Chicago is one of the largest independent social research organizations in the United States.
- It was established in 1941 as the National Opinion Research Center.
- Its corporate headquarters is located in downtown Chicago.
- It has offices in several other locations throughout the United States.
- It is organized as an independent corporation.
- More than half its board comes from faculty and administration of the university.
- It also jointly staffs some university academic research centers.