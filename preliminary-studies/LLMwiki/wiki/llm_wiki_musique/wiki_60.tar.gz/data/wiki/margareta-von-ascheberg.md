# Margareta von Ascheberg

Margareta von Ascheberg
- Margareta von Ascheberg was the youngest child of Field Marshal Rutger von Ascheberg and Magdalena Eleonora Busseck.
- On 26 January 1691, she married colonel count Kjell Christopher Barnekow (d. 1700) in Malmö.
- She kept her name after marriage and style herself »Grevinnan Ascheberg» (Countess Ascheberg).
- The couple had four children.
- She accompanied her spouse on his military commissions.
- She gave birth to their youngest sons during the Bombardment of Brussels in 1695.
- As was the custom of the Swedish nobility as that time, she kept her name after marriage and style herself »Grevinnan Ascheberg» (Countess Ascheberg).