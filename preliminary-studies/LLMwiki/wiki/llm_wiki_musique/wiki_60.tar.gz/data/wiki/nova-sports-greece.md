# Nova Sports Greece

Nova Sports
- Nova Sports is a premium Sports service in Greece.
- Nova Sports is owned by Forthnet Group.
- Forthnet Group is a subsidiary of Greek Telecommunications company Forthnet.
- It launched in 1994 as "Supersport".
- It was the first ever premium sports service in Greece.
- It is available exclusively on Nova.
- Nova is a DTH satellite service.
- Nova Sports is available terrestrially and via satellite only on Nova.
- Greece has been a member of the European Space Agency (ESA) since 2005.
- Greece's technology parks with incubator facilities include the Science and Technology Park of Crete (Heraklion), the Thessaloniki Technology Park, the Lavrio Technology Park and the Patras Science Park, the Science and Technology Park of Epirus (Ioannina).
- Cooperation between ESA and the Hellenic National Space Committee began in the early 1990s.
- In 1994 Greece and ESA signed their first cooperation agreement.
- Having formally applied for full membership in 2003, Greece became the ESA's sixteenth member on 16 March 2005.
- BSkyB utilises the VideoGuard pay-TV scrambling system owned by NDS, a Cisco Systems company.
- There are tight controls over use of VideoGuard decoders.
- VideoGuard decoders are not available as stand-alone DVB CAMs (conditional-access modules).
- BSkyB has design authority over all digital satellite receivers capable of receiving their service.
- The receivers must conform to the same user interface look-and-feel.
- The receivers offer a Personal video recorder (PVR) offering branded Sky+.