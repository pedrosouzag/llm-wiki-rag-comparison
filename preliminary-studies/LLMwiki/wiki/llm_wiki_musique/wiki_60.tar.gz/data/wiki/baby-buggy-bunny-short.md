# Baby Buggy Bunny Short

- Baby Buggy Bunny is a "Merrie Melodies" animated short.
- Baby Buggy Bunny was directed by Chuck Jones.
- Baby Buggy Bunny was written by Michael Maltese.
- Baby Buggy Bunny was released in 1954.
- The story is about a dwarf gangster named "Babyface" Finster.
- "Babyface" Finster is based on gangster Baby Face Nelson.
- Babyface Finster loses his gains down Bugs Bunny's rabbit hole.
- Babyface Finster dons the disguise of an orphan baby.