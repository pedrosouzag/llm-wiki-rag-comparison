# Supervisory Board Meetings

- The Supervisory Board meets twice a month.
- The Supervisory Board discusses, plans and carries out the ECB’s supervisory tasks.
- The Supervisory Board proposes draft decisions to the Governing Council.
- The Supervisory Board uses the non-objection procedure.
- The Chair is appointed for a non-renewable term of five years.
- The Vice-Chair is chosen from among the members of the ECB’s Executive Board.
- The Supervisory Board is composed of four ECB representatives.
- The Supervisory Board is composed of representatives of national supervisors.
- If a national supervisory authority is not an NCB, the representative can be accompanied by an NCB representative.
- The two representatives are considered as one member for the voting procedure.