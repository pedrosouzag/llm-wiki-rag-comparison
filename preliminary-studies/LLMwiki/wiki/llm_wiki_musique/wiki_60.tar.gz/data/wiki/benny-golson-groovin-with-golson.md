# Benny Golson - Groovin' with Golson

Groovin' with Golson
- It is the sixth album by saxophonist Benny Golson.
- The album features performances recorded in 1959.
- It was originally released on the New Jazz label.
- It is the third album released by British rock/R&B band Snafu.
- It was released on the Capitol label in 1975.
- The band featured keyboardist Brian Chatton.
- Brian Chatton was once with the Warriors of Jon Anderson.
- Brian Chatton was once with Flaming Youth with Phil Collins.
- Brian Chatton was later with Jackson Heights with ex-the Nice Lee Jackson.
- It is "highly elusive on vinyl."
- Featuring performances recorded in 1959.
- Originally released on the New Jazz label.