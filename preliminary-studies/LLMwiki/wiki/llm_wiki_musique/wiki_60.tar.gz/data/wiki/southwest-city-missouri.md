# Southwest City, Missouri

Southwest City, Missouri
- Southwest City is a city in McDonald County, Missouri.
- Southwest City is in the United States.
- The population was 937 at the 2010 census.
- At the 2010 census, it was a town.
- It is part of the Fayetteville–Springdale–Rogers, AR-MO Metropolitan Statistical Area.
- It is located in the southwestern corner of the state of Missouri.
- Baljev Dol is a village in the municipality of Dimitrovgrad, Serbia.
- The population of Baljev Dol was 8 people according to the 2002 census.
- Many relations of Ivo Karlović fled the area following unrest after the dissolution of Yugoslavia.
- Eldon is a city in Miller County, Missouri.
- Eldon is located thirty miles southwest of Jefferson City.
- The population was 4,567 at the 2010 census.