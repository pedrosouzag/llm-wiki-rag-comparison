# Krešimir Čuljak

Krešimir Čuljak
- Krešimir Čuljak was born on 18 September 1970.
- Krešimir Čuljak was born in Zagreb.
- Krešimir Čuljak is a Croatian rower.
- Krešimir Čuljak won a bronze medal in the eights competition.
- Krešimir Čuljak won the medal at the 2000 Summer Olympics.
- Krešimir Čuljak's teammates included Igor Boraska.
- Krešimir Čuljak's teammates included Nikša Skelin.
- Krešimir Čuljak's teammates included Siniša Skelin.
- Krešimir Čuljak's teammates included Branimir Vujević.
- Krešimir Čuljak's teammates included Tomislav Smoljanović.
- Krešimir Čuljak's teammates included Tihomir Franković.
- Baptiste Gros competed at the 2014 Winter Olympics for France.
- He placed 40th in the qualifying round in the sprint.
- He failed to advance to the knockout stages.