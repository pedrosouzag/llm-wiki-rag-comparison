# Berhale Woreda, Afar Region

Berhale (woreda)
- Berhale is one of the woredas in the Afar Region of Ethiopia.
- Berhale is part of Administrative Zone 2.
- Berhale's territory includes part of the Afar Depression.
- Berhale is bordered on the south by Afdera.
- Berhale is bordered on the south by Abala.
- Berhale is bordered on the southwest by the Tigray Region.
- Berhale is bordered on the west by Koneba.
- Berhale is bordered on the north by Dallol.
- Berhale is bordered on the northeast by Eritrea.
- Berhale includes the town of Berhale.
- Berhale includes the town of Tiyarabora.