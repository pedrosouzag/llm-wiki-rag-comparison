# Wagner Manufacturing Company

Wagner Manufacturing Company
- The Wagner Manufacturing Company was a family-owned manufacturer.
- It was based in Sidney, Ohio, US.
- It manufactured cast iron and aluminum products.
- It made products for domestic use.
- Products for domestic use included frying pans.
- Products for domestic use included casseroles.
- Products for domestic use included kettles.
- Products for domestic use included baking trays.
- It also made metal products other than cookware.
- Wagner was active between 1891 and 1952.
- It once dominated the cookware market.
- It sold products in Europe.
- It sold products in the US.
- The purchasers of the company in 1952 continued the brand.
- Wagner products are still manufactured today.
- The original items are prized by collectors.