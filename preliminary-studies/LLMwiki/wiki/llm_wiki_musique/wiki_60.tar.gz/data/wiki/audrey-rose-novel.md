# Audrey Rose (novel)

Audrey Rose is a novel.
It was written by Frank De Felitta.
It was published in 1975.
It is about a couple and their daughter.
The couple is confronted with the idea that their daughter might be the reincarnation of another man's child.
The book was inspired by an incident involving De Felitta's son.
De Felitta's son began displaying unusual talents and interests.
An occultist suggested the son might be remembering a previous life.
It was followed by a 1982 sequel, "For Love of Audrey Rose".
- A Prisoner of Birth is a mystery novel.
- A Prisoner of Birth is by English author Jeffrey Archer.
- A Prisoner of Birth was first published on 6 March 2008.
- A Prisoner of Birth was published by Macmillan.
- A Prisoner of Birth is a contemporary retelling of Dumas's "The Count of Monte Cristo".
- The novel saw Archer return to the first place in the fiction best-seller list for the first time in a decade.