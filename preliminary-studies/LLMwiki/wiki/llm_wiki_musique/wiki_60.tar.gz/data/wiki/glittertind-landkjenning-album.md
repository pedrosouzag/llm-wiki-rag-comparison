# Glittertind - Landkjenning Album

Landkjenning
- It is the second full-length album by the Norwegian folk rock band Glittertind.
- It was released on May 27, 2009.
- It was released through Napalm Records.
- All instruments and vocals were done by Torbjørn Sandvik and Geirmund Simonsen.
- Erlend Viken played Harding fiddle.
- Stefan Theofilakis played flutes.
- Kaja Fjellberg Pettersen played cello.
- Kris Verwimp did the cover-artwork.
- Julien Riesen did the cover-layout.