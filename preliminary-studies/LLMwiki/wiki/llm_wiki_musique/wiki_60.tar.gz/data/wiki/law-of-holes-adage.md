# Law of Holes Adage

- The adage has been attributed to a number of sources.
- It appeared in print on page six of The Washington Post dated October 25, 1911.
- The Washington Post published it in 1911 as: ``Nor would a wise man, seeing that he was in a hole, go to work and blindly dig it deeper... ''
- It was published in The Bankers Magazine in 1964.
- The Bankers Magazine published it in 1964 as:`` Let me tell you about the law of holes: If you find yourself in a hole, stop digging.''
- It is a 2003 American adventure comedy - drama film.
- It was directed by Andrew Davis.
- It was produced by Lowell D. Blank, Mike Medavoy and Teresa Tucker - Davies.
- It has music by Joel McNeely.
- It is based on the 1998 eponymous novel by Louis Sachar.
- Louis Sachar also wrote the screenplay.