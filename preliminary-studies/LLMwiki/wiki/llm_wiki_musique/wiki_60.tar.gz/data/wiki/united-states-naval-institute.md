# United States Naval Institute

United States Naval Institute
- It is based in Annapolis, Maryland
- It is a private, non-profit, professional military association
- It seeks to offer independent, nonpartisan forums for debate of national defense and security issues
- It publishes magazines and books
- It holds several annual conferences
- In the Shadow of Greatness is a 2012 book.
- It was written by 33 members of the United States Naval Academy Class of 2002.
- The United States Naval Institute published it.
- The authors describe how their lives were shaped by their experiences at the Academy, the September 11 attacks, and events following graduation.
- It is an international initiative developed by United States Naval Forces Europe-Africa
- It works cooperatively with U.S. and international partners
- It aims to improve maritime safety and security in Africa
- It is part of US Africa Command's Security Cooperation program