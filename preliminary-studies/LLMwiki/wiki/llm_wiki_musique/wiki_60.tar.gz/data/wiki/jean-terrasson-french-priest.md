# Jean Terrasson, French Priest

- The Great Fire of London occurred in 1666.