# Great Value Brand

Great Value
- Products are often claimed to be as good as national brand offerings.
- Products are typically sold at a lower price.
- The lower price is due to lower marketing and advertising expense.
- It is a house or store brand.
- The line does not consist of goods produced by Walmart.
- It is a labeling system for items manufactured and packaged by agricultural and food corporations.
- Corporations that manufacture and package items include ConAgra and Sara Lee.
- Sara Lee also manufactures and brands foods for a variety of other chain stores.
- The labeling system often does not list the location of manufacture.
- Wal-Mart contends that all Great Value products are produced in the United States.
- If a product is not produced in the United States, the country of origin would be listed.