# Miss Sara Sampson

Miss Sara Sampson
- Miss Sara Sampson is a play by Gotthold Ephraim Lessing.
- The original spelling of Miss Sara Sampson is "Miß Sara Sampson".
- The play was written in 1755.
- The author was living in Potsdam when the play was written.
- Many scholars see it as one of the first bourgeois tragedies.
- It was represented at Frankfurt-on-the-Oder in 1755.
- It was very well received at Frankfurt-on-the-Oder.
- It was translated and acted in France.
- It met with success in France.
- It was Lessing's first real success as a playwright.
- The success of the play led to Lessing being asked to be the dramaturg at the German National Theatre in Hamburg.
- Emilia Galotti is a play in five acts by Gotthold Ephraim Lessing (1729–1781).
- The work premiered on 8 March 1772 in Brunswick.
- The work is a classic example of German "bürgerliches Trauerspiel" (bourgeois tragedy).
- The story is based upon the Roman myth of Verginia.
- Other works in this category include Schiller's "Kabale und Liebe" and Hebbel's "Maria Magdalene".
- The play was intended to be performed in one act without interruptions.
- Some 18th-century editors divided the play into three acts.
- The "Imaginary Cuckold" continues to be performed today in its original one-act version.
- A performance of the play by the actors of the Comédie-Française with stage direction by Thierry Hancisse was broadcast on France 3 television in 2002.
- A performance of the play was released on DVD in 2008.