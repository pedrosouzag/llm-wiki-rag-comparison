# Infruset Premiere Event

Infruset
- The first public performance of "Infruset" was on October 28, 2012.
- The performance was celebrated as a cinema event.
- The event included broadcasts in cinemas and theaters in Sweden, Germany and Switzerland.
- The premiere consisted of two parts.
- One part was a biography of Gustaf Fröding.
- One part was interviews with band members.
- The other part was a live performance of new songs.