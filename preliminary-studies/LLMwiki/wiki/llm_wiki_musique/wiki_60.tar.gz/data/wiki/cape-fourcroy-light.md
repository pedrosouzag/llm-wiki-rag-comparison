# Cape Fourcroy Light

Cape Fourcroy Light
- It is an active lighthouse.
- It is located on Cape Fourcroy.
- Cape Fourcroy is on the southwestern tip of Bathurst Island.
- Bathurst Island is in the Northern Territory, Australia.
- It marks the beginning of the route from the Timor Sea to Darwin.