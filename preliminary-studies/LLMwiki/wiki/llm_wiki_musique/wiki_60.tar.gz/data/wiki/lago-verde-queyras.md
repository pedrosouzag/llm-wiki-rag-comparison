# Lago Verde (Queyras)

Lago Verde (Queyras)
- Lago Verde means "green lake" in Italian.
- It is located in Italy.
- It is close to the French border.
- It is located near the Queyras valley.
- Notogawa Station is the only Japan Railway station in Higashiomi.
- Notogawa Station is a rapid stop on the JR Biwako Line.
- The station is located between Omi-Hachiman and Hikone.
- The town shares a small border with Lake Biwa.
- Notogawa Station is located between Omi-Hachiman and Hikone.
- Notogawa Station (Location: N35.179899,E136.165913) is the only Japan Railway station in Higashiomi.
- The station is a rapid stop on the JR Biwako Line.