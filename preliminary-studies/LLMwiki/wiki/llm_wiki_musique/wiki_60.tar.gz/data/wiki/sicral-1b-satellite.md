# SICRAL 1B Satellite

SICRAL 1B
- It is a military communications satellite
- It was built by Thales Alenia Space
- It was built for Italian Armed Forces
- It is a dual-use spacecraft
- Telespazio will use some of its transmission capacity
- The Italian defense ministry will use some of its transmission capacity
- NATO will use some of its transmission capacity
- It is based on the Italsat 3000 bus
- It includes one EHF/Ka band transponder
- It includes three UHF-band transponders
- It includes five active SHF-band transponders
- It is designed to be operable for 13 years
- Commer was a British manufacturer of commercial vehicles from 1905 until 1979.
- Commer vehicles included car-derived vans, light vans, medium to heavy commercial trucks, military vehicles and buses.
- The company also designed and built some of its own diesel engines for its heavy commercial vehicles.