# PIAS Recordings

- In 2000, the label moved from Brussels to London.
- The label was renamed [PIAS] Recordings.
- [PIAS] Recordings released the first two albums by Sigur Rós.
- Mogwai signed to PIAS in 2001.