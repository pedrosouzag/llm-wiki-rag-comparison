# Full-Time Employment

Full-time employment
- Full-time employment is employment in which a person works a minimum number of hours defined by their employer.
- Full-time employment often comes with benefits like annual leave, sick leave, and health insurance.
- Some mistakenly think part-time jobs are not careers.
- Legislation exists to stop employers from discriminating against part-time workers.
- Full-time jobs generally pay more than part-time jobs per hour.
- The Fair Labor Standards Act (FLSA) does not define full-time or part-time employment.
- The definition of full-time employment is generally determined by the employer.
- Employers generally require 35 to 40 hours per week to be defined as full-time.
- Full-time employees are eligible for benefits.
- Part-time jobs are mistakenly thought by some to not be careers.
- They generally pay more than part-time jobs per hour.
- This is similarly discriminatory if the pay decision is based on part-time status as a primary factor.
- The definition by employer can vary and is generally published in a company's Employee Handbook.
- Companies commonly require from 35 to 40 hours per week to be defined as full-time and therefore eligible for benefits.