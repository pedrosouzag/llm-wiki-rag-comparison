# Lou Donaldson - Musty Rusty

Musty Rusty
- It is an album by jazz saxophonist Lou Donaldson.
- It was recorded for the Cadet label.
- The album was recorded in 1965.
- It was performed by Lou Donaldson with Bill Hardman, Billy Gardner, Grant Green, and Ben Dixon.
- Tijuana Jazz is an album by American jazz vibraphonist Gary McFarland and trumpeter Clark Terry.
- It was recorded in 1965.
- It was released in the UK on the HMV label as CLP3541.
- The Jazz Skyline is an album by American jazz vibraphonist Milt Jackson.
- It was recorded in 1956.
- It was released on the Savoy label.