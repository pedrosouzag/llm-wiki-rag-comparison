# Giovanni Cifolelli

Giovanni Cifolelli
- Giovanni Cifolelli was an Italian mandolin virtuoso and dramatic composer.
- The date and place of Giovanni Cifolelli’s birth are unknown.
- In 1764, Giovanni Cifolelli appeared in Paris as a mandolin virtuoso.
- Giovanni Cifolelli was highly esteemed as a performer.
- Giovanni Cifolelli was highly esteemed as a teacher.
- Giovanni Cifolelli published his "Method for the mandolin" while residing in Paris.
- Giovanni Cifolelli’s "Method for the mandolin" met with great success throughout France.
- Giovanni Cifolelli’s "Method for the mandolin" was the most popular of its period.
- His date and place of birth are unknown.
- He made his appearance in Paris in 1764.
- He was highly esteemed, both as a performer and teacher.
- He published his "Method for the mandolin" while residing in Paris.
- His "Method for the mandolin" met with great success throughout France.
- His "Method for the mandolin" was the most popular of its period.
- Suso Cecchi D'Amico was born on 21 July 1914 in Rome.
- Suso Cecchi D'Amico died on 31 July 2010 in Rome.
- Suso Cecchi D'Amico won the 1980 David di Donatello Award for lifetime career.
- Suso Cecchi D'Amico was an Italian screenwriter and actress.
- Suso Cecchi D'Amico worked with virtually all of the most celebrated post-war Italian film directors.
- Suso Cecchi D'Amico wrote or co-wrote many award winning films.