# Alexandre de Lesseps Biography

Alexandre de Lesseps
- Alexandre de Lesseps was born in Paris, France.
- His education took place in Khartoum, Sudan.
- His education took place in France.
- His education took place at Northwestern University in Chicago, Illinois.
- Dupland was a sailor from France.
- Dupland represented France at the 1900 Summer Olympics in Meulan, France.
- Dupland took the 10th place in the first race of the 0.5 to 1 ton.
- Dupland finished 7th in the second race.
- Dupland used the boat "Galopin".