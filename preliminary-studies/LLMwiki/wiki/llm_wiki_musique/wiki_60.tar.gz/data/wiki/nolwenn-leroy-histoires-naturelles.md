# Nolwenn Leroy - Histoires Naturelles

Histoires Naturelles is Nolwenn Leroy's second album.
It was released on 5 December 2005 in France.
Most of the songs were written by Laurent Voulzy.
Most of the songs were written by Nolwenn Leroy.
The title track was written in English by Yasmin Shah.
The title track was written in English by Arnaud Rosenthal.
"Mélusine" was written by Yasmin Shah.
"London Fantasy" was co-written by members of English down-tempo band Sundae Club.
Leroy adapted all the English-language lyrics into French.