# Planet Cake Couture Cakes

Planet Cake
- Planet Cake has created over 12000 couture cakes.
- Planet Cake has created cakes for Nicole Kidman.
- Planet Cake has created cakes for Celine Dion.
- Planet Cake has created cakes for Rihanna.
- Planet Cake has created cakes for Katy Perry.
- Planet Cake has created cakes for Keith Urban.
- Planet Cake has created cakes for John Travolta.
- Planet Cake has created cakes for Lady Gaga.
- Planet Cake has created cakes for television.
- Planet Cake has created cakes for many magazines.
- Planet Cake has created a host of ‘stunt’ cakes.
- Planet Cake created a realistic replica of the Sydney Opera House for Australia Day 2011.
- The Sydney Opera House replica weighed over 1.3 tons.
- 32 cake decorators were required to make the Sydney Opera House replica.