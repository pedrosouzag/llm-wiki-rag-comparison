# Breaking Benjamin - "I Will Not Bow"

I Will Not Bow is Breaking Benjamin's first single.
I Will Not Bow is on the 2009 album "Dear Agony".
"I Will Not Bow" was featured in the ending credits of the Bruce Willis film "Surrogates".
The song was not written specifically for the film "Surrogates".
Chad Szeliga is the drummer for Breaking Benjamin.
Ben sent songs to the record label Hollywood Records.
Hollywood Records is owned by Disney.
Disney wanted a Breaking Benjamin song for the movie "Surrogates".
The song was used on MLB Network during the 2010 MLB postseason.
The song was used as lead-in and lead-out music on MLB Network.