# MacDonald Airfield, WWII

- MacDonald Airfield was built during World War II.
- MacDonald Airfield is west of Stuart Highway.
- MacDonald Airfield is north of Pine Creek.
- MacDonald Airfield was built alongside the former northern road.
- MacDonald Airfield is in the Northern Territory, Australia.
- Milingimbi Airport is located east northeast of Milingimbi.
- Milingimbi Airport is on Milingimbi Island.
- The airport received funding for security upgrades in 2006.
- Henbury Meteorites Conservation Reserve is a protected area.
- Henbury Meteorites Conservation Reserve is in the Northern Territory of Australia.
- Henbury Meteorites Conservation Reserve is located in the locality of Ghan.