# Hinagdanan Cave, Bohol

Hinagdanan Cave
- Hinagdanan Cave is in Dauis
- Hinagdanan Cave is on Panglao Island
- Hinagdanan Cave is in Bohol Province
- Hinagdanan Cave is in the Philippines
- It is a naturally lighted cavern
- It has a deep lagoon
- It has many large stalactites
- It has many large stalagmites