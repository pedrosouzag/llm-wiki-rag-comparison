# Commission for Scheduled Castes

- The first Commission for Scheduled Castes and Scheduled Tribes was set up in August 1978.
- Bhola Paswan Shastri was Chairman of the first Commission.
- The first Commission had four Members.
- In 1990 the Commission for SCs and STs was renamed.
- The National Commission for Scheduled Castes and Scheduled Tribes was formed in 1987.
- The National Commission is a National Level Advisory Body.
- The National Commission advises the Government on broad policy issues.
- The National Commission advises the Government on levels of development of Scheduled Castes and Scheduled Tribes.
- The Directive Principles of State Policy are guidelines for the framing of laws by the government.
- These provisions are set out in Part IV of the Constitution.
- The Directive Principles of State Policy are not enforceable by the courts.
- The Fundamental Rights are defined as the basic human rights of all citizens.
- These rights are defined in Part III of the Constitution.
- These rights applied irrespective of race, place of birth, religion, caste, creed, or gender.
- The Fundamental Rights are enforceable by the courts, subject to specific restrictions.