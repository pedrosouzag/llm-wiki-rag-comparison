# Bruce Lee, My Brother (film)

Bruce Lee, My Brother
- Bruce Lee, My Brother is a 2010 Hong Kong biographical martial arts drama film.
- It is also known in the United Kingdom as Young Bruce Lee.
- The film was directed by Raymond Yip.
- The film was written, produced and directed by Manfred Wong.
- Robert Lee, Bruce Lee's real life younger brother, storied, produced and narrated the film.
- Aarif Lee stars as Lee.
- Tony Leung Ka-fai stars as Lee's father.
- Christy Chung stars as Lee's mother.
- The film is based on Bruce Lee's life during his teenage and adult years.
- Remember When: The Anthology is a DVD.
- Remember When: The Anthology features a collection of live performances by Harry Chapin.
- It features commentary by Joshua, Jennifer, and Sandy.
- Jennifer and Joshua are Harry Chapin's children.
- Sandy is Harry Chapin's widow.
- The DVD features eleven performances by Harry.
- The DVD features one performance by Jennifer (I Wonder What Would Happen to This World).
- Peter Shockey is an American filmmaker and screenwriter.
- Peter Shockey has received a New York City Film Festival award for his television film "Life After Life" (1992).
- Peter Shockey and his works have appeared on talk shows and television shows such as Oprah and the 700 Club.
- Peter co-wrote the book "Journey of Light" with Stowe D. Shockey.
- The book "Journey of Light" focuses on Stowe D. Shockey's experience as an abused child to help others.
- Peter and Stowe both live in Nashville, Tennessee.