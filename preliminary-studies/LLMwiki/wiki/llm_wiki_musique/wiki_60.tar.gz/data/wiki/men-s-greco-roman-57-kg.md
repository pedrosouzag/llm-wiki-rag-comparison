# Men's Greco-Roman 57 kg

- The Men's Greco-Roman 57 kg was part of the wrestling program at the 1984 Summer Olympics.
- The event was held at the Anaheim Convention Center.
- The event was held in Anaheim, California.