# KVLY - TV Mast

KVLY - TV mast
- It is 628.8 m (2,063 ft) tall.
- It was built in 1963.
- It is a guyed mast.
- It is used for VHF - UHF transmission.
- It is located in the United States.
- It is located in Blanchard, North Dakota.
- It is the tallest mast in the world.
- Its coordinates are 47 ° 20 ′ 31.85 ''N 97 ° 17 ′ 21.13'' W.