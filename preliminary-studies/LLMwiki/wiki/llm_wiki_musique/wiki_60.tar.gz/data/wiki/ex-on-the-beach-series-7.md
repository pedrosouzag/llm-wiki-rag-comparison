# Ex on the Beach (Series 7)

Ex on the Beach (British TV series)
- The seventh series began on 20 June 2017.
- The seventh series was filmed on the island of Bali in Indonesia.
- The series was confirmed on 26 February 2017.
- The cast members were confirmed on 23 May 2017.
- Chloe Ferry was in the cast.
- Marty McKenna was in the cast.
- Max Morley was in the cast.
- Josh Ritchie was in the cast.
- Savannah Kemplay was in the cast.
- Marty appeared in the third series of the show.
- Josh appeared in the sixth series of the show.