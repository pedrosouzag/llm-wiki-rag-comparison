# Alvin and the Chipettes

- Justin Long is Alvin Seville
- Matthew Gray Gubler is Simon Seville
- Jesse McCartney is Theodore Seville
- Christina Applegate is Brittany
- Anna Faris is Jeanette
- Kaley Cuoco is Eleanor
- Robbie Amell is Fred
- Kate Melton is Daphne
- Hayley Kiyoko is Velma
- Nick Palatas is Shaggy
- Frank Welker provides Scooby's voice