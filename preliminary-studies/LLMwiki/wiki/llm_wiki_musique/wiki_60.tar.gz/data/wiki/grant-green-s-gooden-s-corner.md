# Grant Green's Gooden's Corner

Gooden's Corner
- It is an album by Grant Green.
- It is by American jazz guitarist Grant Green.
- The album was recorded in 1961.
- It was released on the Japanese Blue Note label.
- It was released in 1980.
- The tracks were released in 1997.
- The tracks were released as part of "The Complete Quartets with Sonny Clark".