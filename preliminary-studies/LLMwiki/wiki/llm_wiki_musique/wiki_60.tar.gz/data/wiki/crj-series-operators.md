# CRJ Series Operators

- Bombardier produced the CRJ100 and CRJ200 series.
- The CRJ100 and CRJ200 series are no longer in production.
- The CRJ100 and CRJ200 series are still in active airline service.
- Bombardier produced the CRJ700, CRJ900 and CRJ1000 series.
- The CRJ700, CRJ900 and CRJ1000 series are in production.
- The CRJ700, CRJ900 and CRJ1000 series are in service.
- Bombardier Inc. is a Canadian aerospace and defence company.
- Bombardier Aerospace is a division of Bombardier Inc.
- The Learjet 60 is a mid-size cabin, medium-range business jet aircraft.
- The Learjet 60 is manufactured by Bombardier Aerospace in Wichita, Kansas.
- The Learjet 60 is powered by two Pratt & Whitney Canada PW305A engines.
- The Learjet 60 has a range (with 4 passengers and 2 crew) of with NBAA reserves, ISA.
- In July 2012 Bombardier Aerospace announced a temporary "production pause" of the latest variant Learjet 60XR.
- The production pause of the Learjet 60XR was to begin in the fourth quarter of 2012.