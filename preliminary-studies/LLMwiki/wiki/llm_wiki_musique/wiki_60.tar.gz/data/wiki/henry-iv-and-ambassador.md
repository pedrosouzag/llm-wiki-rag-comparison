# Henry IV and Ambassador

Henry IV Receiving the Spanish Ambassador
- It is a painting in the Troubador style.
- It was painted in 1817.
- The painter was Jean Auguste Dominique Ingres.
- It shows Henry IV of France.
- It shows Marie de Medici.
- It shows Henry IV's children.
- It shows the Spanish ambassador.