# Arthur Dickey, Canadian Politician

Arthur Rupert Dickey was born in Amherst, Nova Scotia.
Robert Barry Dickey was his father.
Charles Tupper was named High Commissioner for Canada in the United Kingdom.
He was elected to the House of Commons of Canada in an 1888 by-election.
He was elected in the riding of Cumberland.
He was a lawyer.
He was a Conservative.
He was re-elected in 1891.
He was re-elected in 1896.
He was Minister of Justice and Attorney General of Canada.
He was Minister of Militia and Defence.
He was Secretary of State of Canada.