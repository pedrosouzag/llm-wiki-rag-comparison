# The Village of Waiting

The Village of Waiting
- George Packer wrote The Village of Waiting.
- George Packer served with the Peace Corps in Togo in 1982–1983.
- The book chronicles Packer's time as an English teacher in the village of Lavie.
- Lavie means "wait a little longer."
- Packer visited the capital Lomé.
- Packer visited several other African countries.
- The book mixes anecdotes about the people he met in Togo with political observations.
- George Packer criticized Togolese President Gnassingbe Eyadema.
- Packer reflects upon the changes Togo has experienced since his time there in the 2001 edition.
- Packer was terminated early from the Peace Corps.
- Packer left Togo six months prior to the end of his contracted period of service.
- Packer chose not to mention his early termination in the book.