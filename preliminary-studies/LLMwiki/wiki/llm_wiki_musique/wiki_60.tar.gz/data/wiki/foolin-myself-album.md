# Foolin' Myself (album)

Foolin' Myself
- It is an album of trio performances.
- Jaki Byard is the pianist.
- It was recorded in 1988.
- It was released on the Italian Soul Note label.
- It is the 20th studio album by American jazz musician Joe Lovano.
- It was released on the Blue Note label.
- It was released in 2006.
- It features a five-part "Streams of Expression Suite."
- It features a three-part "Birth of the Cool Suite."
- It features three other shorter works.
- The "Birth of the Cool Suite" was conducted by Gunther Schuller.
- The "Birth of the Cool Suite" utilizes melodic themes inspired by Miles Davis' work from his 1948 and 1950 nonet.
- It features George Garzone.
- It features Ralph