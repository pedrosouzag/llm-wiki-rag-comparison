# School's Out (song)

- School's Out is a 1972 song
- School's Out is the title track single of Alice Cooper's fifth album
- The song was written by Alice Cooper, Michael Bruce, Glen Buxton, Dennis Dunaway and Neal Smith