# Dog Star Man Films

Dog Star Man
- Dog Star Man is a series of short experimental films
- The films were directed by Stan Brakhage
- Jane Wodening featured in the films
- The series was released during 1961 to 1964
- It comprises a prelude and four parts