# Pesanggrahan Subdistrict

Pesanggrahan, South Jakarta
- Pesanggrahan is a subdistrict of South Jakarta.
- Pesanggrahan is part of the capital territory of Jakarta, Indonesia.
- The Pesanggrahan River flows along the eastern edge of Pesanggrahan Subdistrict.
- To the west of Pesanggrahan Subdistrict is Tangerang Regency, Banten Province.
- Pesanggrahan is one of the administrative city which forms the capital territory of Jakarta, Indonesia.
- Pesanggrahan is one of the administrative city which forms the capital territory of Jakarta, Indonesia.