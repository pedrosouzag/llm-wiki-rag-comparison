# Port Blair, Andaman Islands

Port Blair
- Port Blair is the capital of the Andaman and Nicobar Islands.
- Port Blair is a union territory of India.
- Port Blair is situated in the Bay of Bengal.
- Port Blair is the local administrative sub-division (tehsil) of the islands.
- Port Blair is the headquarters for the district of South Andaman.
- Port Blair is the territory's only notified town.
- Port Blair houses the headquarters of the Andaman and Nicobar Police.
- Port Blair houses the headquarters of the Andaman and Nicobar Command.
- The Andaman and Nicobar Command is the first integrated tri-command of the armed forces of India.
- Port Blair (pronunciation (help info))
- The first integrated tri-command of the armed forces of India.
- The Citizen is a newspaper.
- The Citizen is based in Juba.
- Juba is the national capital of South Sudan.
- Juba is the state capital of Central Equatoria.
- The Citizen is based in Juba, the national capital of South Sudan and the state capital of Central Equatoria.
- Jirania is a small town in Tripura state of India.
- Jirania is on the banks of river Saidra.
- Jirania is a nagar panchayat.
- Jirania is the headquarters of Jirania Rural Development Block.
- Jirania is located in Sadar sub-divisions of West Tripura district.
- Jirania has 3 major high schools.
- Jirania's market is of great importance for the local business and its sustainence.
- Jirania lies on the National Highway 44 (Assam-Agartala Highway) of India.