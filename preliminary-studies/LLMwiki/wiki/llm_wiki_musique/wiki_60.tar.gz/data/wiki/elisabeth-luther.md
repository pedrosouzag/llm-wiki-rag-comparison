# Elisabeth Luther

Elisabeth Luther
- Elisabeth Luther was the first daughter and second child born to Martin Luther and Katharina von Bora.
- She did not survive infancy.
- He was educated at Luther Theological Seminary (in Saint Paul, Minnesota).
- He was educated at Princeton University.
- He was educated at the University of Tübingen in Germany.
- He served as a pastor in Mason City, Iowa.
- He joined the faculty of Luther Theological Seminary as professor of New Testament.
- Young Man Luther: A Study in Psychoanalysis and History is a 1958 book by psychologist Erik Erikson.
- It was one of the first psychobiographies of a famous historical figure.
- Erikson found in Martin Luther a good model of his discovery of "the identity crisis".
- Erikson was sure he could explain Luther's spontaneous eruption, during a monastery choir practice, "I am not!".
- Dexter Scott King was born January 30, 1961.
- He is the second son of Martin Luther King Jr. and Coretta Scott King.
- He is the brother of Martin Luther King III, Bernice King, and Yolanda King.
- Erikson's stages of psychosocial development is a comprehensive psychoanalytic theory.
- Erikson articulated it in collaboration with Joan Erikson.
- It identifies a series of eight stages that a healthy developing individual should pass through from infancy to late adulthood.