# Eetookashoo Bay Waterway

- Eetookashoo Bay is a waterway in Qikiqtaaluk Region, Nunavut, Canada.
- It is located at the northern end of Axel Heiberg Island.
- It is located between Cape Thomas Hubbard and Cape Stallworthy.
- The bay is named in honor of Eetookashoo ("Itukassuk").
- Eetookashoo ("Itukassuk") had traveled with Frederick Cook.
- Eetookashoo ("Itukassuk") had traveled with Donald Baxter MacMillan.