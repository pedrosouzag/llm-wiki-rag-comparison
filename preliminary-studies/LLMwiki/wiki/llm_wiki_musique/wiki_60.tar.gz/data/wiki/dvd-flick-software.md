# DVD Flick Software

DVD Flick
- DVD Flick is an open source DVD authoring application
- DVD Flick is for Windows
- DVD Flick was developed by Dennis Meuwissen
- DVD Flick is released under the GNU General Public License
- DVD Flick is capable of importing audio tracks
- DVD Flick is capable of importing video files
- DVD Flick is capable of importing subtitles
- DVD Flick can compose a DVD-Video movie
- DVD Flick can burn to a disc
- DVD Flick can create an ISO image