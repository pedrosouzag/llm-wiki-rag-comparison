# Steve Hillage - Green Album

Green (Steve Hillage album)
- It is the fourth studio album by Steve Hillage.
- It was written in spring 1977.
- It was written at the same time as "Motivation Radio" (1977).
- It was originally going to be released as "The Green Album".
- It was intended as a companion to "The Red Album".
- "The Red Album" was the originally intended name for "Motivation Radio".
- It was recorded primarily in Dorking, Surrey.
- It was recorded in London.
- It was recorded after a US tour in late 1977.
- The inspiration for the song was John F. Kennedy's daughter, Caroline.
- Diamond sang the song to Caroline at her 50th birthday celebration in 2007.
- A magazine cover photo of Caroline Kennedy on a horse with her parents inspired the song.
- Diamond said the song was about his then - wife Marcia in 2014.
- Diamond needed a three - syllable name to fit the melody.
- The picture was seen about five years before the song was written.