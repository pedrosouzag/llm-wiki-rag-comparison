# English Middle Ages Conflicts

England in the Middle Ages
- Richard focused on protecting his possessions in France.
- Richard fought in the Third Crusade.
- John inherited England in 1199.
- John lost Normandy and most of Aquitaine after years of war with France.
- John fought campaigns to regain lost possessions.
- John's efforts to raise revenues led to confrontation with English barons.
- In 1215, the Magna Carta was signed to restore peace.
- John died having fought the rebel barons and their French backers to a stalemate.
- Royal power was re-established by barons loyal to Henry III.
- England's power structures remained unstable.
- The Second Barons' War broke out in 1264.
- Simon de Montfort captured the king.
- Edward defeated rebel factions between 1265 and 1267.
- Edward restored his father to power.
- Martin Luther separated the religious and the worldly realms in principle.
- Believers were obliged to use reason to govern the worldly sphere in an orderly and peaceful way.
- Luther's doctrine of the priesthood of all believers upgraded the role of laymen in the church considerably.
- Members of a congregation had the right to elect a minister.
- Members of a congregation had the right to vote for his dismissal.
- Calvin strengthened the role of laymen in the church.
- Calvin included elected laymen (church elders, presbyters) in his representative church government.
- The Huguenots added regional synods and a national synod to Calvin's system of church self-government.
- This system