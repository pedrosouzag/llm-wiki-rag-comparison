# Datsun Brand History

- Datsun is an automobile brand.
- Datsun is owned by Nissan.
- Datsun's original production run began in 1931.
- From 1958 to 1986, only vehicles exported by Nissan were identified as Datsun.
- Nissan phased out the Datsun name by 1986.
- Datsun was re-launched in June 2013.
- Datsun is a brand for low-cost vehicles.
- Datsun vehicles are manufactured for emerging markets.