# Joan Llimona

Joan Llimona
- Joan Llimona i Bruguera was born in 1860.
- Joan Llimona i Bruguera died in 1926.
- Joan Llimona i Bruguera was a Spanish artist.
- Joan Llimona rose to popularity at the end of the Romantic movement in Europe.
- Joan Llimona was a key contributor to the modernist movement.
- Joan Llimona was born in Barcelona.
- Joan Llimona died in Barcelona.
- Joan Llimona made a lasting impact on the modernist movement in European art during the early 20th century.
- Many of Joan Llimona's works deal with religious scenes and beliefs.
- Joan Llimona's works often communicate controversial religious messages.
- F. A. Forbes was a "nom de plume".
- F. A. Forbes' "nom de plume" was Mother Frances Alice Monica Forbes, RSCJ.
- F. A. Forbes was a member of the Society of the Sacred Heart.
- F. A. Forbes was from Scotland.
- F. A. Forbes (1869–1936).
- F. A. Forbes was a religious author.