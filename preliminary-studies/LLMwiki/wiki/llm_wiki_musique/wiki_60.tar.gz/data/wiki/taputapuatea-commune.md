# Taputapuatea Commune

Taputapuatea
- Taputapuatea is a commune of French Polynesia.
- French Polynesia is an overseas territory of France.
- Taputapuatea is located in the Pacific Ocean.
- Taputapuatea is located on the island of Raiatea.
- Taputapuatea is located in the Leeward Islands.
- The Leeward Islands are part of the Society Islands.
- In 2017, Taputapuatea had a population of 4,792.
- In 2017, Taputapuatea and Taputapuatea marae were inscribed on the UNESCO World Heritage Sites list.
- Poum is a commune in the North Province of New Caledonia.
- New Caledonia is an overseas territory of France.
- Poum is located in the Pacific Ocean.
- The town of Poum is located at Latitude: 20° 13' 59" south, longitude: 164° 1' 23" east.
- Poum is located on the southern part of Banare Bay.
- Mouac Island is just offshore from Poum.
- Taputapuatea along with Taputapuatea marae were inscribed on the UNESCO World Heritage Sites list.
- At the 2017 census it had a population of 4,792.
- Taputapuatea is a commune of French Polynesia, an overseas territory of France in the Pacific Ocean.
- The commune of Taputapuatea is located on the island of Raiatea, in the administrative subdivision of the Leeward Islands, themselves part of the Society Islands.
- In 2017 Taputapuatea along with Taputapuatea marae were inscribed on the UNESCO World Heritage Sites list.