# Marshall Islands - US Occupation

Marshall Islands
- The Marshall Islands were captured and occupied by the United States during World War II.
- The Marshall Islands are located in Micronesia.
- The Marshall Islands passed formally to the United States in 1947.
- The Marshall Islands were part of the Trust Territory of the Pacific Islands.
- The Trust Territory of the Pacific Islands was established pursuant to Security Council Resolution 21.