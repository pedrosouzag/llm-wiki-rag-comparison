# The Stranglers' "Strange Little Girl"

Strange Little Girl (song)
- "Strange Little Girl" was released in the UK in 1982.
- The song was released as a single by the Stranglers.
- The Stranglers were signed to Liberty Records (part of EMI) at the time.
- The Stranglers had decided to leave Liberty Records for Epic Records by the time of release.
- The single was part of a severance deal.
- The severance deal also included the compilation album, "The Collection 1977-1982".