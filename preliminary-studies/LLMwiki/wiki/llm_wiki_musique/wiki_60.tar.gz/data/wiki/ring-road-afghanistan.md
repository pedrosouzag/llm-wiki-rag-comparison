# Ring Road (Afghanistan)

Highway 1 (Afghanistan)
- National Highway 01 is formally called the Ring Road.
- National Highway 01 is also known as NH01.
- It is an ancient two-lane road network inside Afghanistan.
- It connects Kabul, Maidan Shar, Ghazni, Kandahar, Delaram, Herat, Maymana, Sheberghan, Mazari Sharif, and Puli Khumri (clockwise).
- It was originally built and renovated by the Mauryan Empire.
- It was a part of the Grand Trunk Road project.
- It was well documented by Greek and Buddhist sources in the 4th century BCE.
- It was renovated by Sher Shah Suri.
- It was renovated by the Mughal Empire.
- It was renovated by the British Empire.
- It has extensions that connect Jalalabad.
- It has extensions that connect Bamyan.
- It has extensions that connect Khost