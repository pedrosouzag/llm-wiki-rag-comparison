# Market Square, High Point

Market Square (High Point, North Carolina)
- Market Square is a furniture showroom complex.
- It is located in High Point, North Carolina.
- It is owned by International Market Centers.
- It is the largest building in North Carolina on the National Register of Historic Places (NRHP).
- It is the sixth largest building in the United States.
- It was formerly known as Tomlinson Chair Manufacturing Company Complex.
- It was listed on the NRHP under that name.
- It includes the oldest factory building in the city.
- Its renovation has been credited with making High Point a successful furniture exhibition center.
- A 16-story addition was built in 1990.
- The 16-story addition is one of the city's tallest buildings.