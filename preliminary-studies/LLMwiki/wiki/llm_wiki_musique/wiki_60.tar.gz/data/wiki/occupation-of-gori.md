# Occupation of Gori

Occupation of Gori
- The Occupation of Gori was a military occupation of Gori and its surrounding areas.
- The occupation started on 13 August 2008.
- The occupation was part of the Russo-Georgian War.
- Russian military forces started the occupation.
- The occupation ended on 22 August 2008.
- Russian units withdrew from the city on 22 August 2008.