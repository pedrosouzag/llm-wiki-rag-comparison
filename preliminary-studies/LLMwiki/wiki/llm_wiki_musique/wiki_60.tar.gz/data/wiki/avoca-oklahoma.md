# Avoca, Oklahoma

- Avoca was a small town
- Avoca was in Avoca Township
- Avoca was in southeastern Pottawatomie County, Oklahoma Territory
- The post office was established in 1894
- The post office closed permanently in 1906