# Gallaratese, Milan District

- Gallaratese is a district of Milan, Italy.
- Gallaratese is part of the Zone 8 administrative division.
- It is located 7 km north-west of the city centre.
- It borders on the "comune" of Pero to the north.
- It borders on the district of Trenno to the west.
- It borders on the district of Lampugnano to the south.
- Its ideal border to the east is the eponymous street.
- The eponymous street is named after Gallarate.
- The eponymous street leads to the town of Gallarate.
- Menteng is an administrative village.
- Menteng is located in the Menteng district of Indonesia.
- It has a postal code of 10310.
- It is located on the southern area of the Menteng Project.