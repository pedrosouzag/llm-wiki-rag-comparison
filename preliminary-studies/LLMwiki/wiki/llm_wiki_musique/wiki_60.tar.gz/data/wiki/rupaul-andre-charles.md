# RuPaul Andre Charles

RuPaul Andre Charles was born on November 17, 1960.
RuPaul is known professionally by the mononym RuPaul.
RuPaul is an American actor.
RuPaul is a drag queen.
RuPaul is a television personality.
RuPaul is a singer / songwriter.
RuPaul has produced the reality competition series RuPaul's Drag Race since 2009.
RuPaul has hosted RuPaul's Drag Race since 2009.
RuPaul received two Primetime Emmy Awards for RuPaul's Drag Race.