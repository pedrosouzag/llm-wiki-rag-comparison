# iPod Manufacturing Conditions

iPods are mainly manufactured by workers who earn no more than US$50 per month
iPods are mainly manufactured by workers who work 15-hour shifts
The Mail on Sunday reported that iPods are mainly manufactured by workers who earn no more than US$50 per month
The Mail on Sunday reported that iPods are mainly manufactured by workers who work 15-hour shifts
Apple investigated the case with independent auditors
Some of the plant's labour practices met Apple's Code of Conduct
Employees worked over 60 hours a week for 35% of the time
Employees worked more than six consecutive days for 25% of the time