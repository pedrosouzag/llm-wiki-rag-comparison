# AS Monaco Coupe de France Win

- The 1979–80 Coupe de France was the 63rd Coupe de France.
- It is France's annual national football cup competition.
- It was won by AS Monaco.
- AS Monaco defeated US Orléans in the final.
- The competition was won by Napoli.
- Napoli defeated Verona in a one-legged final.
- The final was played at the Stadio Olimpico in Rome.
- The 1975–76 Coppa Italia was the 29th season of Coppa Italia.