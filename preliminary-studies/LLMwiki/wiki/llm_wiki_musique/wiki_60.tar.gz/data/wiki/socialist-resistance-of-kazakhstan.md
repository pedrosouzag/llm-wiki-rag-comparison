# Socialist Resistance of Kazakhstan

Socialist Resistance of Kazakhstan was established in 2002.
It was established by Kazakh members of the Committee for a Workers International.
A conference held in Russia established the organisation.
One member was detained en route to the conference.
Members reported being attacked as they gathered for the conference.
The organisation came under attack by authorities from its inception.