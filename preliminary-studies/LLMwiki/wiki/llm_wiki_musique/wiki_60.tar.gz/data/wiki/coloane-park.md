# Coloane Park

- Coloane Park is a large park
- It is located on Coloane Island
- Coloane Island is in Macau
- Macau is a Special Administrative Region of the People's Republic of China
- Coloane Park is located on the southern section of Coloane Island