# Bernd Hüttemann

Bernd Hüttemann
- Bernd Hüttemann was born on December 8, 1970.
- Bernd Hüttemann was born in Paderborn.
- Bernd Hüttemann is Vice President of the European Movement International.
- Bernd Hüttemann is Secretary General of the European Movement Germany.
- Ignazio Corrao is an Italian politician.
- Ignazio Corrao is a member of the Five Star Movement.
- Ignazio Corrao is a member of the European Parliament since 2014.
- Ignazio Corrao was born on January 14, 1984.
- Alain Milon was born on September 16, 1947.
- Alain Milon is a member of the Senate of France.
- Alain Milon represents the Vaucluse department.
- Alain Milon is a member of the Union for a Popular Movement.
- Klaus Mehnert was born on October 10, 1906.
- Klaus Mehnert was born in Moscow, Russia.
- Klaus Mehnert was a political scientist.
- Klaus Mehnert was a journalist.
- Klaus Mehnert was a professor at two American universities before World War II.
- Klaus Mehnert authored several books on recent youth led political movements in various Western countries in the late 1970s.
- Klaus Mehnert died on January 2, 1984.
- Klaus Mehnert died in Freudenstadt, Germany.
- The European Movement International is a lobbying association.
- The European Movement International coordinates the efforts of associations and national councils.
- The European Movement International promotes European integration.
- The European Movement International disseminates information about it.
- The 2003 European Fencing Championships were held in Bourges, France.
- The event took place from 29 June to 3 July 2003.