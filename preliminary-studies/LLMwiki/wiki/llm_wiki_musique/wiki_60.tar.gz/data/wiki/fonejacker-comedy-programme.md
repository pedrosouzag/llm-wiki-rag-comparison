# Fonejacker Comedy Programme

Fonejacker
- Fonejacker is a British comedy programme.
- It is broadcast on E4.
- It features prank calls.
- The prank calls involve a number of different characters.
- The characters are performed by Kayvan Novak.
- Kayvan Novak is a British Iranian television actor.
- It first appeared in May 2006.
- It became a full series in 2007.
- Frank TV was an American sketch comedy show.
- It starred Frank Caliendo, Mike MacRae, and Freddy Lockhart.
- Frank Caliendo hosted the show.
- Frank Caliendo performed in sketches in full makeup as characters he impersonated.