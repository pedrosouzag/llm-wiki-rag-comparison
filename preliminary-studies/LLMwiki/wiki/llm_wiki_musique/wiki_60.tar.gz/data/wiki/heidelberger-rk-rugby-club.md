# Heidelberger RK Rugby Club

- Heidelberger RK is one of two professional rugby clubs in Germany
- SC 1880 Frankfurt is the other professional rugby club in Germany
- Hans-Peter Wild owns a soft drink manufacturing business
- Hans-Peter Wild supported the club's turn to professionalism