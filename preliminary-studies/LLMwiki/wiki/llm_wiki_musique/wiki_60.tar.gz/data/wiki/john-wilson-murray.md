# John Wilson Murray

The Great Detective
- "The Great Detective" was inspired by John Wilson Murray.
- John Wilson Murray was Canada's first government-appointed detective.
- The series is set in the latter part of the Victorian era.
- Inspector Alistair Cameron was a fictional counterpart of Murray.
- Inspector Cameron was assisted by Dr. Chisholm.
- Dr. Chisholm was a forensic scientist.
- The series was produced on location at Rockwood.
- The series was produced on location at Kleinburg.
- The series was produced on location at Shadow Lake.
- The series was produced in Ontario.
- The series was produced in Victoria.
- The series was produced in areas of downtown Toronto.
- The series was produced at CBC's television Studio 7.