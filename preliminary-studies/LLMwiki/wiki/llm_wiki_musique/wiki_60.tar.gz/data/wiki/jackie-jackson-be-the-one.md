# Jackie Jackson - Be the One

Be the One is Jackie Jackson's second studio album.
Be the One was released on September 9, 1989.
Paul Jackson, Jr. was a musician on the album.
Jeff Lorber was a musician on the album.
Robert Brookins was a musician on the album.
Gerald Albright was a musician on the album.