# Michael Feinstein - Romance on Film

- Romance on Film, Romance on Broadway is an album.
- The album was released in 2000.
- Michael Feinstein is the vocalist on the album.
- Alan Broadbent arranged the album.
- John Oddo arranged the album.
- It was Feinstein's third album for the Concord label.