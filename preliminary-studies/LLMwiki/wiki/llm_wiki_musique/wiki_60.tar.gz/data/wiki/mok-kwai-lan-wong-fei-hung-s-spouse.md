# Mok Kwai-lan, Wong Fei-hung's Spouse

Mok Kwai-lan
- Mok Kwai-lan’s date of birth was October 15, 1892.
- Mok Kwai-lan’s date of death was November 3, 1982.
- Mok Kwai-lan was the fourth spouse of Wong Fei-hung.
- Mok Kwai-lan was a spouse of a Lingnan martial arts grandmaster.
- Wong Fei-hung was a Lingnan martial arts grandmaster.