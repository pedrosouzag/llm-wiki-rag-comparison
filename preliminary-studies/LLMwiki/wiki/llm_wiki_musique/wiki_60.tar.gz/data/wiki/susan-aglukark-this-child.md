# Susan Aglukark - This Child

This Child
- This Child is the second album by Susan Aglukark
- This Child was released in 1995
- This Child was Susan's commercial breakthrough in Canada
- The album spawned chart hits with "O Siem"
- The album spawned chart hits with "Hina Na Ho (Celebration)"
- Susan was the first Inuk performer ever to have a Top 40 hit