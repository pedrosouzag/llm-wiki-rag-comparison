# Kimbrough Memorial Stadium

Kimbrough Memorial Stadium
- Kimbrough Memorial Stadium is in Canyon, Texas.
- It is owned by Canyon Independent School District.
- It is primarily used for American football.
- It is the home stadium for Canyon High School.
- It is the home stadium for Randall High School.
- It is the former home of West Texas A&M University.
- It holds 20,000 people.
- It was built in 1959.
- It was originally called Buffalo Bowl on Canyon Hill.
- It was renamed Kimbrough Memorial Stadium in 1971.
- It was renamed in honor of Frank Kimbrough.
- Frank Kimbrough was a West Texas State University football coach.
- Frank Kimbrough was a West Texas State University athletic director.
- Historic Broken Bow Memorial Stadium has served as the home of the Broken Bow Savages.
- It was constructed in 1936.
- It was constructed by the National Youth Administration.
- It was constructed as part of the Works Progress Administration.
- Canyon is the county seat of Randall County, Texas.
- The population of Canyon was 13,303 at the 2010 census.
- Canyon is part of the Amarillo, Texas, metropolitan statistical area.
- Canyon is the home of West Texas A&M University.
- Canyon is the home of Panhandle–Plains Historical Museum.
- Canyon is the home of the world-famous outdoor musical drama "Texas".