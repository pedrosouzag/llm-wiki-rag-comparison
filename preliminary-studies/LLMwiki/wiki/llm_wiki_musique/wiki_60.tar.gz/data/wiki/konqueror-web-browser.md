# Konqueror Web Browser

Konqueror
- It is a free and open-source web browser.
- It is a file manager.
- It provides web access.
- It provides file-viewer functionality.
- It provides functionality for file systems.
- It can access local files.
- It can access files on a remote FTP server.
- It can access files in a disk image.
- It forms a core part of the KDE Software Compilation.
- It was developed by volunteers.
- It can run on most Unix-like operating systems.
- The KDE community licenses and distributes it.
- It is licensed under the GNU General Public License version 2.