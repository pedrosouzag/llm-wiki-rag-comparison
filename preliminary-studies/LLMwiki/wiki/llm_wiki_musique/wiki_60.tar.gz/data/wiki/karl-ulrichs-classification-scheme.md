# Karl Ulrichs' Classification Scheme

- One of the earliest sexual orientation classification schemes was proposed in the 1860s.
- Karl Heinrich Ulrichs proposed the classification scheme in the 1860s.
- Ulrichs published a series of pamphlets privately.
- The classification scheme was meant only to describe males.
- The classification scheme separated males into three basic categories.
- The categories were dionings, urnings and uranodionings.
- An urning can be categorized by degree of effeminacy.
- The categories correspond with the categories of sexual orientation used today.
- The categories are heterosexual, homosexual, and bisexual.
- Ulrichs outlined a set of questions to determine if a man was an urning.
- Ulrichs outlined definitions for each category of his classification scheme.