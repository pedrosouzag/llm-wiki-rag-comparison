# Bann Na Mohra, Pakistan

Bann Na Mohra is a town
Bann Na Mohra is in the Islamabad Capital Territory of Pakistan
Bann Na Mohra is located at 33° 27' 50N 73° 22' 10E
Bann Na Mohra has an altitude of 562 metres
Bann Na Mohra has an altitude of 1847 feet