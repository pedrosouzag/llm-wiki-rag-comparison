# Rohana Wijeweera

Rohana Wijeweera
- Rohana Wijeweera was born on 14 July 1943.
- Rohana Wijeweera died on 13 November 1989.
- Rohana Wijeweera was a Sri Lankan Marxist politician.
- Rohana Wijeweera was a revolutionary.
- Rohana Wijeweera was the founding leader of the Janatha Vimukthi Peramuna.
- Rohana Wijeweera led the party in two unsuccessful insurrections in Sri Lanka.
- The insurrections occurred in 1971 and 1987 to 1989.
- Rohana Wijeweera's name is also written as Patabendi Don Jinadasa Nandasiri Wijeweera.
- Dimuthu Bandara Abayakoon is a Sri Lankan politician.
- Dimuthu Bandara Abayakoon belongs to the Janatha Vimukthi Peramuna.
- Dimuthu Bandara Abayakoon was born on September 6, 1971.
- Dimuthu Bandara Abayakoon was elected as a representative of Kandy District in the Parliament of Sri Lanka in the 2004 election.
- Dimuthu Bandara Abayakoon stood as a United People's Freedom Alliance candidate.
- Dimuthu Bandara Abayakoon resides in Kandy.