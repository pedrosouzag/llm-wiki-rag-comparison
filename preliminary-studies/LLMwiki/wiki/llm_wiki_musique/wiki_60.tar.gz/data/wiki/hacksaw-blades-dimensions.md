# Hacksaw Blades Dimensions

Hacksaw
- The most common blade is the 12 inch or 300 mm length.
- Hacksaw blades have two holes near the ends for mounting them in the saw frame.
- The 12 inch / 300 mm dimension refers to the center to center distance between these mounting holes.