# Child Reference Number & NI Number

- People born and resident in the UK are assigned a Child Reference Number shortly after birth.
- A claim is made for Child Benefit to receive a Child Reference Number.
- HMRC notifies each child of their NI number at age 15 years 9 months.
- A bill was proposed in June 2005 to raise the age of consent from 16 to 18 in Georgia.
- The Georgia age of consent was 14 from the Progressive era until 1995.
- A bill proposed by state Senator Steve Langford to make 16 the age of consent passed in 1995.
- In 2006, aggravated child molestation was reduced to a misdemeanor with a maximum of one year in prison under certain conditions.
- The conditions for the reduced misdemeanor sentence in 2006 were: the offender was under 19, the victim was either 14 or 15 years old, and