# Pak Tam Chung Area

Pak Tam Chung
- Pak Tam Chung is an area in the southern part of the Sai Kung Peninsula
- Pak Tam Chung is in the New Territories of Hong Kong
- Pak Tam Chung is administratively under the Sai Kung District
- Pak Tam Chung () is an area in the southern part of the Sai Kung Peninsula in the New Territories of Hong Kong.
- It is administratively under the Sai Kung District.
- The transfer of sovereignty over Hong Kong from the United Kingdom to China took place on 1 July 1997.
- The event is referred to as ``the Handover ''internationally.
- The event is referred to as ``the Return'' in China.
- The event marked the end of British administration in Hong Kong.
- The event is often regarded as the watershed of the British Empire.
- Hong Kong has a total area of .
- 3.16% of Hong Kong is water.
- 60 islands are dispersed around Hong Kong.
- Lantau Island is the largest island by area.
- Lantau Island is located Southwest of the main peninsula.
- Lantau Island and the majority of the remaining islands are part of the New Territories.
- Victoria Harbour is a natural landform harbour.
- Hong Kong Island is separated from Kowloon by Victoria Harbour.
- The Kowloon Peninsula to the south of Boundary Street was added to Colonial Hong Kong in 1860.
- The New Territories to the north of Hong Kong Island were added to Colonial Hong Kong in 18