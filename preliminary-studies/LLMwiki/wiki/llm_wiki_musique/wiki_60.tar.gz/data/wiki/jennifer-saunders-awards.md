# Jennifer Saunders Awards

Jennifer Saunders
- Jennifer Jane Saunders was born on 6 July 1958.
- Jennifer Jane Saunders is an English comedian.
- Jennifer Jane Saunders is an English screenwriter.
- Jennifer Jane Saunders is an English actress.
- Jennifer Saunders has won three BAFTAs.
- Jennifer Saunders has won a BAFTA Fellowship.
- Jennifer Saunders has won an International Emmy Award.
- Jennifer Saunders has won a British Comedy Award.
- Jennifer Saunders has won a Rose d'Or Light Entertainment Festival Award.
- Jennifer Saunders has won two Writers' Guild of Great Britain Awards.
- Jennifer Saunders has won a People's Choice Award.
- Anthony Veiller was born on 23 June 1903.
- Anthony Veiller died on 27 June 1965.
- Anthony Veiller was an American screenwriter.
- Anthony Veiller was an American film producer.
- Anthony Veiller was the son of Bayard Veiller.
- Anthony Veiller was the son of Margaret Wycherly.
- Anthony Veiller wrote for 41 films between 1934 and 1964.
- The role of Katniss Everdeen made Guinness World Records to recognise Lawrence as the highest - grossing action heroine of all time.
- Her reprisal of Mystique in X-Men: Days of Future Past (2014) earned her two People's Choice Awards for Favorite Actress and Favorite Action Movie Actress.
- In 2015, she starred as the eponymous inventor in the biopic Joy.
- In 2015, she won her third Golden Globe Award in the Best Actress -- Motion Picture Comedy or Musical category.
- In 2015, she received another Academy Award for Best Actress nomination.
- She received several awards and nominations for her performances in the other