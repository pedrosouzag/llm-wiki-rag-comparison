# Eddie Argos

Eddie Argos
* Eddie Argos was born Kevin Macklin.
* Eddie Argos was born on 25 October 1979.
* Eddie Argos is the lead singer of Art Brut.
* Eddie Argos is a writer of comics.
* Eddie Argos is English.
* Art Brut is an English rock band.