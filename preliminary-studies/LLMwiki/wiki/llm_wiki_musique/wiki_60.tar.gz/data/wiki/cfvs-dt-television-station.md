# CFVS-DT Television Station

CFVS-DT is branded on-air as V Abitibi-Témiscamingue.
CFVS-DT is a French language television station.
CFVS-DT is affiliated with V.
CFVS-DT serves Quebec's Abitibi-Témiscamingue region.
CFVS-DT is licensed to Val-d'Or, Quebec, Canada.
CFVS-DT broadcasts a digital signal.
CFVS-DT broadcasts on UHF channel 15.
CFVS-DT broadcasts on virtual channel 25.1 via PSIP.
CFVS-DT broadcasts from a transmitter near Route Québec Lithium in La Corne.
CFVS-DT operates a rebroadcaster in Rouyn-Noranda (CFVS-DT-1).
CFVS-DT-1 operates on UHF channel 20.
Both transmitters flash-cut to digital on September 1, 2011.