# Varjak Paw Novel

Varjak Paw
- Varjak Paw (2003) is a novel.
- The author of Varjak Paw is S. F. Said.
- The illustrator of Varjak Paw is Dave McKean.
- The illustrations have a dark "gothic" quality.
- Varjak Paw received the 2003 Smarties Gold Award for the 6–8 years range.
- Varjak Paw has been adapted for other media.
- Varjak Paw (2003) is a novel by the British author S. F. Said.
- The illustrations in this book have a dark "gothic" quality.
- The novel received the 2003 Smarties Gold Award for the 6–8 years range, and has been adapted for other media.