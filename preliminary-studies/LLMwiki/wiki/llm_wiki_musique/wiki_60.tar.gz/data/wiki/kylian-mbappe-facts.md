# Kylian Mbappé Facts

Kylian Mbappé
- Kylian Mbappé received the Best Young Player Award at the 2018 FIFA World Cup.
- Kylian Mbappé’s full name is Kylian Mbappé Lottin.
- Kylian Mbappé’s date of birth is 20 December 1998.
- Kylian Mbappé’s age is 19.
- Kylian Mbappé was born in Paris, France.
- Kylian Mbappé’s height is 1.78 m.
- Kylian Mbappé’s height is 5 ft 10 in.
- Kylian Mbappé plays as a forward.
- Kylian Mbappé’s current team is Paris Saint - Germain.
- Kylian Mbappé’s number is 7.
- Kylian Mbappé played for AS Bondy from 20
- The final took place on 15 July.
- The final took place at the Luzhniki Stadium in Moscow.
- France won the match 4 -- 2.
- France claimed their second World Cup title.
- It marked the fourth consecutive title won by a European team.
- Abderrahim Achchakir was born on December 15, 1986.
- Abderrahim Achchakir plays for FAR Rabat.
- Abderrahim Achchakir is a member of the Morocco national team.
- Abderrahim Achchakir was a member of the Morocco national team at the 2013 Africa Cup of Nations in South Africa.