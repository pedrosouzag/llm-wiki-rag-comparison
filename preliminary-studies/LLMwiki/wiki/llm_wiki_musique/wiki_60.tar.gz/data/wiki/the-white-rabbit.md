# The White Rabbit

White Rabbit
- The White Rabbit is a fictional character in "Alice's Adventures in Wonderland".
- He appears at the beginning of the book, in chapter one.
- He is wearing a waistcoat.
- He mutters "Oh dear! Oh dear! I shall be too late!"
- Alice follows him down the rabbit hole into Wonderland.
- He mistakes Alice for his housemaid Mary Ann.
- Alice grows too large and becomes trapped in his house.
- He appears as a herald-like servant of the King and Queen of Hearts.
- Flemish Giant Rabbits weigh 15 pounds on average.
- The biggest ones can weigh up to 22 lb.
- The longest one on record measured about 4 feet 3 inches long.
- It holds the record for the longest rabbit in the world of any kind.
- School for Secrets is also known as Secret Flight.
- It is a 1946 British black and white film.
- It was written and directed by Peter Ustinov.
- It stars Ralph Richardson.
- David Tomlinson, Raymond Huntley, Finlay Currie, Richard Attenborough, John Laurie and Michael Hordern are in leading supporting roles.
- The film celebrates the discovery of radar.
- It was developed with the full cooperation of the Air Ministry.