# Josh LaBove, Actor

Josh LaBove
- Joshua Labove was born on March 22, 1986.
- Joshua Labove was born in Manhasset, New York.
- He has been credited in TV and film performances as a child actor.
- He was a child actor in the late 1980s.
- He was a child actor in the 1990s.
- Heather Morgan is an American actress and comedian.
- She was a cast member and writer on "The Dana Carvey Show".
- She wrote and performed such notable skits as Jenny and First Ladies as Dogs.
- The skits Jenny and First Ladies as Dogs were called "one of the two or three funniest things on the show" by writer and producer Robert Smigel.
- Morgan wrote, produced and starred in the movie "Bark!".
- "Bark!" was nominated for a Grand Jury Prize at the 2002 Sundance Film Festival.
- She is an alum of The Groundlings.
- Kevin Sussman was born on December 4, 1970.
- He is an American actor.
- He is known for playing Stuart Bloom on the CBS sitcom The Big Bang Theory.
- He is known for playing Walter on the ABC comedy - drama Ugly Betty.
- Starting with the sixth season of The Big Bang Theory, he was promoted to a series regular.