# Global Allele Distributions

- Coop et al. (2009) found a selected allele that differentiates the French from the Yoruba and Han
- The selected allele could be strongly clinal across Europe
- The selected allele could be at high frequency in Europe and absent elsewhere
- The global geographic distributions of putatively selected alleles are largely determined by their frequencies in Yoruba, French and Han
- The global distributions fall into three major geographic patterns
- The three geographic patterns are non-African sweeps
- The three geographic patterns are west Eurasian sweeps
- The three geographic patterns are East Asian sweeps