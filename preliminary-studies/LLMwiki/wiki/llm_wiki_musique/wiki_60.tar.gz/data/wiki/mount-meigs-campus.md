# Mount Meigs Campus

Mount Meigs Campus
- The Mount Meigs Campus is a juvenile corrections facility.
- It is a facility of the Alabama Department of Youth Services.
- It is located in Mount Meigs, unincorporated Montgomery County.
- It serves as the agency's administrative headquarters.
- The campus can house 264 boys.
- It is next to Interstate 85 North.
- It is east of Downtown Montgomery.
- Since 2015, the J. Walter Wood Treatment facility for 24 girls is also located in the Mount Meigs Campus.
- The separate J. Walter Wood Treatment facility for 24 girls is also located in the Mount Meigs Campus.