# The Great Lakes Group

- The Great Lakes Group is an American full-service marine-related transportation company.
- The Great Lakes Group is headquartered in Cleveland, Ohio.
- The Great Lakes Group is the parent company to The Great Lakes Towing Company.
- The Great Lakes Group is the parent company to Great Lakes Shipyard.
- The Great Lakes Group is the parent company to Tugz International L.L.C.
- The Great Lakes Group is the parent company to Puerto Rico Towing & Barge Co.
- The Great Lakes Group is the parent company to Soo Linehandling Services.
- The Great Lakes Group is the parent company to Admiral Towing and Barge Company.
- The Great Lakes Group is the parent company to Wind Logistics, Inc.
- Black Wolf Lodge was founded in 1997 by brothers Jack and Andrew ``Turk ''Waterman.
- Brothers Jack and Andrew ``Turk ''Waterman were the original owners of Noah's Ark water park in Wisconsin Dells, Wisconsin.
- Black Wolf Lodge was purchased by The Great Lakes Company in 1999.
- Marc Vaccaro and Bruce Neviaser changed the name to Great Wolf Lodge in 1999.
- The company headquarters were established in Madison, Wisconsin in 1999.
- The company built a second location in Sandusky, Ohio in 2001.
- The second location was named Great Bear Lodge in 200