# Vocal Instrumentation Emulation

A cappella
- Some a cappella singers emulate instrumentation.
- Some a cappella singers reproduce instrumental sounds with their vocal cords and mouth.
- The Mills Brothers were early practitioners of emulating instrumentation.
- The Mills Brothers’ early recordings from the 1930s stated instrumentation was done vocally.
- "Twilight Zone" by 2 Unlimited was sung a cappella to the instrumentation on Tompkins Square.
- The theme song for The New Addams Family series on Fox Family Channel (now ABC Family) emulates instrumentation.
- Vocal Sampling emulates Latin rhythms a cappella.
- Undivided emulates Latin rhythms a cappella.
- The Swingle Singers emulated musical instruments to Baroque and Classical music in the 1960s.
- Bobby McFerrin is a vocal artist famous for instrumental emulation.
- Naturally Seven recreates entire songs using vocal tones for every instrument.