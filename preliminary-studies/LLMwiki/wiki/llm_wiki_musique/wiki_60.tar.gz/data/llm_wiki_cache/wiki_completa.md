# ```

Sonnet 110
- Sonnet 110 is one of 154 sonnets written by William Shakespeare.
- Sonnet 110 was published along with the other sonnets in the 1609 Quarto.
- The sonnet falls in place with the Fair Youth sequence of Shakespeare's sonnets.
- The poet expresses his love towards a young man in the sonnet.
- The mystery of the young man is still unknown today.
- Various scholars have different theories about who this young man may be.
- There has been debate whether or not this sonnet was written about Shakespeare's disdain with the stage and actors.
- Some have interpreted sonnet 110 as the poet confessing his love to a young man.
- The Emperor's Children is a 2006 novel.
- The author of The Emperor's Children is Claire Messud.
- The Emperor's Children was Claire Messud's third novel.
- The Emperor's Children was Claire Messud's first best-seller.
- The Emperor's Children was longlisted for the 2006 Man Booker Prize.
- Actor Role Erin Cottrell
- Missie LaHaye
- Logan Bartholomew
- Willie LaHaye
- Frank McRae
- Cookie
- Irene Bedard
- Miriam McClaine
- Gil Birmingham
- Sharp Claw
- W. Morgan Sheppard
- Scottie
- James Tupper
- Henry Kline
- Johann Urb
- Fyn
- Anders
- Jeff Kober
- Pacey
- Richard Lee Jackson
- Sonny
- Huff
- Graham Phillips
- Jeff Huff
- Stephen Bridgewater
- Mr. Taylorsen
- Diane Salinger
- Diane Louise Salinger
- John Savage
- Trent
- British nationality law is determined by lex soli.
- By birth in the UK or a qualified British Overseas Territory to a parent who is a British citizen at the time of the birth, one can obtain British citizenship.
- One can obtain British citizenship if they are born in the UK or a qualified British Overseas Territory to a parent who is settled in the UK or that Overseas Territory.
- British nationality law is determined by lex sanguinis.
- British citizenship by descent is only transferable to one generation down from the parent who is a British citizen otherwise than by descent, if the child is born abroad.
- One can obtain British citizenship by naturalisation.
- One can obtain British citizenship by registration.
- One can obtain
- The Portrait of Pietro Aretino is a portrait of the Renaissance poet Pietro Aretino by Titian.
- The portrait was painted around 1545, possibly for Cosimo I de' Medici.
- The portrait is now in the sali di Venere of Palazzo Pitti in Florence.
- The Wreck Of The Zanzibar is a children's novel.
- The author of The Wreck Of The Zanzibar is Michael Morpurgo.
- The Wreck Of The Zanzibar was first published in Great Britain by William Heinemann Publishers in 1995.
- The book won the Whitbread Children's Book Award in 1995.
- La Rosière de Pessac (The Virgin of Pessac) is the title of two hour-long films directed by Jean Eustache.
- The films were directed in 1968 and 1979 respectively.
- The films cover an annual ceremony held in Jean Eustache's place of birth.
- The ceremony involves the mayor and his associates nominating a girl as the town's most virtuous.
- The girls chosen in those two years are eponymous subjects of these documentaries.
- By birth abroad, which constitutes ``by descent ''if one of the parents is a British citizen otherwise than by descent (for example by birth, adoption, registration or naturalisation in the UK).
- By naturalisation
- By registration
- By adoption
- Lucy Neal Dahl was born on 4 August 1965.
- Lucy Neal Dahl is a British screenwriter.
- Lucy Neal Dahl is the daughter of Roald Dahl and Patricia Neal.
- Roald Dahl was a British author.
- Patricia Neal was an American actress.
- Fatma Begum was an Indian actress, director, and screenwriter.
- She is often considered the first female film director of Indian cinema.
- She launched her own production house, Fatma Films, and directed Bulbul-e-Paristan in 1926.
- She lived from 1892-1983.
- She was mother to three children.
- Upi Avianto is an Indonesian screenwriter and film director.
- Upi Avianto has worked on several of Indonesia's most popular films in the 2000s.
- She directed the 2004 film "30 Days Looking for Love" ("30 Hari Mencari Cinta").
- The 2004 film "30 Days Looking for Love" ("30 Hari Mencari Cinta") founded the film career of actress Nirina Zubir.

# 1969 Mexican Grand Prix

- The 1969 Gran Premio de Mexico was also known as the Mexican Grand Prix.
- The race was held at the Ciudad Deportiva Magdalena Mixhuca, Mexico City.
- The race was held on October 19, 1969.
- The race was held two weeks after the United States Grand Prix at Watkins Glen.
- It was race 11 of 11 in the 1969 World Championship of Drivers.
- It was race 11 of 11 in the 1969 International Cup for Formula One Manufacturers.
- Denny Hulme won the 65-lap race.
- Denny Hulme started from fourth position.
- Jacky Ickx finished second for the Brabham team.
- Jack Brabham came in third.
- The Municipality of Nuevo Laredo is located in the Mexican state of Tamaulipas.
- Its municipal seat is Nuevo Laredo.
- The municipality contains more than 60 localities.
- The most important localities are Nuevo Laredo, El Campanario y Oradel, and Álvarez.
- Álvarez is a suburb of the city of Nuevo Laredo.
- El Campanario y Oradel are suburbs of the city of Nuevo Laredo.
- The municipality is the third largest in the state of Tamaulipas (behind Reynosa and Matamoros respectively).
- The Nuevo Laredo municipality is the northernmost in Tamaulipas.
- The city of Nuevo Laredo contains approximately 97.5
- Lloyd Dane was born on August 19, 1925.
- Lloyd Dane died on December 11, 2015.
- Lloyd Dane was a NASCAR Grand National Series driver from Eldon, Missouri.
- Lloyd Dane participated part-time in the 1951 and 1954 to 1964 seasons.
- Lloyd Dane captured four wins, all in his own car.
- Two of Lloyd Dane's wins came during the 1956 season.
- Lloyd Dane finished 23rd in points during the 1956 season.

# 2006 Men's Basketball Tournament

2006 NCAA Division I Men's Basketball Tournament
- LSU scored 45 points.
- UCLA scored 59 points.
- UCLA scored 57 points.
- Florida scored 73 points.
- Florida scored 73 points.
- George Mason scored 58 points.
- The Sacramento Kings are an American professional basketball team.
- The Sacramento Kings are based in Sacramento, California.
- The Sacramento Kings compete in the National Basketball Association (NBA).
- The Sacramento Kings are a member of the Western Conference's Pacific Division.
- The Sacramento Kings are the only team in the major professional North American sports leagues located in Sacramento.
- The Sacramento Kings play their home games at the Golden 1 Center.

# 2010 Tomato Shortage

- The 2010 United States tomato shortage occurred between March and April 2010
- The shortage was caused by unseasonably cold weather in Florida in January 2010
- The cold weather destroyed 60-70% of Florida's tomato crop
- There was a tomato shortage over the new year holiday
- The new year shortage was caused by the Californian harvest finishing before the Florida harvest began

# A Little Bit of Love (song)

- "A Little Bit of Love" is a song written by Andreas Johnson and Peter Kvint.
- Andreas Johnson performed "A Little Bit of Love" at Melodifestivalen 2007.
- The song participated in the semifinale in Gävle on 24 February 2007.
- The song headed directly to the finals inside the Stockholm Globe Arena on 10 March 2007.
- The song finished second.
- The single was released on 5 March 2007.
- The single peaked at third position at the Swedish singles chart.
- The song became a major radio hit at Sveriges Radio.
- The song became a major radio hit at the commercial stadions.

# A Prisoner of Birth

- A Prisoner of Birth is a mystery novel.
- Jeffrey Archer is the author of A Prisoner of Birth.
- A Prisoner of Birth was first published on 6 March 2008.
- A Prisoner of Birth was published by Macmillan.
- A Prisoner of Birth is a retelling of "The Count of Monte Cristo" by Dumas.
- Archer returned to the first place in the fiction best-seller list for the first time in a decade.
- Cornelius Clifford places Athanasius of Alexandria’s birth no earlier than 296 and no later than 298.
- Athanasius indicates no first hand recollection of the Maximian persecution of 303.
- The Arians accused Athanasius of not having yet attained the canonical age (30).
- Athanasius could not have been properly ordained as Patriarch of Alexandria in 328.
- The Orthodox Church places his year of birth around 297.

# A Sinless Season

A Sinless Season
- It is a novel by South African author Damon Galgut.
- It was published in 1982.
- The author was seventeen when it was published.
- It details the interactions between Scott, Raoul, and Joseph.
- Scott, Raoul, and Joseph are three young inmates at the Bleda reformatory.

# Adaba Woreda, Oromia

- Adaba is a woreda in the Oromia Region of Ethiopia.
- Adaba shares its name with its administrative center.
- Adaba is part of the West Arsi Zone.
- Adaba is bordered on the southwest by Nensebo.
- Adaba is bordered on the west by Dodola.
- Adaba is bordered on the northwest by the Shabelle River.
- The Shabelle River separates Adaba from Gedeb Asasa.
- Adaba is bordered on the east and south by Bale Zone.
- Jimma Arjo is one of the woredas in the Oromia Region of Ethiopia.
- Jimma Arjo shares the name of one of the subgroups of the Oromo people, the Jimma Arjo.
- Jimma Arjo is part of the Misraq Welega Zone.
- Jimma Arjo is bordered on the southwest by the Didessa River which separates it from the Illubabor Zone.
- Jimma Arjo is bordered on the northwest by Diga Leka.
- Jimma Arjo is bordered on the northeast by Guto Wayu.
- Jimma Arjo is bordered on the southeast by Nunu Kumba.
- The administrative center of Jimma Ar
- Adaba is one of the woredas in the Oromia Region of Ethiopia.
- Adaba shares the name of its administrative center, Adaba.
- Adaba is bordered on the northwest by the Shabelle River which separates it from the Gedeb Asasa.
- Berahle is one of the woredas in the Afar Region of Ethiopia.
- Part of Berahle's territory includes part of the Afar Depression.
- Berahle is bordered on the south by Afdera.
- Berahle is bordered on the south by Abala.
- Berahle is bordered on the southwest by the Tigray Region.
- Berahle is bordered on the west by Koneba.
- Berahle is bordered on the north by Dallol.
- Berahle is bordered on the northeast by Eritrea.
- Towns in Berahle include Berhale.
- Towns in Berahle include Tiyarabora.

# Adam's Rib (1949 film)

- Adam's Rib is a 1949 American romantic comedy film.
- It was directed by George Cukor.
- The screenplay was written by Ruth Gordon and Garson Kanin.
- It stars Spencer Tracy and Katharine Hepburn.
- They play married lawyers who oppose each other in court.
- Judy Holliday co-stars as the third lead.
- This is Judy Holliday's second credited movie role.
- The music was composed by Miklós Rózsa.
- "Farewell, Amanda" was written by Cole Porter.
- James Dearden is an English film director and screenwriter.
- He was born on 14 September 1949.
- He is the son of Melissa Stribling and Basil Dearden.
- He directed seven films between 1977 and 1999.
- His film "Pascali's Island" was entered into the 1988 Cannes Film Festival.
- He is married to Annabel Brooks.
- The Actress is a 1953 American comedy-drama film.
- The Actress is based on Ruth Gordon's autobiographical play "Years Ago".
- Ruth Gordon wrote the screenplay for The Actress.
- George Cukor directed The Actress.
- Jean Simmons stars in The Actress.
- Teresa Wright stars in The Actress.
- Anthony Perkins appears in The Actress in his film debut.

# Adobe LiveCycle Designer

Adobe LiveCycle Designer
- It is a forms authoring tool
- It is published by Adobe Systems
- It renders XML forms as PDF or HTML files
- It is a one-stop design tool

# Aerojet Rocket Propulsion

Aerojet was an American rocket and missile propulsion manufacturer
Aerojet was based primarily in Rancho Cordova, California
Aerojet had divisions in Redmond, Washington
Aerojet had divisions in Orange, Virginia
Aerojet had divisions in Gainesville, Virginia
Aerojet had divisions in Camden, Arkansas
Aerojet was owned by GenCorp
In 2013, Aerojet was merged with Pratt & Whitney Rocketdyne
The merged company was named Aerojet Rocketdyne

# Alamnagar (community development block)

Alamnagar (community development block)
- Alamnagar is an administrative division of Madhepura district.
- Alamnagar is in the Indian state of Bihar.
- The block headquarters are located 58 km from Madhepura.
- The name of Alamnagar is named for Shah Alamgir.
- The block headquarters are located at a distance of 58 km from the district headquarters, namely, Madhepura.
- The block headquarters are located at a distance of 58 km from the district headquarters, namely, Madhepura.
- Alamnagar (community development block) is one of the administrative divisions of Madhepura district in the Indian state of Bihar.

# Albert Tyler, Biologist

- Albert Tyler was a biologist.
- Albert Tyler was born in Brooklyn, New York.
- Albert Tyler attended Columbia University.
- Albert Tyler majored in chemistry.
- Albert Tyler took interest in the work of Thomas Hunt Morgan.
- Thomas Hunt Morgan hired to establish the new Division of Biology at the California Institute of Technology.
- Thomas Hunt Morgan took Albert Tyler to the California Institute of Technology.
- Albert Tyler completed his Ph.D. studies on reproductive biology.
- Albert Tyler was appointed to the faculty at Caltech.
- David Gardiner Tyler was born on July 12, 1846.
- David Gardiner Tyler died on September 5, 1927.
- David Gardiner Tyler was the ninth child of John Tyler.
- David Gardiner Tyler was the fourth son of John Tyler.
- David Gardiner Tyler was a U.S. Democratic Party politician.
- Wilber Morris recorded widely.
- Wilber Morris performed with Pharoah Sanders.
- Wilber Morris performed with Sonny Simmons.
- Wilber Morris performed with Alan Silva.
- Wilber Morris performed with Joe McPhee.
- Wilber Morris performed with Horace Tapscott.
- Wilber Morris performed with Butch Morris.
- Wilber Morris performed with Arthur Blythe.
- Wilber Morris performed with Charles Gayle.
- Wilber Morris performed with William Parker.
- Wilber Morris performed with Billy Bang.
- Wilber Morris performed with Charles Tyler.
- Wilber Morris performed with Dennis Charles.
- Wilber Morris performed with Roy Campbell.
- Wilber Morris performed with Avram Fefer.
- Wilber Morris performed with Alfred 2

# Alexandre de Lesseps Biography

Alexandre de Lesseps
- Alexandre de Lesseps was born in Paris, France.
- His education took place in Khartoum, Sudan.
- His education took place in France.
- His education took place at Northwestern University in Chicago, Illinois.
- Dupland was a sailor from France.
- Dupland represented France at the 1900 Summer Olympics in Meulan, France.
- Dupland took the 10th place in the first race of the 0.5 to 1 ton.
- Dupland finished 7th in the second race.
- Dupland used the boat "Galopin".

# Alfred Nobel's Literature Prize

Nobel Prize in Literature
- The Nobel Prize in Literature is a Swedish literature prize.
- The prize is awarded annually since 1901.
- The prize is awarded to an author from any country.
- The prize is awarded to an author who has produced the most outstanding work in an ideal direction.
- The award is based on an author's body of work as a whole.
- The Swedish Academy decides who will receive the prize.
- The Swedish Academy announces the name of the laureate in early October.
- The prize is one of the five Nobel Prizes established by the will of Alfred Nobel in 1895.
- The prize will not be awarded in 2018.
- Two names will be awarded in 2019.
- The PEN/Diamonstein-Spielvogel Award for the Art of the Essay is awarded by the PEN American Center.
- The award is for a book of original collected essays.
- The award was founded by Barbaralee Diamonstein and Carl Spielvogel.
- Carl Spielvogel was a former "New York Times" columnist.
- The award was founded "to preserve the dignity and esteem that the essay form imparts to literature."
- The winner receives a cash award of $10,000.
- Audrey Hepburn received numerous awards and honors during her career.
- Hepburn won awards for her work in motion pictures, television, spoken - word recording, on stage, and humanitarian work.
- Hepburn was nominated for an Academy Award five times.
- Hepburn was awarded the 1954 Academy Award for Best Actress for her performance in Roman Holiday.
- Hepburn received the Jean Hersholt Humanitarian Award in 1993, post-humously.
- Hepburn won a record three BAFTA Awards for Best British Actress in a Leading Role, from five nominations.
- Hepburn received a Lifetime Achievement Award in 1992.
- Hepburn received 10 Golden Globe Award nominations, winning two.
- Six laureates have received more than one prize.
- The International Committee of the Red Cross has received the Nobel Peace Prize three times.
- UNHCR has been awarded the Nobel Peace Prize twice.
- John Bardeen was awarded the Nobel Prize in Physics twice.
- Frederick Sanger was awarded the Nobel Prize in Chemistry.
- Marie Curie was awarded the Nobel Prize in Physics in 1903.
- Marie Curie was the first person (male or female) to be awarded two Nobel Prizes.
- Marie Curie was also awarded the Nobel Prize in Chemistry, given in 1911.
- Linus Pauling was awarded twice but not in the same field.
- Among the 89
- Dinner at the Homesick Restaurant is a 1982 novel.
- Dinner at the Homesick Restaurant is set in Baltimore, Maryland.
- It is Anne Tyler's ninth novel.
- In 1983 it was a finalist for the Pulitzer Prize.
- In 1983 it was a finalist for the National Book Award.
- In 1983 it was a finalist for the PEN/Faulkner Award.
- Anne Tyler considers it her best work.
- Rabbit Ears Productions is a production company.
- Rabbit Ears Productions is best known for producing three TV series.
- The TV series feature individual episodes adapting popular pieces of children's literature.
- The TV series aired from 1984-1995 on PBS.
- The series features actors such as Robin Williams, Raul Julia, Laura Dern, Denzel Washington, Meryl Streep, John Hurt, Danny Glover, and others.
- The series features actors narrating children's books from around the world.
- Rabbit Ears Productions used a limited animation technique.
- The limited animation technique is similar to modern motion comics.
- Rabbit Ears Productions has won numerous awards.
- Rabbit
- Allison DuBois was born January 24, 1972.
- Allison DuBois is an American author.
- Allison DuBois is a purported medium.
- Allison DuBois has assisted U.S. law enforcement officials in solving crimes.
- The TV series Medium is based on Allison DuBois' psychic abilities.
- Margaret H. George is an American author.
- Margaret H. George was born in 1928.
- Margaret H. George is a former Democratic member of the Pennsylvania House of Representatives.
- Susan Evans McCloud is an American novelist.
- Susan Evans McCloud is an author.
- Susan Evans McCloud is a poet.
- Susan Evans McCloud is a hymnwriter.
- Susan Evans McCloud is a member of The Church of Jesus Christ of Latter-day Saints (LDS Church).
- Susan Evans McCloud was born July 28, 1945.
- Haig Aram Bosmajian (March 26, 1928- June 17, 2014) was an author, lecturer, and professor.
- Haig Bosmajian received the 1983 Orwell Award for his book "The Language of Oppression" (1974).
- Haig Bosmajian received a PhD in 1960 from Stanford University.
- Haig Bosmajian's work has explored rhetoric and the freedom of speech.
- Haig Bosmajian was professor emeritus at the University of Washington, in the Speech/Communications Department.
- Haig Bosmajian taught at the University of Washington since 1
- The Goblin Emperor is a 2014 fantasy novel.
- The author is Sarah Monette.
- Sarah Monette wrote under the pseudonym Katherine Addison.
- The novel received the Locus Award for Best Fantasy Novel.
- The novel was nominated for the Nebula, Hugo and World Fantasy Awards.
- Critics noted the strength of the protagonist's characterization.
- The work has a warm and understated tone.
- Driving Miss Daisy won four awards.
- Jessica Tandy won Best Actress.
- Jessica Tandy was the oldest person at the time to win a competitive acting Oscar.
- Glory won three awards.
- The Little Mermaid won two awards.
- My Left Foot won two awards.
- The Abyss won one award.
- Balance won one award.
- Batman won one award.
- Cinema Paradiso won one award.
- Common Threads: Stories from the Quilt won one award.
- Dead Poets Society won one award.
- Henry V won one award.
- Indiana Jones and the Last Crusade won one award.
- The Johnstown Flood won one award.
- Work Experience won one
- Patrick Modiano (born 30 July 1945) is a French novelist.
- Patrick Modiano is a recipient of the 2014 Nobel Prize in Literature.
- He previously won the 2012 Austrian State Prize for European Literature.
- He won the 2010 Prix mondial Cino Del Duca from the Institut de France for lifetime achievement.
- He won the 1978 Prix Goncourt for "Rue des boutiques obscures".
- He won the 1972 Grand Prix du roman de l'Académie française for "Les Boulevards de ceinture".
- His works have been translated into more than 30 languages.
- 892 Nobel laureates have been awarded a Nobel Prize.
- 48 of the Nobel laureates have been women.
- The first woman to receive a Nobel Prize was Marie Curie.
- Frederick Sanger was awarded the Nobel Prize in Chemistry twice.
- Marie Curie received the Nobel Prize in Physics in 1903.
- Marie Curie received the Nobel Prize in Chemistry in 1911.

# Algeria as French Territory

French Algeria

- Shortly after the 1848 revolution, the Second Republic ended Algeria's status as a colony.
- The 1848 Constitution declared the occupied lands an integral part of France.
- Alger, Oran, and Constantine were organized as Departments of France.
- Departments of France were local administrative units.
- French citizens in the civil territories elected their own councils and mayors.
- Muslims could not hold more than one-third of council seats.
- Muslims could not serve as mayors or assistant mayors.
- The administration of territories outside the zones settled by colons remained under the French Army.
- Local Muslim administration was allowed to continue under the supervision of French Army commanders.
- French Army commanders were charged with maintaining order in newly pacified regions.
- The bureaux arabes supervised local Muslim administration.
- These areas were theoretically closed to European colonization.

# Alice Cooper - Fistful of Alice

A Fistful of Alice
- A Fistful of Alice is a live album by Alice Cooper.
- It was released in 1997.
- It was recorded in 1996.
- It was recorded at Sammy Hagar's Cabo Wabo club in Cabo San Lucas, Mexico.
- Slash plays guitar for part of the album.
- Cooper guested on "The Garden" in 1991.
- "The Garden" is on the Guns N' Roses album "Use Your Illusion I".
- Cooper says "Desperado" was written about Jim Morrison.
- Jim Morrison died in 1971.
- Cooper wrote the song "Desperado" in 1971.
- Rob Zombie is on vocals in the album.
- Sammy Hagar is on guitar in the album.
- The title track from 1991's "Hey Sto

# Almost Made Ya Song

Almost Made Ya
- It is an R&B song by American duo Ali & Gipp
- It is on the album "Kinfolk" (2007)
- It samples Brandy's "Almost Doesn't Count"
- It is about a relationship between a female and a male
- LeToya sings that she is "almost done" with her man
- LeToya sings that "they" need to improve the relationship
- The men say about the situation they've been passing
- It leaked on April 13, 2007
- It was officially released on Sunday, June 13, 2007
- It was written by LeToya Luckett
- It was written by Jermaine Dupri
- It was written by Ali Vaskabi-Waski-Jones
- It was written by Cameron Gipp
- It was written by Shelly Peiken
- It was
- Kinfolk is the debut and only album by American rap duo Ali & Gipp
- It was released on August 14, 2007
- It was released through Derrty Entertainment and Universal Records
- "Go 'Head" featuring Chocolate Tai was the first single off the album
- "N da Paint" featuring Nelly is the second single
- "Work Dat, Twerk Dat" featuring Murphy Lee is the third single
- "Almost Made Ya" featuring LeToya Luckett is the fourth and final single
- "The Horse" is an American instrumental song by Cliff Nobles and Company.
- It was released as the B-side of the single "Love is All Right".
- It peaked at #2 on the US "Billboard" Hot 100 chart (in June 1968).
- It peaked at #2 on the US "Billboard" R&B chart.

# Alvin and the Chipettes

- Justin Long is Alvin Seville
- Matthew Gray Gubler is Simon Seville
- Jesse McCartney is Theodore Seville
- Christina Applegate is Brittany
- Anna Faris is Jeanette
- Kaley Cuoco is Eleanor
- Robbie Amell is Fred
- Kate Melton is Daphne
- Hayley Kiyoko is Velma
- Nick Palatas is Shaggy
- Frank Welker provides Scooby's voice

# Amamoor Forest Reserve

- The Amamoor Forest Reserve is in the Gympie Region in Queensland, Australia.
- The forest is a riverine rainforest.
- The forest is composed of subtropical vegetation.
- The forest is dominated by stands of "Melia azedarach" (white cedar).
- The forest is dominated by stands of "Toona ciliata" (red cedar).
- The forest is dominated by stands of "Araucaria cunninghamii" (hoop pine).
- The forest is dominated by stands of "A. bidwillii" (Bunya pine).
- Amamoor creek within the reserve is a habitat for the platypus.
- Amamoor creek within the reserve is a habitat for several species of endangered frogs.
- The park station is located on Amamoor Creek Road.
- The park station is 180 kilometers north of Brisbane.
- The park station is 20 kilometers southwest of Gym

# Amblin Entertainment

- Amblin Entertainment is an American film production company.
- Steven Spielberg founded Amblin Entertainment.
- Kathleen Kennedy founded Amblin Entertainment.
- Frank Marshall founded Amblin Entertainment.
- Amblin Entertainment was founded in 1981.
- The company's headquarters are located on the backlot of Universal Studios.
- The company's headquarters are located in Universal City, California.
- Amblin Entertainment distributes films from Amblin Partners.
- The films are distributed under the Amblin Entertainment name.
- Little Miss Marker is a 1980 American comedy-drama film.
- Walter Bernstein wrote and directed Little Miss Marker.
- Little Miss Marker is based on a short story by Damon Runyon.
- Walter Matthau stars in Little Miss Marker.
- Tony Curtis stars in Little Miss Marker.
- Julie Andrews stars in Little Miss Marker.
- Bob Newhart stars in Little Miss Marker.
- Sara Stimson stars in Little Miss Marker.
- Little Miss Marker is a remake of the 1934 film of the same name.
- Shirley Temple starred in the 1934 film Little Miss Marker.
- Adolphe Menjou starred in the 1934

# Amulya's Filmography

Amulya
- Her first film was "Khushi Khushiyagi" in 2015.
- She was paired opposite Ganesh for the third time in "Khushi Khushiyagi".
- Critics praised her performance as Nandini in "Khushi Khushiyagi".
- G. S. Kumar of "The Times of India" wrote about shades of 'Shravani Subramanya' in her role.
- In "Male", she played a tomboyish role as Varsha.
- She was paired opposite Prem Kumar in "Male".
- In "Ram-Leela", she played Chandrakala, the sister of a don.
- In "Ram-Leela", she played the love interest of Chiranjeevi Sarja.
- "Ram-Leela" received mixed response from critics.
- In "Maduveya Mamatheya Kareyole", she portrayed "a meaty character that

# Andrićev Venac, Belgrade

- Andrićev Venac is a street.
- Andrićev Venac is an urban neighborhood.
- Andrićev Venac is located in Belgrade.
- Andrićev Venac is located in the municipality of Stari Grad.
- The official seat of the President of Serbia is located in Andrićev Venac.
- Andrićev Venac became synonymous for the politics of the president.
- San Marino has an embassy in Belgrade.
- Ubaldo Livolsi is the Ambassador of San Marino to Serbia.
- Ambassador Livolsi presented his Letters of Credence on February 2, 2005.
- The Ambassador of Serbia to Italy accredited on non-residential basis to San Marino is Sanda Rašković Ivić.

# Angelīna Kučvaļska Biography

Angelīna Kučvaļska
- Angelīna Kučvaļska was born on 6 December 1998
- Angelīna Kučvaļska was born in Saldus, Latvia
- Her father died when she was 12 years old
- She is a student at Riga 1st secondary school
- Bùi Bích Phương was born in 1971.
- Bùi Bích Phương was born in Hanoi.
- Bùi Bích Phương was crowned Miss Vietnam in 1988.
- Bùi Bích Phương was a first year English student at the University of Hanoi.
- Bùi Bích Phương was the first person ever to be crowned Miss Vietnam.
- Bùi Bích Phương was 17 years old when she won the title.
- Bùi Bích Phương is 5'2" tall.
- Bùi Bích Phương can speak fluent English, Korean and Vietnamese.
- Bùi Bích Phương is a successful business woman.
- Bùi
- Rachael Finch was born on 8 July 1988
- Rachael Finch is an Australian TV host
- Rachael Finch is an Australian model
- Rachael Finch was awarded the 'People's Choice Award' for the 2006 Miss Teen Australia
- Rachael Finch finished as 3rd runner-up at Miss Universe 2009

# Arena Football League Model

Arena Football League
- The league runs under a single-entity model.
- The league owns the rights to the teams, players, and coaches.
- The single-entity model was adopted in 2010.
- The league emerged from bankruptcy in 2010.
- Prior to 2010, the league followed the franchise model.
- Each team essentially operated as its own business.
- The league provided rules, officials, scheduling, and organizational structure.
- A pool of money is allotted to teams to aid in travel costs.
- Tom Benson announced that the New Orleans VooDoo were ceasing operations.
- The New Orleans VooDoo were folding "based on circumstances currently affecting the league and the team".
- The AFL had a tentative agreement to sell a $100 million stake in the league to Platinum Equity.
- Platinum Equity would create a centralized, single-entity business model.
- Platinum Equity would streamline league and team operations.
- Platinum Equity would allow the league to be more profitable.
- Benson's move to shut down the VooDoo came during the Platinum Equity conference call.
- There was speculation that Benson had folded because of the deal.
- The 2015 AFL Grand Final was an Australian rules football match.
- The match was contested between the Hawthorn Football Club and the West Coast Eagles.
- The match was held at the Melbourne Cricket Ground on 3 October 2015.
- It was the 119th annual Grand Final of the Australian Football League.
- The match was attended by 98,632 spectators.
- Hawthorn won the match by a margin of 46 points.
- Hawthorn won their third consecutive premiership.
- Hawthorn won their thirteenth VFL/AFL premiership victory overall.
- Cyril Rioli was awarded the Norm Smith Medal.

# Arthur Dickey, Canadian Politician

Arthur Rupert Dickey was born in Amherst, Nova Scotia.
Robert Barry Dickey was his father.
Charles Tupper was named High Commissioner for Canada in the United Kingdom.
He was elected to the House of Commons of Canada in an 1888 by-election.
He was elected in the riding of Cumberland.
He was a lawyer.
He was a Conservative.
He was re-elected in 1891.
He was re-elected in 1896.
He was Minister of Justice and Attorney General of Canada.
He was Minister of Militia and Defence.
He was Secretary of State of Canada.

# AS Monaco Coupe de France Win

- The 1979–80 Coupe de France was the 63rd Coupe de France.
- It is France's annual national football cup competition.
- It was won by AS Monaco.
- AS Monaco defeated US Orléans in the final.
- The competition was won by Napoli.
- Napoli defeated Verona in a one-legged final.
- The final was played at the Stadio Olimpico in Rome.
- The 1975–76 Coppa Italia was the 29th season of Coppa Italia.

# Asima Chatterjee's Research

Asima Chatterjee
- Asima Chatterjee (23 September 1917 – 22 November 2006)
- She was an Indian organic chemist.
- She was noted for her work in organic chemistry.
- She was noted for her work in phytomedicine.
- Her work includes research on vinca alkaloids.
- Her work includes the development of anti-epileptic drugs.
- Her work includes the development of anti-malarial drugs.
- She authored a considerable volume of work on medicinal plants of the Indian subcontinent.
- She was the first woman to receive a Doctorate of Science from an Indian university.
- Her most notable work includes research on vinca alkaloids.
- Her most notable work includes the development of anti-epileptic drugs.
- Her most notable work includes development of anti-malarial drugs.

# Audrey Rose (novel)

Audrey Rose is a novel.
It was written by Frank De Felitta.
It was published in 1975.
It is about a couple and their daughter.
The couple is confronted with the idea that their daughter might be the reincarnation of another man's child.
The book was inspired by an incident involving De Felitta's son.
De Felitta's son began displaying unusual talents and interests.
An occultist suggested the son might be remembering a previous life.
It was followed by a 1982 sequel, "For Love of Audrey Rose".
- A Prisoner of Birth is a mystery novel.
- A Prisoner of Birth is by English author Jeffrey Archer.
- A Prisoner of Birth was first published on 6 March 2008.
- A Prisoner of Birth was published by Macmillan.
- A Prisoner of Birth is a contemporary retelling of Dumas's "The Count of Monte Cristo".
- The novel saw Archer return to the first place in the fiction best-seller list for the first time in a decade.

# Australian Government Structure

Australian Government
- Each state and major mainland territory has its own parliament.
- The Northern Territory has a unicameral parliament.
- The ACT has a unicameral parliament.
- Queensland has a unicameral parliament.
- The other states have a bicameral parliament.
- The states are sovereign entities.
- The states are subject to certain powers of the Commonwealth.
- The lower houses are known as the Legislative Assembly.
- The House of Assembly is the name of the lower house in South Australia.
- The House of Assembly is the name of the lower house in Tasmania.
- The upper houses are known as the Legislative Council.
- The head of the government in each state is the Premier.
- The head of the government in each territory is the Chief Minister.
- The Queen is represented in each state by a governor.
- The Northern Territory is represented by an Administrator.
- The Governor-General represents the
- Brazil's federation is tripartite, encompassing the Union, the States, and the municipalities.
- Each state in Brazil is divided into municipalities (municípios).
- Municipalities in Brazil have their own legislative council (câmara de vereadores) and a mayor (prefeito).
- Municipalities in Brazil have a "little constitution", called "organic law" (lei orgânica).
- Mexico's municipalities are granted full-autonomy by the federal constitution.
- Mexico's federal constitution determines which powers and competencies belong exclusively to the municipalities.
- Municipalities in Mexico do not have an elected legislative assembly.
- A federation is usually formed at two levels: the central government and the regions (states,
- There are 36 States in Nigeria.
- A Nigerian State is a federated political entity, which shares sovereignty with the Federal Government of Nigeria.
- There is a territory called the Federal Capital Territory (FCT).
- The Federal Capital Territory (FCT) is not a state.
- The Federal Capital Territory (FCT) is under the direct control of the Federal Government.
- The States are divided into a total of 774 Local Government Areas.
- Under the Nigerian Constitution, states have the power to ratify constitutional amendments.
- HM Prison Tarrengower is a women's prison.
- It is located in Maldon, Victoria, Australia.
- It focuses on release preparation.
- It provides programs and employment opportunities.
- It allows women to build confidence and skill sets.
- It allows women to gain and maintain employment whilst in custody.
- It allows women to gain and maintain employment upon their release.
- Swimming is one of the sports at the quadrennial Commonwealth Games competition.
- It has been a Commonwealth Games sport since the inaugural edition of the event's precursor, the 1930 British Empire Games.
- It is a core sport and must be included in the sporting programme of each edition of the Games.
- Synchronised swimming and Diving events are optional.
- Water polo is a recognised sport.
- The Commonwealth Parliament also directly administers the following external territories: Ashmore and Cartier Islands.
- The Commonwealth Parliament also directly administers the following external territories: Australian Antarctic Territory.
- The Commonwealth Parliament also directly administers the following external territories: Christmas Island.
- The Commonwealth Parliament also directly administers the following external territories: Cocos (Keeling) Islands.
- The Commonwealth Parliament also directly administers the following external territories: Coral Sea Islands.
- The Commonwealth Parliament also directly administers the following external territories: Heard Island and McDonald Islands.
- The Commonwealth Parliament also directly administers the following external territories: Jervis Bay Territory, a naval base and sea port for the national capital in land that was formerly part of New South Wales.
- The Queen’s representative in the Commonwealth is the Governor-General.
- The external territory of Norfolk Island previously exercised considerable autonomy under the Norfolk Island Act 1979 through its own legislative assembly and an Administrator to represent the Queen.
- In 2015, the Commonwealth Parliament abolished self-government, integrating Norfolk Island into the Australian tax and welfare systems and replacing its legislative assembly with a council.
- Macquarie Island is administered by Tasmania.
- Lord Howe Island is administered by New South Wales.
- The Red Ochre Award was established in 1993.
- The Australia Council for the Arts established the Red Ochre Award.
- The Red Ochre Award is awarded annually.
- The Red Ochre Award is for lifetime achievement.
- The award is for an outstanding Aboriginal and Torres Strait Islander artist.
- In 1970 Margaret Thatcher became Secretary of State for Education.
- She ended the compulsion on local authorities to convert.
- More comprehensive schools were established under Mrs Thatcher than any other education secretary.
- In 2015, there were 54 sovereign states and 27 non-sovereign entities where English was an official language.
- Many country subdivisions have declared English an official language at the local or regional level.
- The government planned to voluntarily evacuate four million people—mostly women and children—from urban areas, including 1.4 million from London.
- A trial blackout was held on 10 August 1939.
- A blackout began at sunset when Germany invaded Poland on 1 September.
- The blackout lasted almost six years.
- The blackout became the most unpopular aspect of the war for civilians.
- The relocation of the government and the civil service was also planned.
- The government planned the relocation of the government and the civil service so as not to damage civilian morale.
- The Naas River is a perennial stream.
- The Naas River is located in the Australian Capital Territory, Australia.
- The Naas River is part of the Murrumbidgee catchment.
- The Naas River is part of the Murray-Darling basin.
- Maunula (Finnish), Månsas (Swedish) is a northwestern neighborhood of Helsinki, Finland.
- For the 1952 Summer Olympics, it hosted part of the road cycling events.
- Julia Claire Irwin (born 8 November 1951) is an Australian politician.
- Julia Irwin was an Australian Labor Party member of the Australian House of Representatives from October 1998 to July 2010.
- Julia Irwin represented the Division of Fowler, New South Wales.
- Julia Irwin was born in Sydney.
- Julia Irwin was a bank officer.
- Julia Irwin was a trade union administration officer.
- Julia Irwin was an electorate officer.
- The Majura Training Area (MTA) is a facility belonging to the Australian Department of Defence.
- The MTA is located to the east of Mount Majura in the Majura district in the Australian Capital Territory, Australia.
- The MTA is used primarily by the Australian Army for the conduct of field exercises and weapon qualification shoots.
- Accommodation and support on the range is through 'Camp Blake'.
- Camp Blake consists of headquarters buildings, Q-Store, Mess, Staff accommodation and trainee accommodation and amenities.
- The MTA is located near to the Royal Military College, Duntroon and the Australian Defence Force Academy.
- These training establishments frequently use the MTA.
- The lower houses are known as the Legislative Assembly (the House of Assembly in South Australia and Tasmania).
- The head of the government in each state is the Premier and in each territory the Chief Minister.
- The Queen is represented in each state by a governor; and in the Northern Territory, the Administrator.
- In the Commonwealth, the Queen’s representative is the Governor-General.
- The Commonwealth Parliament also directly administers the Australian Antarctic Territory.
- The Commonwealth Parliament also directly administers Christmas Island.
- The Commonwealth Parliament also directly administers the Cocos (Keeling) Islands.
- The states are sovereign entities, although subject to certain powers of the Commonwealth as defined by the Constitution.
- The Commonwealth Parliament also directly administers Coral Sea Islands.
- The Commonwealth Parliament also directly administers Heard Island and McDonald Islands.
- 26 January 1788 marked the proclamation of British sovereignty over the eastern seaboard of Australia (then known as New Holland).
- The date has also been variously named ``Anniversary Day '',`` Foundation Day'', and ``ANA Day ''.
- Records of celebrations on 26 January date back to 1808.
- The first official celebration of the formation of New South Wales was held in 1818.
- On New Year's Day 1901, the British colonies of Australia formed a federation.
- A national day of unity and celebration was looked for.
- It was not until 1935 that all Australian states and territories adopted use
- The issuance of birth certificates is a function of the Vital Records Office of the states, capital district, territories and former territories.
- Birth in the U.S. establishes automatic eligibility for American citizenship.
- A birth certificate from a local authority is commonly provided to the federal government to obtain a U.S. passport.
- The U.S. State Department issues a Consular Report of Birth Abroad for children born to U.S. citizens.
- Births on military bases in foreign territory are covered by the Consular Report of Birth Abroad.
- The Commonwealth Parliament also directly administers Ashmore and Cartier Islands.
- The Commonwealth Parliament also directly administers Australian Antarctic Territory.
- The Commonwealth Parliament also directly administers Cocos (Keeling) Islands.
- The Commonwealth Parliament also directly administers Jervis Bay

# Avoca, Oklahoma

- Avoca was a small town
- Avoca was in Avoca Township
- Avoca was in southeastern Pottawatomie County, Oklahoma Territory
- The post office was established in 1894
- The post office closed permanently in 1906

# Baby Buggy Bunny Short

- Baby Buggy Bunny is a "Merrie Melodies" animated short.
- Baby Buggy Bunny was directed by Chuck Jones.
- Baby Buggy Bunny was written by Michael Maltese.
- Baby Buggy Bunny was released in 1954.
- The story is about a dwarf gangster named "Babyface" Finster.
- "Babyface" Finster is based on gangster Baby Face Nelson.
- Babyface Finster loses his gains down Bugs Bunny's rabbit hole.
- Babyface Finster dons the disguise of an orphan baby.

# Bang Bang! Film Details

Bang Bang!
- Bang Bang! is a 2014 Indian action comedy film
- The film is directed by Siddharth Anand
- The film is written by Abbas Tyrewala and Sujoy Ghosh
- The film is produced by Fox Star Studios
- The film is an official remake of the 2010 film "Knight and Day"
- The film features Hrithik Roshan and Katrina Kaif in the lead roles
- Tom Cruise and Cameron Diaz performed the lead roles in the original film
- The main antagonist of the film is Danny Denzongpa
- Fox Star Studios distributed and marketed the film
- Fox International Productions collaborated with Fox Star Studios on the film's distribution and marketing
- Bang Bang You're Dead is a 2002 American crime thriller drama film
- The film stars Tom Cavanagh and Ben Foster
- It is based on the play of the same name by William Mastrosimone
- The film was first screened publicly at the Seattle International Film Festival in June 2002
- Bang Bang Rock & Roll is the debut studio album by British rock band Art Brut.
- It was re-released in 2006 with bonus CD.
- Chitty-Chitty-Bang-Bang: The Magical Car is a children's novel.
- It was written by Ian Fleming for his son Caspar.
- It has illustrations by John Burningham.
- It was initially published in three volumes.
- The first volume was released on 22 October 1964.
- It was published by Jonathan Cape in London.
- "Cheatty Cheatty Bang Bang" is an episode of the American mystery television series "Veronica Mars"
- It is the third episode of the second season
- It is the twenty-fifth episode overall
- It was written by Phil Klemmer and John Enbom
- It was directed by John T. Kretchmer
- It premiered on UPN on October 12, 2005
- Chitty Chitty Bang Bang is a 1968 British musical adventure fantasy film
- It is directed by Ken Hughes
- It is written by Roald Dahl and Ken Hughes
- It is loosely based on Ian Fleming's 1964 novel Chitty - Chitty - Bang - Bang: The Magical Car
- The film stars Dick Van Dyke
- The film stars Sally Ann Howes
- The film stars Adrian Hall
- The film stars Heather Ripley
- The film stars Lionel Jeffries
- The film stars James Robertson Justice
- The film stars Robert Helpmann
- The film stars Gert Fröbe
- Slap Bang with Ant & Dec was a short lived television programme.
- It was shown in the United Kingdom on ITV in 2001.
- Bang Bang You're Dead is a one-act play written by William Mastrosimone.
- William Mastrosimone had the assistance of Michael Fisher, Director of the Thurston High School Drama Department, Springfield, Oregon.
- Fisher and his high school cast debuted "Bang Bang" in a Springfield theater in April 1999.
- The play was made available, free of charge, on the Internet the next day.
- It was the most-produced one-act play in high schools during the 1999-2000 school year.
- Mastrosimone said it “is a drama to be performed by kids, for kids” for free.

# Bang Bon District

- Bang Bon is one of the 50 districts of Bangkok, Thailand.
- Bang Bon is pronounced [bāːŋ bɔ̄ːn].
- Its neighbours clockwise from north are Bang Khae.
- Its neighbours clockwise from north are Phasi Charoen.
- Its neighbours clockwise from north are Chom Thong.
- Its neighbours clockwise from north are Bang Khun Thian.
- Its neighbours clockwise from north are Mueang Samut Sakhon District.
- Its neighbours clockwise from north are Krathum Baen District.
- Its neighbours clockwise from north are Nong Khaem District.
- Bang Bon borders Mueang Samut Sakhon District of Samut Sakhon Province.
- Bang Bon borders Krathum Baen District of Samut Sakhon Province.
- Bang Bon borders Nong Khaem District of Bangkok.
- Ban Sam Ruen is a village.
- Ban Sam Ruen is in the Nakhon Pa Mak subdistrict.
- Ban Sam Ruen is in the Amphoe Bang Krathum District.
- Ban Sam Ruen is in Phitsanulok Province, Thailand.
- Ban Sam Ruen (Thai: บ้านสามเรือน) is a village.
- Rama VII Bridge is a bridge over the Chao Phraya River.
- Rama VII Bridge is in Bangkok and Nonthaburi, Thailand.
- Rama VII Bridge connects the Bang Sue District and Bang Phlat District.
- The roadway on Rama VII Bridge is in a dual carriageway configuration.
- The roadway on Rama VII Bridge has 3 lanes in each direction.
- The bridge was named in honour of King Prajadhipok.
- Pegangsaan is an administrative village.
- Pegangsaan is in the Menteng district of Indonesia.
- Pegangsaan has a postal code of 10320.
- The house where the Proclamation of Indonesian Independence was read is in Pegangsaan.

# Bann Na Mohra, Pakistan

Bann Na Mohra is a town
Bann Na Mohra is in the Islamabad Capital Territory of Pakistan
Bann Na Mohra is located at 33° 27' 50N 73° 22' 10E
Bann Na Mohra has an altitude of 562 metres
Bann Na Mohra has an altitude of 1847 feet

# Barnett River Facts

- The Barnett River rises below the Caroline Range
- The Barnett River rises near Mount Lacy
- The Barnett River flows south
- The Barnett River flows west of Mount Elizabeth
- The Barnett River flows through the Barnett River gorge
- The Barnett River crosses the Gibb River Road near the Mount Barnett roadhouse
- The Barnett River flows into the Hann River
- The Barnett River flows near Mount Caroline
- The Barnett River flows in the Philip Range
- The Choptank River is a major tributary of the Chesapeake Bay
- The Choptank River is the largest river on the Delmarva Peninsula
- The Choptank River rises in Kent County, Delaware
- The Choptank River runs through Caroline County, Maryland
- The Choptank River forms much of the border between Talbot County, Maryland on the north, and Caroline County and Dorchester County on the east and south
- The Choptank River is located north of the Nanticoke River
- The Choptank River's mouth is located south of Eastern Bay
- Cambridge, the county seat of Dorchester County, is located on its south shore
- Denton, the county seat of Caroline County,
- Lancaster Crossing is also known as Indian Ford
- Lancaster Crossing is also known as Pecos Crossing
- Lancaster Crossing is also known as Solomon's Ford
- Lancaster Crossing is also known as Crossing of the Pecos
- Lancaster Crossing is also known as Crossing Rio Pecos
- Lancaster Crossing is also known as Ferry of the Pecos
- Lancaster Crossing is also known as Ford Canyon Crossing
- Lancaster Crossing is located between Crockett County and Pecos County
- Lancaster Crossing is located southeast of Sheffield, Texas
- Lancaster Crossing is one of the few natural fords on the Pecos River
- The Pecos River is otherwise known for its steep banks that made crossing difficult
- Lancaster Crossing is named after nearby Fort
- The Naas River is located in the Australian Capital Territory, Australia.
- The Naas River is a perennial stream.
- The Naas River is part of the Murrumbidgee catchment.
- The Naas River is part of the Murray-Darling basin.
- The York River is in Renfrew County, Hastings County and Haliburton County in Ontario, Canada.
- The York River is in the Saint Lawrence River drainage basin.
- The York River flows from the southern extension of Algonquin Provincial Park to the Madawaska River.

# Battle of Bunker Hill

Battle of Bunker Hill
- Part of the American Revolutionary War
- Death of General Warren occurred at the Battle of Bunker Hill
- The Battle of Bunker Hill took place on June 17, 1775
- The location was Charlestown, Massachusetts
- Coordinates are 42° 22′ 34.9''N 71° 3′ 38.8'' W
- The result was a Pyrrhic British victory
- The British captured the Charlestown Peninsula
- Belligerents included the United Colonies
- Belligerents included Connecticut
- Belligerents included Massachusetts
- Belligerents included New Hampshire
- Belligerents included Rhode Island
- Belligerents included Great Britain
- Commanders and leaders included William Prescott
- Commanders and leaders included Israel Putnam
- Commanders and leaders included Joseph Warren
- Commanders and leaders included John Stark
- Commanders and leaders included William Howe
- Commanders and leaders

# Benny Golson - Groovin' with Golson

Groovin' with Golson
- It is the sixth album by saxophonist Benny Golson.
- The album features performances recorded in 1959.
- It was originally released on the New Jazz label.
- It is the third album released by British rock/R&B band Snafu.
- It was released on the Capitol label in 1975.
- The band featured keyboardist Brian Chatton.
- Brian Chatton was once with the Warriors of Jon Anderson.
- Brian Chatton was once with Flaming Youth with Phil Collins.
- Brian Chatton was later with Jackson Heights with ex-the Nice Lee Jackson.
- It is "highly elusive on vinyl."
- Featuring performances recorded in 1959.
- Originally released on the New Jazz label.

# Berhale Woreda, Afar Region

Berhale (woreda)
- Berhale is one of the woredas in the Afar Region of Ethiopia.
- Berhale is part of Administrative Zone 2.
- Berhale's territory includes part of the Afar Depression.
- Berhale is bordered on the south by Afdera.
- Berhale is bordered on the south by Abala.
- Berhale is bordered on the southwest by the Tigray Region.
- Berhale is bordered on the west by Koneba.
- Berhale is bordered on the north by Dallol.
- Berhale is bordered on the northeast by Eritrea.
- Berhale includes the town of Berhale.
- Berhale includes the town of Tiyarabora.

# Bernd Hüttemann

Bernd Hüttemann
- Bernd Hüttemann was born on December 8, 1970.
- Bernd Hüttemann was born in Paderborn.
- Bernd Hüttemann is Vice President of the European Movement International.
- Bernd Hüttemann is Secretary General of the European Movement Germany.
- Ignazio Corrao is an Italian politician.
- Ignazio Corrao is a member of the Five Star Movement.
- Ignazio Corrao is a member of the European Parliament since 2014.
- Ignazio Corrao was born on January 14, 1984.
- Alain Milon was born on September 16, 1947.
- Alain Milon is a member of the Senate of France.
- Alain Milon represents the Vaucluse department.
- Alain Milon is a member of the Union for a Popular Movement.
- Klaus Mehnert was born on October 10, 1906.
- Klaus Mehnert was born in Moscow, Russia.
- Klaus Mehnert was a political scientist.
- Klaus Mehnert was a journalist.
- Klaus Mehnert was a professor at two American universities before World War II.
- Klaus Mehnert authored several books on recent youth led political movements in various Western countries in the late 1970s.
- Klaus Mehnert died on January 2, 1984.
- Klaus Mehnert died in Freudenstadt, Germany.
- The European Movement International is a lobbying association.
- The European Movement International coordinates the efforts of associations and national councils.
- The European Movement International promotes European integration.
- The European Movement International disseminates information about it.
- The 2003 European Fencing Championships were held in Bourges, France.
- The event took place from 29 June to 3 July 2003.

# Bhanwar Singh Dangawas

* Bhanwar Singh Dangawas (7 June 1929 – 2 July 2012)
            * Was a member of the 14th Lok Sabha
            * Represented the Nagaur constituency
            * Was a member of the Bharatiya Janata Party (BJP) political party

# Big Swing Face (album)

Big Swing Face
- It is the eighth album by Bruce Hornsby.
- It was released by American singer and pianist Bruce Hornsby.
- It was Hornsby's first studio album with the Noisemakers.
- It was Hornsby's last album for RCA Records.
- It is the tenth studio album by Bruce Hornsby.
- It was Hornsby's third studio album with his touring band, Bruce Hornsby and the Noisemakers.
- It was his first release with Verve Records.

# Billy Goat Tavern History

Billy Goat Tavern
- The first location opened in 1934.
- William ``Billy Goat ''Sianis bought the Lincoln Tavern.
- William ``Billy Goat ''Sianis bought the Lincoln Tavern for $205.
- He made good on a bounced check with the proceeds from the first weekend.
- The Lincoln Tavern was near Chicago Stadium.
- He posted a sign saying ``No Republicans allowed'' during the 1944 Republican National Convention.
- The place was packed with Republicans demanding to be served.
- Sianis took advantage of the publicity.

# Billy Joel - Don't Ask Me Why

- "Don't Ask Me Why" is a Billy Joel song.
- "Don't Ask Me Why" was released in 1980.
- The track contains acoustic and Latin percussion instruments.
- The instruments perform in an Afro-Cuban rhythmic style.
- The song features an instrumental "Latin Ballroom" piano solo.
- The piano solo is played over the bridge section after the second verse.
- Joel overdubbed fifteen pianos on top of each other in the midsection.
- The song spent two weeks at number one on the Adult Contemporary chart.
- The song peaked at number nineteen on the "Billboard" Hot 100.
- "Brown Eyed Girl" is a song by Northern Irish singer and songwriter Van Morrison.
- Written by Morrison and recorded in March 1967 for Bang Records owner and producer Bert Berns.
- It was released as a single in June 1967 on the Bang label.
- It featured the Sweet Inspirations singing back-up vocals.
- It has remained a staple on classic rock radio.
- It has been covered by hundreds of bands over the decades.

# Biplab Dasgupta (Economist)

Biplab Dasgupta
- Biplab Dasgupta (1938 – 17 July 2005) was a Marxian economist.
- He was a former member of Rajya Sabha.
- He was a member of the Bengal state committee of the CPI(M).
- He was the author of several books on the agrarian economy of India.
- Dilipkumar Mansukhlal Gandhi was born on 9 May 1951.
- He is an Indian politician.
- He is a member of the Bharatiya Janata Party (BJP) political party.
- He is a current member of the 16th Lok Sabha of India.

# Blackout and Scorponok

Transformers (film)
- Blackout attacks and destroys a United States military base in Qatar.
- Blackout's attempt is to hack the military network.
- The network search is for information on Megatron.
- The network search is also for the AllSpark.
- Captain William Lennox leads a team of Army Rangers.
- The team escapes across the desert.
- The team is pursued by Scorponok.
- Scorponok is a drone.
- Aerial reinforcements aid in fighting off Scorponok.
- Scorponok's armor is damaged by sabot rounds.
- John Keller is the Secretary of Defense.
- Keller leads the investigation into the attack.
- Maggie Madsen is a sound analyst.
- Frenzy is another Decepticon.
- Frenzy is hacking into the military network.
- Frenzy is onboard Air Force One.
- The hack is thwarted.
- Frenzy downloads files on Archibald
- Harlow Shapley stated in 1918 that the halo of globular clusters surrounding the Milky Way seemed to be centered on the star swarms in the constellation of Sagittarius.
- Dark molecular clouds in the area blocked the view for optical astronomers.
- Walter Baade at Mount Wilson Observatory took advantage of wartime blackout conditions in nearby Los Angeles.
- Baade conducted a search for the center with the 100 inch Hooker Telescope.
- Baade found a one - degree - wide void in the interstellar dust lanes near the star Alnasl (Gamma Sagittarii).
- The gap has been known as Baade's Window.

# Blood Stain Child

- Blood Stain Child is a Japanese heavy metal band.
- The band is from the city of Osaka.
- The band's musical style combines melodic death metal with electronic and trance.
- The band formed under the name "Visionquest" in 1999.
- The band changed their name to Blood Stain Child in 2000.
- Visionquest was stylised as "VISIONQUEST".
- BLOOD STAIN CHILD is a stylisation of the band's name.

# Breaking Benjamin - "I Will Not Bow"

I Will Not Bow is Breaking Benjamin's first single.
I Will Not Bow is on the 2009 album "Dear Agony".
"I Will Not Bow" was featured in the ending credits of the Bruce Willis film "Surrogates".
The song was not written specifically for the film "Surrogates".
Chad Szeliga is the drummer for Breaking Benjamin.
Ben sent songs to the record label Hollywood Records.
Hollywood Records is owned by Disney.
Disney wanted a Breaking Benjamin song for the movie "Surrogates".
The song was used on MLB Network during the 2010 MLB postseason.
The song was used as lead-in and lead-out music on MLB Network.

# Britney Spears - Radar Song

Radar (song)
- "Radar" is a song recorded by Britney Spears.
- It is for her fifth studio album, "Blackout" (2007).
- It was written and produced by Bloodshy & Avant and The Clutch.
- Henrik Jonback did additional writing.
- It was a record that did not relate to her personal problems at the time.
- The recording sessions took place the day after Spears filed for divorce from Kevin Federline.
- Members of The Clutch claimed to be surprised by her work ethic.
- "Radar" was originally planned to be released as the third single from "Blackout".
- "Break the Ice" was chosen instead of "Radar" as the third single.
- "Radar" was then planned as the fourth single.
- The release was cancelled as Spears began recording "Circus" (2008).
- "Radar" was later included as a bonus track on

# Bruce Hunter (Actor)

Bruce Hunter
- Bruce Hunter is a Canadian actor and comedian.
- Bruce Hunter was born in 1961.
- Bruce Hunter is from Calgary, Alberta.
- Bruce Hunter has appeared in "Puppets Who Kill".
- Bruce Hunter has appeared in "The Red Green Show".
- Bruce Hunter received a Canadian Comedy Awards nomination in 2002.
- Bruce Hunter was nominated for his work on "After Hours".
- Bruce Hunter voices the king of Happily-Ever-Afterville on "Cyberchase".
- The Wandering Fire is a 1986 novel.
- The Wandering Fire is by Guy Gavriel Kay.
- The Wandering Fire is a Canadian novel.
- The Wandering Fire is the second novel of "The Fionavar Tapestry" trilogy.
- The Wandering Fire follows "The Summer Tree".
- Guy Gavriel Kay is a Canadian author.
- "The Fionavar Tapestry" is a trilogy.
- "The Summer Tree" is a novel.
- The Red Tree is a picture book.
- The Red Tree (2001) was written and illustrated by Shaun Tan.
- The illustrations are surreal.
- The text is sparse.
- The text matches the dark illustrations.
- Tyler Lepley is an American actor.
- Tyler Lepley was born on March 24, 1987.
- Tyler Lepley is best known for his portrayal of Benjamin ``Benny ''Young on The Have and the Have Nots.
- Tyler Lepley starred in a Tyler Perry produced show.
- The Have and the Have Nots is a television series.
- The Have and the Have Nots airs on the Oprah Winfrey Network.
- The Have and the Have Nots is the first scripted television series to air on the Oprah Winfrey Network.
- Dana MacDuff was born in Pasadena, California.
- Dana MacDuff's parents are Tyler MacDuff and Beverlie May Anderson (born 1930).
- Dana MacDuff is named for the actor Dana Andrews.
- Dana MacDuff graduated in 1974 from Blair International Baccalaureate School in Pasadena.
- Dana MacDuff served in the United States Navy from 1974–1977.
- Dana MacDuff worked as a page at the American Broadcasting Company.
- Dana MacDuff worked as a floor and stage manager with the BBC in Belfast, Northern Ireland.
- Dana MacDuff returned to Hollywood in 1
- The Canadian Grenadier Guards Band was sometimes referred to as His Majesty's Canadian Grenadier Guards Band.
- The Canadian Grenadier Guards Band was active for more than 60 years during the 20th century.
- The band performed for military events.
- The band had an active concert schedule.
- The band performed at venues throughout North America.
- The group made several recordings on various labels.
- The group appeared on numerous radio broadcasts in both Canada and the United States.
- Arthur Kroker was born in 1945.
- Arthur Kroker was born in Red Rock, Ontario, Canada.
- Arthur Kroker is a Canadian author.
- Arthur Kroker is an editor.
- Arthur Kroker is an educator.
- Arthur Kroker is a researcher of political science, technology and culture.
- "For You" is a song written and recorded by Bruce Springsteen in 1972.
- "Greetings from Asbury Park, N.J." is a 1973 album.
- "For You" was released on "Greetings from Asbury Park, N.J." in 1973.
- "The Essential Bruce Springsteen" is a compilation album.
- Manfred Mann's Earth Band has covered "For You".
- The Format has covered "For You".
- Greg Kihn has covered "For You".
- Fist of Fury II is a 1977 Hong Kong kung fu film.
- Fist of Fury II is also known as Chinese Connection 2 and Fist of Fury Part II.
- Iksan Lahardi and Tso-nam Lee directed Fist of Fury II.
- Bruce Li stars in Fist of Fury II.
- Lo Lieh stars in Fist of Fury II.
- Fist of Fury II is a sequel to "Fist of Fury".
- "Fist of Fury" was released in 1972.
- "Pink Cadillac" is a single by Bruce Springsteen.
- The A-side of "Pink Cadillac" is "Dancing in the Dark".
- "Pink Cadillac" was released on May 3, 1984.
- "Pink Cadillac" is 3:33 in length.
- "Pink Cadillac" is a rock song.
- "Pink Cadillac" was released on the Columbia label.
- Bruce Springsteen wrote "Pink Cadillac".
- Bruce Springsteen, Jon Landau, Chuck Plotkin, Steven Van Zandt, and Bruce Springsteen produced "Pink Cadillac".
- "Fade Away" was released in 1981.
- "Cover Me" was released in 19
- ``I Write the Songs'' is a single by David Cassidy.
- ``I Write the Songs'' is from the album "The Higher They Climb".
- ``I Write the Songs'' was released in the format of a 7'' (45 rpm).
- ``I Write the Songs'' was written by Bruce Johnston.
- ``I Write the Songs'' was produced by Bruce Johnston and David Cassidy.
- ``I Write the Songs'' was released in 1975.
- ``Daydreamer'' was released in 1973.
- ``Darlin' '' was released in 1975.

# Bruce Lee and Wong Jack Man

Birth of the Dragon
- Philip Ng plays Bruce Lee
- Bruce Lee founded Jeet Kune Do
- Xia Yu plays Wong Jack Man
- Wong Jack Man is a Tai chi and Northern Shaolin Master
- Bruce Lee fights Wong Jack Man
- Jin Xing plays Auntie Blossom
- Auntie Blossom is a gangster
- Billy Magnussen plays Steve McKee
- Steve McKee is Bruce Lee's student
- Jingjing Qu plays Xiulan
- Xiulan is McKee's love interest
- Simon Yin plays Vinnie
- Vinnie Wei plays Tony Yu
- Lee Eddy is an American stage actress, comedian and writer.
- She was born in Shreveport, Louisiana.
- She was a member of The Peter Pan Players as a child.
- She has appeared in the one-woman show "LadeeLeroy".
- She regularly performs in Austin, Texas with the Salvage Vanguard Theater.
- She was well-reviewed when she appeared in an annual production of "The Santaland Diaries".
- Escape from L.A. is a 1996 American postapocalyptic action film.
- Escape from L.A. is also known as John Carpenter's Escape from L.A. or Escape from Los Angeles.
- John Carpenter co-wrote, co-scored, and directed Escape from L.A.
- Debra Hill and Kurt Russell co-wrote and produced Escape from L.A.
- Kurt Russell stars as Snake Plissken.
- Steve Buscemi co-stars in Escape from L.A.
- Stacy Keach co-stars in Escape from L.A.
- Bruce Campbell co-stars in Escape from L.A.
- Pam Grier co

# Bruce Lee, My Brother (film)

Bruce Lee, My Brother
- Bruce Lee, My Brother is a 2010 Hong Kong biographical martial arts drama film.
- It is also known in the United Kingdom as Young Bruce Lee.
- The film was directed by Raymond Yip.
- The film was written, produced and directed by Manfred Wong.
- Robert Lee, Bruce Lee's real life younger brother, storied, produced and narrated the film.
- Aarif Lee stars as Lee.
- Tony Leung Ka-fai stars as Lee's father.
- Christy Chung stars as Lee's mother.
- The film is based on Bruce Lee's life during his teenage and adult years.
- Remember When: The Anthology is a DVD.
- Remember When: The Anthology features a collection of live performances by Harry Chapin.
- It features commentary by Joshua, Jennifer, and Sandy.
- Jennifer and Joshua are Harry Chapin's children.
- Sandy is Harry Chapin's widow.
- The DVD features eleven performances by Harry.
- The DVD features one performance by Jennifer (I Wonder What Would Happen to This World).
- Peter Shockey is an American filmmaker and screenwriter.
- Peter Shockey has received a New York City Film Festival award for his television film "Life After Life" (1992).
- Peter Shockey and his works have appeared on talk shows and television shows such as Oprah and the 700 Club.
- Peter co-wrote the book "Journey of Light" with Stowe D. Shockey.
- The book "Journey of Light" focuses on Stowe D. Shockey's experience as an abused child to help others.
- Peter and Stowe both live in Nashville, Tennessee.

# Buenos Aires Argentina Temple

- The Buenos Aires Argentina Temple is the 39th operating temple of The Church of Jesus Christ of Latter-day Saints (LDS Church)
- The temple is located in Ciudad Evita, near Buenos Aires, Argentina.
- Club Sportivo Italiano is an Argentine football club.
- The club is located in Ciudad Evita, La Matanza Partido, Greater Buenos Aires.
- The team currently plays in the Primera B Metropolitana.
- The Primera B Metropolitana is the third division of the Argentine football league system.
- Ciudad del Niño is an underground metro station.
- Ciudad del Niño is on the Line 2 of the Santiago Metro.
- It is located in Santiago, Chile.
- It is named for the former Ciudad del Niño Presidente Juan Antonio Ríos.
- The film deals with the story of an upper middle class couple who lives in Buenos Aires.
- The couple illegally adopted a child.
- The mother realizes her daughter may be the child of a desaparecido.
- A desaparecido is a victim of the forced disappearances that occurred during Argentina's last military dictatorship (1976 - 1983).
- Argentina's last military dictatorship occurred from 1976 - 1983.
- The military dictatorship was marred by widespread human rights violations and a genocide.
- National Route A012 is a road in the southeast of Santa Fe Province, Argentina.
- It has a semi-circular length centered on the city of Rosario, running as a long-length beltway.
- From the National Route 9 junction on km marker 278, in the town of Pueblo Esther, it runs for all paved.
- It runs to the junction with National Route 11 on km marker 326 in the city of San Lorenzo.

# Callum Kane

Callum Kane is a fictional character.
Callum Kane is from the British Channel 4 soap opera "Hollyoaks".
Callum Kane is played by Laurie Duncan.
Callum Kane's character and Duncan's casting was announced on 25 August 2011.
Callum was introduced along with five other regular characters.
Callum made his first screen appearance on 6 September 2011.
Callum appeared in the sixth series of "Hollyoaks Later" in October 2013.
Callum was killed off in October 2013.
Callum's exit was part of a "cast cull".
Callum's exit coincided with the show's 18th anniversary.
Duncan's departure from the show was kept secret.
Laurie Duncan cried when he learned he was leaving.

# Campora, Salerno Province

Campora
- Campora is a town
- Campora is a "comune"
- Campora is in the province of Salerno
- Campora is in Campania
- Campora is in the territory of Cilento
- Campora's population was 810 in 2009
- The Palazzo Corner Spinelli is a palace
- The Palazzo Corner Spinelli is in Venice
- The Palazzo Corner Spinelli is in northern Italy
- The Palazzo Corner Spinelli is located on the Grand Canal
- The Palazzo Corner Spinelli is in the sestiere of San Marco
- The Palazzo Corner Spinelli stands across the canal from the Palazzo Querini Dubois

# Canonical Alien Trilogy

Alien (franchise)
- Novelizations of each of the six films have been released.
- Some comic books have been released.
- Original canonical novels based on the franchise have been released.
- The original novels include Alien: Out of the Shadows.
- The original novels include Alien: Sea of Sorrows.
- The original novels include Alien: River of Pain.
- Alien: Out of the Shadows and River of Pain were adapted into audio dramas.
- The audio dramas were released on Alien Day.
- Alan Dean Foster published Alien: Covenant -- Origins.
- Alien: Covenant -- Origins is set between the events of Prometheus and Alien: Covenant.
- Aliens: Bug Hunt is a short story collection.
- The original novels are marketed as the Canonical Alien Trilogy.

# Cape Fourcroy Light

Cape Fourcroy Light
- It is an active lighthouse.
- It is located on Cape Fourcroy.
- Cape Fourcroy is on the southwestern tip of Bathurst Island.
- Bathurst Island is in the Northern Territory, Australia.
- It marks the beginning of the route from the Timor Sea to Darwin.

# Caroline LeRoy Webster

Caroline LeRoy Webster
- Caroline LeRoy Webster was born on September 28, 1797 in New York City.
- Caroline LeRoy Webster died on February 26, 1882.
- Caroline LeRoy Webster was the second wife of Daniel Webster.
- Caroline's father was Herman LeRoy.
- Herman LeRoy was once head of the commercial house of Leroy, Bayard, McKiven & Co.
- Leroy, Bayard, McKiven & Co. was a large trading company.
- Leroy, Bayard, McKiven & Co. operated in different parts of the world.
- Herman LeRoy was the first Holland Consul to the United States.
- Caroline's mother was Hannah Cornell.
- Hannah Cornell was daughter of the last Royal Attorney General of the State of North Carolina.
- Caroline was a descendant of Thomas Cornell.
- Daniel Marsin was born on November 13, 1951 in Pointe-à-Pitre, Guadeloupe.
- Daniel Marsin is a member of the Senate of France.
- Daniel Marsin represents the island of Guadeloupe.
- Daniel Marsin is a member of "Guadeloupe unie, socialisme et réalités".
- Daniel Marsin is a member of the Modern Left.
- Daniel Marsin is a satellite organisation of Nicolas Sarkozy' Union for a Popular Movement.
- Daniel Marsin is a member of the parliamentary group European Democratic and Social Rally in the French Senate.
- Shiranthi Wickremesinghe Rajapaksa is the wife of the sixth President of Sri Lanka, Mahinda Rajapaksa.
- Shiranthi Wickremesinghe Rajapaksa was the First Lady of Sri Lanka from 2005 to 2015.
- Shiranthi Wickremesinghe Rajapaksa is a professional in child psychology and pre-school education.
- Frances Amélia Tupper was born on March 14, 1826.
- Frances Amélia Tupper died on May 11, 1912.
- Frances Amélia Tupper (née Morse)
- Frances Amélia Tupper was the wife of Sir Charles Tupper.
- Sir Charles Tupper was the sixth Prime Minister of Canada.
- Frances Amélia Tupper and Sir Charles Tupper had six children.
- Frances Amélia Tupper and Sir Charles Tupper had three boys.
- Frances Amélia Tupper and Sir Charles Tupper had three girls.

# Casey's Shadow (1978 film)

Casey's Shadow
- Casey's Shadow is a 1978 film.
- The film is a drama.
- The film is in Metrocolor.
- The film was directed by Martin Ritt.
- The film stars Walter Matthau.
- The film was based on a short story in "Ruidoso".
- "Ruidoso" was published on April 29, 1974.
- "Ruidoso" was published in The New Yorker magazine.
- The short story was written by John McPhee.
- Much of the exterior shots were done in Opelousas, LA.
- Opelousas, LA is 20 miles north of Lafayette, LA.

# Catalan and Romance Languages

Catalan language
- Catalan shares many traits with its neighboring Romance languages.
- Catalan is mostly situated in the Iberian Peninsula.
- Catalan differs from Iberian Romance in terms of vocabulary.
- Catalan differs from Iberian Romance in terms of pronunciation.
- Catalan differs from Iberian Romance in terms of grammar.
- Catalan differs more from Iberian Romance than from Gallo-Romance.
- These similarities are most notable with Occitan.
- The ascription of Catalan to the Occitano-Romance branch of Gallo-Romance languages is not shared by all linguists and philologists.
- Ramón Menéndez Pidal is a Spanish linguist and philologist who does not share this ascription.
- Victim of Romance is singer and songwriter Michelle Phillips' first and only solo album.
- Victim of Romance was released in February 1977.
- The record was unsuccessful.
- Michelle Phillips was previously with The Mamas & the Papas.
- The front cover photography was by Terry O'Neill.

# Ceres Nunataks

- The Ceres Nunataks are a group of three nunataks
- The Ceres Nunataks are located east of the base of Shostakovich Peninsula
- The Ceres Nunataks are in southern Alexander Island, Antarctica
- The Ceres Nunataks were mapped by the Directorate of Overseas Surveys
- The mapping used satellite imagery supplied by the U.S. National Aeronautics and Space Administration
- The mapping was in cooperation with the U.S. Geological Survey
- The UK Antarctic Place-Names Committee named the Ceres Nunataks
- The Ceres Nunataks were named after Ceres
- Ceres is one of the asteroids
- Ceres lies between the orbits of the planets Mars and Jupiter
- Amundsen Icefall is a steep and turbulent icefall.
- The Amundsen Icefall is where the Axel Heiberg Glacier descends from the polar plateau between Mount Fridtjof Nansen and Mount Don Pedro Christophersen.
- The Amundsen Icefall is in the Queen Maud Mountains of Antarctica.
- The Southern Party of the New Zealand Geological Survey Antarctic Expedition (1961–62) named the Amundsen Icefall.
- Captain Roald Amundsen ascended Axel Heiberg Glacier en route to the South Pole in 1911.
- The Amundsen Icefall was named for Captain Roald Amundsen.

# CFVS-DT Television Station

CFVS-DT is branded on-air as V Abitibi-Témiscamingue.
CFVS-DT is a French language television station.
CFVS-DT is affiliated with V.
CFVS-DT serves Quebec's Abitibi-Témiscamingue region.
CFVS-DT is licensed to Val-d'Or, Quebec, Canada.
CFVS-DT broadcasts a digital signal.
CFVS-DT broadcasts on UHF channel 15.
CFVS-DT broadcasts on virtual channel 25.1 via PSIP.
CFVS-DT broadcasts from a transmitter near Route Québec Lithium in La Corne.
CFVS-DT operates a rebroadcaster in Rouyn-Noranda (CFVS-DT-1).
CFVS-DT-1 operates on UHF channel 20.
Both transmitters flash-cut to digital on September 1, 2011.

# Charlotte 49ers Sports Teams

Charlotte 49ers
- The Charlotte 49ers represent the NCAA Division I sports teams of the University of North Carolina at Charlotte.
- Charlotte is a founding member of Conference USA (C-USA).
- Charlotte rejoined the conference in 2013.
- Charlotte spent eight years as a member of the Atlantic 10 Conference.
- Charlotte was a charter member of the Sun Belt Conference.
- Charlotte was a member of the Metro Conference.
- Ann Arbor is a major scene of college sports.
- The University of Michigan is a member of the Big Ten Conference.
- Michigan Stadium is the largest American football stadium in the world.
- Michigan Stadium was completed in 1927.
- Michigan Stadium cost more than $950,000 to build.
- Michigan Stadium has a 109,901 seating capacity.
- Michigan Stadium is colloquially known as "The Big House".
- Crisler Center hosts the school's basketball (both men's and women's) teams.
- Yost Ice Arena hosts the school's ice hockey teams.
- Concordia University
- Edward Wesley Schulmerich (August 21, 1901 – June 26, 1985) was an American Major League Baseball player.
- He was a native of the state of Oregon.
- He played baseball and football at what is now Oregon State University.
- He participated in three sports at Oregon State University.
- He played three positions on the football team.
- He earned the nickname of Ironhorse on the football team.
- He earned all-conference honors on the football team.
- He was a right-handed outfielder in baseball.
- He was the first player from the school to make it to the Major Leagues.
- He played for three
- North Carolina State University is located in southwest Raleigh.
- The Wolfpack competes nationally in 24 intercollegiate varsity sports.
- The Wolfpack is a member of the Atlantic Coast Conference.
- The university's football team plays in Carter-Finley Stadium.
- Carter-Finley Stadium is the third largest football stadium in North Carolina.
- The men's basketball team shares the PNC Arena with the Carolina Hurricanes hockey club.
- The Wolfpack women's basketball, volleyball, and gymnastics as well as men's wrestling events are held on campus at Reynolds Coliseum.
- The men's baseball team plays at Doak Field.
- The Bennigsen Beavers were established in 1993.
- The Bennigsen Beavers became an independent sporting team on January 1, 2004.
- The club fielded 7 teams for the 2005 season.
- The 2005 season included three men's teams.
- The 2005 season included a women's team.
- The 2005 season included a junior team.
- The 2005 season included a youth team.
- The 2005 season included a student team.
- As of mid-2005, the Bennigsen Beavers claimed

# Charlotte Brabantina of Nassau

Countess Charlotte Brabantina of Nassau
- Countess Charlotte Brabantina of Nassau was born in Antwerp on 17 September 1580.
- She died in Château-Renard in August 1631.
- She was the fifth daughter of William the Silent.
- Her mother was Charlotte of Bourbon.
- William the Silent was her father.
- Charlotte of Bourbon was her mother.
- Tumaraa is a commune of French Polynesia.
- Tumaraa is an overseas territory of France.
- Tumaraa is located in the Pacific Ocean.
- Tumaraa is located on the island of Raiatea.
- The commune of Tumaraa is located in the Leeward Islands.
- The Leeward Islands are part of the Society Islands.
- At the 2017 census, Tumaraa had a population of 3,721.
- Tumaraa is the least populous commune on Raiatea.
- Peter Antonovich of Brunswick (1745–1798) was the second son of Duke Anthony Ulrich of Brunswick and Grand Duchess Anna Leopoldovna of Russia.
- He was the younger brother of Ivan VI.
- Peter Antonovich of Brunswick-Lüneburg was the second son of Duke Anthony Ulrich of Brunswick and Grand Duchess Anna Leopoldovna of Russia, and younger brother of Ivan VI.
- He was the second son of Duke Anthony Ulrich of Brunswick.
- He was the younger brother of Ivan VI.
- Peter Antonovich of Brunswick-Lüneburg (1745–1798) was the second son of Duke Anthony Ulrich of Brunswick and Grand
- Fletcher Webster was born on July 25, 1813 in Portsmouth, New Hampshire.
- Fletcher Webster was the son of Daniel Webster and Grace Fletcher Webster.
- Fletcher Webster was educated at Harvard College.
- Fletcher Webster served as Chief Clerk of the United States State Department during his father's first term as Secretary of State.
- Fletcher Webster delivered the news of President William Henry Harrison's death to the new President, John Tyler.
- The State Department office Fletcher Webster held was the second most powerful office in the State Department.
- Fletcher Webster died on August 30, 1862.
- Margareta von Ascheberg was the youngest child of Field Marshal Rutger von Ascheberg and Magdalena Eleonora Busseck.
- She married colonel count Kjell Christopher Barnekow (d. 1700) in Malmö on 26 January 1691.
- As was the custom of the Swedish nobility at that time, she kept her name after marriage and styled herself »Grevinnan Ascheberg» (Countess Ascheberg).
- The couple had four children.
- She accompanied her spouse on his military commissions.
- She gave birth to their youngest sons during the Bombardment of Brussels in 1695.
- George II was King of Great Britain and Ireland.
- George II was Elector of Hanover.
- George II reigned from 11/22 June 1727 to 25 October 1760.
- George II was crowned on 11/22 October 1727.
- George II's predecessor was George I.
- George II's successor was George III.
- George II had the following Prime Ministers: Robert Walpole, Lord Wilmington, Henry Pelham, The Duke of Newcastle, The Duke of Devonshire.
- George II was born on 30 October / 9 November 1683 in Herrenhausen Palace, or Le
- Princess Stéphanie of Monaco, Countess of Polignac (Stéphanie Marie Elisabeth Grimaldi; born 1 February 1965) is the youngest child of Rainier III, Prince of Monaco, and the American actress Grace Kelly.
- She is the younger sister of Albert II, Prince of Monaco, and Caroline, Princess of Hanover.
- Currently 14th in the line of succession to the Monegasque throne.
- She has been a singer.
- She has been a swimwear designer.
- She has been a fashion model.
- Marie Anne de Bourbon was born on 2 October 1666.
- Marie Anne de Bourbon died on 3 May 1739.
- Marie Anne de Bourbon was the eldest legitimised daughter ("fille légitimée de France") of King Louis XIV of France.
- She was married to Louis Armand de Bourbon, Prince of Conti.
- She was the Princess of Conti by marriage.
- She was widowed in 1685 aged 19.
- She never married again.
- She had no children.
- She later became the Duchess of La Vallière in her own right.
- Her mother retired to a convent.
- She continued to reside
- William Conyers, 1st Baron Conyers was born on 21 December 1468.
- William Conyers, 1st Baron Conyers died on 14 April 1524.
- He was also known as William Conyers of Hornby.
- He was an English baron.
- He was an aristocrat.
- He married Elizabeth le Despencer.
- Elizabeth le Despencer was the daughter of Edward le Despencer, 1st Baron le Despencer (Despencer).
- Elizabeth Burghersh was the daughter and heiress of Bartholomew de Burghersh, 2nd Baron Burghersh.
- Elizabeth le Despencer was the daughter of Elizabeth Burghersh.
- Beatrice Van was born on August 8, 1890 in Omaha, Nebraska.
- Beatrice Van died on July 4, 1983 in Long Beach, California.
- She was a screenwriter for both silent and sound films.
- She was an American silent film actress.

# Chelyabinsk, Russia

Chelyabinsk
- Chelyabinsk is a city.
- Chelyabinsk is the administrative center of Chelyabinsk Oblast, Russia.
- Chelyabinsk is located in the northeast of the oblast.
- Chelyabinsk is south of Yekaterinburg.
- Chelyabinsk is just to the east of the Ural Mountains.
- Chelyabinsk is on the Miass River.
- Chelyabinsk is on the border of Europe and Asia.
- Krasnovishersky District is an administrative district of Perm Krai, Russia.
- Krasnovishersky District is incorporated as Krasnovishersky Municipal District.
- It is located in the northeast of Perm Krai.
- It is located in the valley of the Vishera River.
- It borders with the Komi Republic in the north.
- It borders with Sverdlovsk Oblast in the east.
- It borders with Cherdynsky District in the west.
- It borders with Solikamsky District in the south.
- It borders with the territory of the town of krai significance of Alexandrovsk in the southeast.
- The area of the district is
- Suresh Ganapat Wagmare was born on 15 September 1961.
- Wagmare Suresh Ganapat is a member of the 14th Lok Sabha of India.
- He represents the Wardha constituency of Maharashtra.
- He is a member of the Bharatiya Janata Party (BJP) political party.
- Chelyabinsk () is a city.
- Chelyabinsk () is the administrative center of Chelyabinsk Oblast, Russia.
- Krasnovishersky District is an administrative district (raion) of Perm Krai, Russia.
- Municipally, it is incorporated as Krasnovishersky Municipal District.
- It is located in the northeast of the krai, in the valley of the Vishera River.
- Its administrative center is the town of Krasnovishersk.
- The population of Krasnovishersk accounts for 71.4% of the district's total population.
- Notogawa Station is the only Japan Railway station in Higashiomi.
- Notogawa Station is a rapid stop on the JR Biwako Line.
- Notogawa Station is located between Omi-Hachiman and Hikone.
- The town shares a small border with Lake Biwa.
- The coordinates of Notogawa Station are N35.179899,E136.165913.
- Krasnovishersky District () is an administrative district (raion) of Perm Krai, Russia.
- It is one of the thirty-three in the krai.
- The area of the district is .
- Population: The population of Krasnovishersk accounts for 71.4% of the district's total population.
- Poronaysky District is an administrative district (raion) of Sakhalin Oblast, Russia.
- Poronaysky District is one of the seventeen in the oblast.
- As a municipal division, it is incorporated as Poronaysky Urban Okrug.
- It is located in the eastern central part of the Island of Sakhalin.
- Its administrative center is the town of Poronaysk.
- Population (excluding the administrative center):
- Krasnovishersky District is one of the thirty-three in the krai.

# Chevrolet Malibu History

Chevrolet Malibu
- The Chevrolet Malibu is a mid-size car.
- It is manufactured and marketed by Chevrolet.
- It was manufactured from 1964 to 1983.
- It has been manufactured since 1997.
- The Malibu began as a trim level of the Chevrolet Chevelle.
- It became its own model line in 1978.
- Originally, it was a rear-wheel-drive intermediate.
- GM revived the Malibu nameplate in 1997.
- The revived Malibu was a front-wheel-drive car.
- Chevrolet has won 39 NASCAR Championship titles.
- Ford has won 15 NASCAR

# Chicago - All the Years Song

All the Years is a song
All the Years was recorded by the rock band Chicago
All the Years was released on the 2008 album Stone of Sisyphus
It was written by Robert Lamm
It was written by Bruce Gaitsch
Bruce Gaitsch is a studio session musician
Bruce Gaitsch was the guitarist from the "Night & Day Big Band" album

# Chihuahua State Economy

Chihuahua (state)
- Two-fifths of the state's territory was divided among 17 rich families.
- 17 rich families owned practically all of the arable land in Chihuahua.
- The state economy in Chihuahua grew at a rapid pace during the Porfiriato.
- The economy in Chihuahua was dominated by agriculture and mining.
- The Díaz administration funded the Municipal Public Library in Chihuahua City.
- The Díaz administration passed a federal initiative for the construction of the railroad from Chihuahua City to Ciudad Júarez.
- The Central Mexican Railroad was completed by 1881.
- The Central Mexican Railroad connected Mexico City to Ciudad Juárez.
- Telephone lines were installed throughout the state in 1883.
- Telephone lines allowed communication between Chihuahua City and Aldama.
- Telephone services were extended to Julimes, Meoqui, and Hidalgo del Parral by 1888.
- The telecommunication
- New Haven's economy originally was based in manufacturing.
- The postwar period brought rapid industrial decline to New Haven.
- The entire Northeast was affected by industrial decline.
- Medium-sized cities with large working-class populations were hit particularly hard.
- The growth and expansion of Yale University further affected the economic shift.
- Today, over half (56%) of New Haven's economy is made up of services.
- Education and health care make up over half of New Haven's economy.
- Yale is New Haven's largest employer.
- Yale – New Haven Hospital is New Haven's second largest employer.
- St. Raphael Hospital is a large employer in New Haven.
- New Haven's greatest culinary claim to fame may be its pizza.
- New Haven-style pizza is called "apizza" (pronounced ah-BEETS, [aˈpitts]).
- Apizza debuted at Frank Pepe Pizzeria Napoletana (known as Pepe's) in 1925.
- Apizza is baked in coal- or wood-fired brick ovens.
- Pies ordered "plain" are made without mozzarella cheese.
- A white clam pie is a specialty of restaurants on Wooster Street in New Haven.
- Sally's Apizza opened in 1938.
- Modern Apizza opened in 1934.

# Child Reference Number & NI Number

- People born and resident in the UK are assigned a Child Reference Number shortly after birth.
- A claim is made for Child Benefit to receive a Child Reference Number.
- HMRC notifies each child of their NI number at age 15 years 9 months.
- A bill was proposed in June 2005 to raise the age of consent from 16 to 18 in Georgia.
- The Georgia age of consent was 14 from the Progressive era until 1995.
- A bill proposed by state Senator Steve Langford to make 16 the age of consent passed in 1995.
- In 2006, aggravated child molestation was reduced to a misdemeanor with a maximum of one year in prison under certain conditions.
- The conditions for the reduced misdemeanor sentence in 2006 were: the offender was under 19, the victim was either 14 or 15 years old, and

# China's One-Child Policy

One-child policy
- It was a population planning policy of China.
- It was introduced in 1979.
- It began to be formally phased out in 2015.
- It allowed exceptions for ethnic minorities.
- In 2007, 36% of China's population was subject to a strict one-child restriction.
- An additional 53% were allowed to have a second child if the first child was a girl.
- Provincial governments imposed fines for violations.
- Local and national governments created commissions to raise awareness.
- Local and national governments carried out registration and inspection work.
- The one - child policy, a part of the family planning policy, was a population planning policy of China.
- It began to be formally phased out near the end of 2015 and the beginning of 2016.
- The policy was only enforced on Han Chinese.
- It allowed exceptions for many groups, including ethnic minorities.
- China's first imperial dynasty was the Qin dynasty (221–206 BC).
- Qin unified the Chinese Warring States by conquest.
- Xiang Yu (d. 202 BC) of Chu was a former rebel leader.
- Liu Bang (d. 195 BC) of Han was a former rebel leader.
- Liu Bang defeated Xiang Yu at Battle of Gaixia (202 BC).
- Liu Bang assumed the title "emperor" (huangdi).
- Liu Bang is known posthumously as Emperor Gaozu (r. 202–195 BC).
- Chang'an was chosen as the new capital of

# Chumak Food Processing Company

Chumak (company)
- Chumak is a Swedish-Ukrainian food processing company.
- It is located in Kakhovka, Kherson Oblast.
- It is one of Ukraine's biggest food processing companies.
- It has commercial offices in Kiev.
- It has commercial offices in Minsk.
- It has commercial offices in Moscow.
- Its products include ketchup.
- Its products include mayonnaise.
- Its products include pasta.
- Its products include salad dressings.
- Its products include cooking sauces.
- Its products include canned vegetables.
- Its products include marinated vegetables.
- Its products include tomato juice.
- Its products include sunflower oil.
- Chumak is the largest tomato processing company in Central and Eastern Europe.
- The company employs about 1200 people (2010).
- The company has a revenue of about 48 million Euros (2010).

# Circus Time (TV Program)

Circus Time was a variety program.
Circus Time was presented in the United States.
Circus Time was part of ABC's 1956-57 season.

# Ciudad Deportiva Nuevo Laredo

Ciudad Deportiva (Nuevo Laredo)
- The Ciudad Deportiva is a sports complex in Nuevo Laredo, Mexico.
- It is home to the Tecolotes de Nuevo Laredo Mexican Baseball League team.
- It is home to the Toros de Nuevo Laredo Mexican professional basketball team from the Liga Nacional de Baloncesto Profesional.
- The Ciudad Deportiva's Estadio Nuevo Laredo can seat up to 12,000 fans at a baseball game.
- The Nuevo Laredo Multidisciplinary Gymnasium can seat 4,000 fans at a basketball game.
- It is a multi-use stadium in Tarma, Peru.
- It is currently used mostly for football matches.
- It is the home stadium of Asociación Deportiva Tarma of the Copa Perú.
- The stadium holds 9,000 spectators.
- The Stadio Giuseppe Grezar was a multi-use stadium in Trieste, Italy.
- It was inaugurated in 1932 as the Stadio Littorio.
- It was initially used as the stadium of U.S. Triestina Calcio matches.
- The capacity of the stadium was 8,000.
- It hosted the match between Czechoslovakia and Romania during the 1934 FIFA World Cup.

# Clarice Starling Actors

Clarice Starling
- She was played by Jodie Foster in the film adaptation of The Silence of the Lambs.
- She was played by Julianne Moore in the film adaptation of Hannibal.
- Hannibal is a 2001 American psychological horror film.
- It is directed by Ridley Scott.
- It is adapted from the novel of the same name by Thomas Harris.
- It is the sequel to the 1991 film The Silence of the Lambs.
- Anthony Hopkins returns to his role as Hannibal Lecter.
- Julianne Moore co-stars as FBI Special Agent Clarice Starling.
- Gaspard Ulliel is a French actor and model.
- He was born on 25 November 1984.
- He is best known for portraying serial killer Hannibal Lecter in "Hannibal Rising" (2007).
- He portrayed fashion mogul Yves Saint Laurent in the biopic "Saint Laurent" (2014).
- He is the face of the Chanel men's fragrance, Bleu de Chanel.

# Collective Soul Debut Album

Hints Allegations and Things Left Unsaid is the debut studio album by Collective Soul.
It was released on Rising Storm Records in 1993.
The track "Shine" gained the band attention.
They later signed with Atlantic Records.
The album was released on CD in 1994 under the Atlantic label.
- Soul Fixin' Man is an album by American blues guitarist Luther Allison.
- It was released in 1994 by Alligator Records.
- It is also known as "Bad Love".
- Some editions have a different track listing.
- Three for Shepp is the debut album by American saxophonist Marion Brown.
- It features performances recorded in 1966 for the Impulse! label.

# Coloane Park

- Coloane Park is a large park
- It is located on Coloane Island
- Coloane Island is in Macau
- Macau is a Special Administrative Region of the People's Republic of China
- Coloane Park is located on the southern section of Coloane Island

# Comanche and Texans Conflict

Comanche were known as the ``Lords of the Plains. ''
The Comanche occupied territory in the area.
The Comancheria was the most powerful entity.
The Comancheria was persistently hostile to the Spanish.
The Comancheria was persistently hostile to the Mexicans.
The Comancheria was persistently hostile to the Texans.
This article covers conflicts from 1820.
Mexico gained independence from Spain before 1820.
The last free band of Plains Indians, the Comanches, surrendered in 1875.
Quanah Parker was a Quahadi warrior.
The Comanches led by Quanah Parker moved to the Fort Sill reservation in Oklahoma.
- The Comanche were known as the ``Lords of the Plains. ''
- This article covers the conflicts from 1820, just before Mexico gained independence from
- The Basotho National Party is a political party in Lesotho.
- The Basotho National Party was founded in 1959 as the Basutoland National Party.
- Leabua Jonathan founded the Basotho National Party.
- Leabua Jonathan was Prime Minister from 1965 until the coup of 1986.
- Quahadi warrior Quanah Parker led the Comanches.
- The Comanches moved to the Fort Sill reservation in Oklahoma.
- The article covers the conflicts from 1820 until 1875.
- Mexico gained independence from Spain just before 1820.
- This article covers the conflicts from 1820 until 1875.

# Comcast Sports Southwest

Comcast Sports Southwest
- It was an American regional sports network.
- It served Greater Houston, Texas.
- It was owned by the NBC Sports Group unit of NBCUniversal.
- The channel launched on September 1, 2009.
- It had a similar format to Comcast/Charter Sports Southeast.
- Comcast/Charter Sports Southeast launched ten years earlier.
- Both networks shared the same logo.
- Both networks focused primarily on collegiate and high school sports.
- It launched July 1, 1995.
- It is owned by NBC Sports Group.
- It has a picture format of 1080i (HDTV).
- It is downconverted to letterboxed 480i for SDTV feed.
- Its slogan is "Believe".
- It broadcasts nationwide.
- It is headquartered in Stamford, Connecticut.
- It was formerly called Outdoor Life Network (1995 -- 2006).
- It was formerly called Versus (2006 -- 11).
- It was formerly called NBC Sports Network (2012 -- 13).
- It has sister
- It launched August 17, 2013.
- It is owned by Fox Entertainment Group (21st Century Fox).
- Its picture format is 720p (HDTV).
- Its slogan is "The 1".
- It is headquartered in Los Angeles, California.
- It replaced Speed (2005 -- 2013).
- It broadcasts in the United States, Puerto Rico, and the Caribbean.
- It is available on DirecTV Channel 219 (HD / SD).
- It is available on Dish Network Channel 150 (HD / SD).
- It is available on most U.S. cable systems
- Fox Sports West and Prime Ticket are American regional sports networks.
- They are owned by The Walt Disney Company.
- They operate as Fox Sports Networks affiliates.
- They broadcast regional coverage of professional and collegiate sports events in California.
- They focus primarily on professional sports teams based in the Greater Los Angeles area.
- Fox Sports West and Prime Ticket maintain general offices and studios based at the Staples Center in Downtown Los Angeles.

# Commission for Scheduled Castes

- The first Commission for Scheduled Castes and Scheduled Tribes was set up in August 1978.
- Bhola Paswan Shastri was Chairman of the first Commission.
- The first Commission had four Members.
- In 1990 the Commission for SCs and STs was renamed.
- The National Commission for Scheduled Castes and Scheduled Tribes was formed in 1987.
- The National Commission is a National Level Advisory Body.
- The National Commission advises the Government on broad policy issues.
- The National Commission advises the Government on levels of development of Scheduled Castes and Scheduled Tribes.
- The Directive Principles of State Policy are guidelines for the framing of laws by the government.
- These provisions are set out in Part IV of the Constitution.
- The Directive Principles of State Policy are not enforceable by the courts.
- The Fundamental Rights are defined as the basic human rights of all citizens.
- These rights are defined in Part III of the Constitution.
- These rights applied irrespective of race, place of birth, religion, caste, creed, or gender.
- The Fundamental Rights are enforceable by the courts, subject to specific restrictions.

# Common Nightingale Habitat

- The common nightingale is a migratory insectivorous species.
- It breeds in forest and scrub in Europe and south - west Asia.
- It winters in sub-Saharan Africa.
- It is not found naturally in the Americas.
- Its distribution is more southerly than the thrush nightingale Luscinia luscinia.
- It nests on or near the ground in dense vegetation.
- Research in Germany found that favoured breeding habitat of nightingales was defined by a number of geographical factors.

# Confederation of Finnish Industries

Confederation of Finnish Industries
- It is the largest employers' association in Finland.
- It is known as EK.
- It was formed at the beginning of 2005.
- It formed from the merger of "Palvelutyönantajat" and "Teollisuuden ja Työnantajain Keskusliitto".
- Member companies contribute over 70% of Finland's GDP.
- Member companies contribute over 95% of Finland's exports.
- It has considerable negotiating power.
- Finland has universal validity of collective labour agreements.
- A national income policy agreement is often reached.

# Confederation of Regions Party

Confederation of Regions Party of Canada
- The Confederation of Regions Party (CoR) was a right-wing federal political party in Canada.
- It was founded in 1984 by Elmer Knutson.
- It was founded as a successor to the Western Canada Federation (West-Fed).
- West-Fed was a non-partisan organization.
- The CoR aimed to fight the Liberal Party of Canada.
- The CoR aimed to fill the void on the right of the political spectrum.
- The Social Credit Party of Canada declined.
- Westerners were growing unpopular with the Progressive Conservative Party of Canada under Brian Mulroney.
- Islamic Iran Solidarity Party (; "Hezb-e Hambastegi-e Iran-e Eslami") is an Iranian reformist political party.
- It was founded in 1998 by 10 members of Parliament of Iran.
- It is a member of Council for coordinating the Reforms Front.
- It publishes newspaper "Hambastegi".
- Ali Asghar Ahmadi is currently the General Secretary.
- Ebrahim Asgharzadeh previously held the office of General Secretary.
- Mohamadreza Raahchamani previously held the office of General Secretary.
- They have supported Mohammad Khatami in 2001 election.
- They have
- The Congress of the New Right (, Nowa Prawica or just KNP) is an economically libertarian, socially conservative and Eurosceptic political party in Poland.
- It was founded on 25 March 2011 by Janusz Korwin-Mikke.
- It was formed from the merger of the Liberty and Lawfulness (WiP) with several members of the Real Politics Union (UPR).
- Janusz Korwin-Mikke was ousted from the party in 2015.
- The party assumed the official name Congress of the New Right on 12 May 2011.

# Constance of Burgundy

Constance of Burgundy
- Constance of Burgundy was born on May 8, 1046.
- She was the daughter of Duke Robert I of Burgundy and Helie de Semur-en-Brionnais.
- She was Queen consort of Castile and León.
- She married Alfonso VI of León and Castile.
- She was the granddaughter of King Robert II of France.
- King Robert II of France was the second monarch of the French Capetian dynasty.
- She was the mother of Urraca of León.
- Urraca of León succeeded her father in both Castile and León.
- Childebrand I (678, Heristal - 751) was a Frankish duke.
- He was the son of Pepin of Heristal and Alpaida.
- He was the brother of Charles Martel.
- He married Emma of Austrasia.
- He was given Burgundy by his father.
- He distinguished himself in the expulsion of the Saracens from France.
- Maria de las Mercedes of Orléans was born on June 24, 1860.
- She died on June 26, 1878.
- She was Queen of Spain.
- She was the first wife of King Alfonso XII.
- Her father was Antoine of Orléans, Duke of Montpensier.
- Her mother was Infanta Luisa Fernanda of Spain.
- Sigrid Eskilsdotter (Banér) died in 1527.
- She was a Swedish noble.
- She was the mother of Christina Gyllenstierna.
- She was the maternal grandmother of King Gustav Vasa of Sweden.

# Cooper Glacier Facts

Cooper Glacier
- It is a tributary glacier
- It flows northeast between Butchers Spur and the Quarles Range
- It enters the south side of Axel Heiberg Glacier
- It is in the Queen Maud Mountains
- R. Admiral Byrd discovered it in November 1929
- It was named by R. Admiral Byrd for Kent Cooper
- Kent Cooper was an official of the Associated Press
- Hangin' with Mr. Cooper is an American television sitcom.
- It originally aired on ABC from September 22, 1992 to August 30, 1997.
- It starred Mark Curry and Holly Robinson.
- The show took place in Oakland, California.
- It was produced by Jeff Franklin Productions.
- It was produced in association with Warner Bros. Television.
- It was originally produced by Lorimar Television for the first season.
- It was produced by Bickley - Warren Productions by the third season.
- It originally aired on Tuesdays in prime time after Full House.
- It was part of the TGIF Friday night lineup on ABC from September

# Copper Toxicity and Diet

Copper Toxicity
- Copper salts have been taken in suicide attempts.
- Copper salts produce acute copper toxicity in humans.
- Copper toxicity may be due to redox cycling.
- Copper toxicity may be due to the generation of reactive oxygen species.
- Copper toxicity damages DNA.
- 30 mg/kg of copper salts are toxic in animals.
- A minimum dietary value for healthy growth in rabbits is at least 3 ppm.
- Higher concentrations of copper (100 ppm) may favorably influence feed conversion efficiency.
- Higher concentrations of copper (200 ppm) may favorably influence growth rates.
- Higher concentrations of copper (500 ppm) may favorably influence carcass dressing percentages.

# Cork City Industry

Cork City
- Cork City is at the heart of industry in the south of Ireland.
- Its main area of industry is pharmaceuticals.
- Pfizer Inc. is a big employer in the region.
- Novartis is a big employer in the region.
- Viagra is the most famous product of the Cork pharmaceutical industry.
- Cork is the European headquarters of Apple Inc.
- Over 3,000 staff are involved in manufacturing at Apple Inc.
- Over 3,000 staff are involved in R&D at Apple Inc.
- Over 3,000 staff are involved in customer support at Apple Inc.
- Logitech is an important IT employer in the area.
- EMC Corporation is an important IT employer in the area.
- Three hospitals are among the top ten employers in the city.
- Shipbuilding became an important industry for the town during the Middle Ages.
- Henry V's warship HMS Grace Dieu was built in Southampton.
- Walter Taylor's 18th century mechanisation of the block-making process was a significant step in the Industrial Revolution.
- The Thornycroft shipbuilding yard was a major employer in Southampton from 1904 to 2004.
- The Thornycroft shipbuilding yard built and repaired ships used in the two World Wars.
- Local government in Ireland has limited powers in comparison with other countries.
- Cork City Council has 31 elected members.
- The council has responsibility for planning, roads, sanitation, libraries, street lighting, parks, and a number of other important functions.
- There are six electoral wards.
- 5 members are affiliated to Fine Gael.
- 10 members are affiliated to Fianna Fáil.
- 8 members are affiliated to Sinn Féin.
- 3 members are affiliated to Anti-Austerity Alliance.
- 1 member is affiliated to Workers' Party.
- 4 members are Independents.
- Certain councillors are co-opted to represent the city at

# CRJ Series Operators

- Bombardier produced the CRJ100 and CRJ200 series.
- The CRJ100 and CRJ200 series are no longer in production.
- The CRJ100 and CRJ200 series are still in active airline service.
- Bombardier produced the CRJ700, CRJ900 and CRJ1000 series.
- The CRJ700, CRJ900 and CRJ1000 series are in production.
- The CRJ700, CRJ900 and CRJ1000 series are in service.
- Bombardier Inc. is a Canadian aerospace and defence company.
- Bombardier Aerospace is a division of Bombardier Inc.
- The Learjet 60 is a mid-size cabin, medium-range business jet aircraft.
- The Learjet 60 is manufactured by Bombardier Aerospace in Wichita, Kansas.
- The Learjet 60 is powered by two Pratt & Whitney Canada PW305A engines.
- The Learjet 60 has a range (with 4 passengers and 2 crew) of with NBAA reserves, ISA.
- In July 2012 Bombardier Aerospace announced a temporary "production pause" of the latest variant Learjet 60XR.
- The production pause of the Learjet 60XR was to begin in the fourth quarter of 2012.

# Crystal Kay

Crystal Kay
- Crystal Kay released her debut single "Eternal Memories" in 1999.
- Crystal Kay gained fame for her third studio album "Almost Seventeen" (2002).
- "Almost Seventeen" debuted at number 2 on the Japanese Oricon charts.
- "Almost Seventeen" sold over 400,000 copies.
- "Almost Seventeen" was certified platinum by the Recording Industry Association of Japan.
- Crystal Kay was formerly signed to Epic Records.
- Crystal Kay was signed to Epic Records, a sub-label of Sony Music Japan for 12 years.
- Crystal Kay transferred to Delicious Deli Records in 2011.
- Delicious Deli Records is a sub-label of Universal Music Japan.
- Crystal is an album by American jazz pianist Ahmad Jamal.
- The album was recorded in 1987.
- The album was released on the Atlantic label.
- (Miss)understood is the seventh studio album by Japanese singer-songwriter Ayumi Hamasaki.
- (Miss)understood was released January 1, 2006 by Avex Trax.
- Hamasaki acted as the album's sole lyricist.
- Hamasaki had explored new influences such as funk.
- Hamasaki used gospel choruses in some of the songs.
- This was the result of her having heard compositions by Geo from Sweetbox.
- Hamasaki asked Geo for his works.
- Lyrically, the album was a departure from her previous work, "My Story".
- "My Story" had been primarily autobiographical.
- Kamryn Belle was raised in the Netherlands.
- Kamryn Belle currently lives in the Netherlands.
- Kamryn Belle is the youngest of six children.
- Kamryn Belle comes from a musical family.
- Kamryn Belle's dad was a singer in a band.
- Kamryn Belle's three brothers all played an instrument.
- Kamryn Belle started singing more often when she was growing up.
- Kamryn Belle gained more experience when she was growing up.
- Kamryn Belle writes songs.
- Kamryn Belle records songs.
- Kamryn Belle has a home studio.
- Leslie Feist was born on 13 February 1976.
- Leslie Feist is known professionally as Feist.
- Feist is a Canadian.
- Feist is an indie pop singer.
- Feist is a singer - songwriter.
- Feist is a guitarist.
- Feist performs as a solo artist.
- Feist is a member of the indie rock group Broken Social Scene.

# Cyprus Popular Bank

Cyprus Popular Bank
- Cyprus Popular Bank was known as Marfin Popular Bank from 2006 to 2011.
- Cyprus Popular Bank was the second largest banking group in Cyprus.
- It was second to the Bank of Cyprus.
- Cyprus Popular Bank was shut down in March 2013.
- It was split into two parts.
- The 'good' part was merged into the Bank of Cyprus.
- The 'good' part included insured deposits under 100,000 Euro.
- The 'bad' part or legacy entity holds overseas operations.
- The 'bad' part holds uninsured deposits above 100,000 Euro.
- The 'bad' part holds old shares and bonds.
- Uninsured depositors became the new shareholders of the legacy entity.
- As of May 2017, the legacy entity held 4.8% of Bank
- The legacy entity is one of the largest shareholders of Bank of Cyprus with 4.8%.
- The legacy entity does not hold a board seat.
- All the overseas operations of the now defunct Cyprus Popular Bank are held by the legacy entity.
- The Special Administrator was first Ms Andri Antoniadou.
- Ms Andri Antoniadou ran the legacy entity for two years, from March 2013 until 3 March 2015.
- Ms Andri Antoniadou tendered her resignation due to disagreements with the Governor of the Central Bank of Cyprus and the Central Bank Board members.
- The Central Bank Board members amended the lawyers of the legacy entity without consulting Ms Andri Antoniadou.
- Chris Pavlou
- Veteran banker Chris Pavlou took over as Special Administrator of the legacy entity in April 2015 until December 2016.
- The legacy entity is pursuing legal action against former major shareholder Marfin Investment Group.
- Cyprus Popular Bank (from 2006 to 2011 known as Marfin Popular Bank) was the second largest banking group in Cyprus behind the Bank of Cyprus until it was 'shuttered' in March 2013 and split into two parts.
- The uninsured depositors were subject to a bail-in.
- Veteran banker Chris Pavlou is an expert in Treasury and risk management.
- She tendered her resignation due to disagreements, with the Governor of the Central Bank of Cyprus and the Central Bank Board members, who amended the lawyers of the legacy entity, without consulting her.
- The 'good' Cypriot part was merged into the Bank of Cyprus (including insured deposits under 100,000 Euro).
- The uninsured depositors were subject to a bail-in and became the new shareholders of the legacy entity.
- All the overseas operations, of the now defunct Cyprus Popular Bank, are also held by the legacy entity, until they are sold by the Special Administrator.
- James III of Cyprus (or Jacques III de Lusignan) was born on 6 July 1473.
- James III of Cyprus (or Jacques III de Lusignan) died on 26 August 1474.
- James III of Cyprus was the only child of James II of Cyprus and Catherine Cornaro.
- His mother was the last Queen of Cyprus.
- His death paved the way for Venice to gain control of Cyprus.

# Darial, Pakistan Town

Darial, Pakistan
- Darial is a town in the Islamabad Capital Territory of Pakistan.
- It is located at 33° 23' 35N 73° 19' 45E.
- Its altitude is 494 metres.
- Its altitude is 1624 feet.

# Datsun Brand History

- Datsun is an automobile brand.
- Datsun is owned by Nissan.
- Datsun's original production run began in 1931.
- From 1958 to 1986, only vehicles exported by Nissan were identified as Datsun.
- Nissan phased out the Datsun name by 1986.
- Datsun was re-launched in June 2013.
- Datsun is a brand for low-cost vehicles.
- Datsun vehicles are manufactured for emerging markets.

# David Profumo Family History

- David Profumo was born in London.
- David Profumo’s father was John Profumo.
- David Profumo’s mother was Valerie Hobson.
- The Profumo family is of Italian origin.
- David Profumo would have succeeded his father as 6th Baron Profumo.
- The nobility of Italy was legally abolished after WW2.
- Like his father, David Profumo does not use this title.
- Godfrey Baring was the son of Lieutenant-General Charles Baring.
- Godfrey Baring was the son of Henry Bingham Baring.
- Godfrey Baring was the son of Henry Baring.
- Godfrey Baring was the son of Sir Francis Baring, 1st Baronet.
- Godfrey Baring’s mother was Helen Graham.
- Godfrey Baring’s mother was the daughter of Sir James Graham, 2nd Baronet.
- Godfrey Baring was a lifelong resident of the Isle of Wight.
- Godfrey Baring was elected president of the Isle of Wight Liberal Union aged 23.
- Godfrey Baring was made a Justice of the Peace a year after being elected president
- David Profumo was born in London, the son of former British government minister John Profumo and his wife, actress Valerie Hobson.
- David Profumo would have succeeded his father as 6th Baron Profumo in the nobility of the Kingdom of Sardinia, if the nobility of Italy had not been legally abolished after WW2.
- Like his father, he does not use this title.

# David's difficult decision

The Memory Keeper's Daughter
- The story begins in early March of 1964.
- Dr. David Henry delivers his wife Norah's twins.
- Caroline Gill helps Dr. David Henry deliver the twins.
- Their first child is a boy named Paul.
- Paul is a healthy, perfect child.
- Their second child is a girl named Phoebe.
- Phoebe has Down syndrome.
- David's younger sister June died at the age of twelve.
- June had a heart defect.
- David decides Phoebe will be placed in an institution.
- Theo Carver is the newborn son of Abe Carver and Lexie Carver.
- Dena Higley created the character.
- Chase and Tyler Johnson appeared in the role from 2003 to 2004.
- Kavi Faquir appeared in the role from 2006 to 2007.
- Amyrh Harris appeared in the role from 2007.
- Terrell Ransom, Jr. appeared in the role in 2008.
- Theo was diagnosed with autism in 2008.
- Theo's autism diagnosis was his most significant storyline.
- Theo had a close friendship with Ciara Brady.
- Terrell Ransom

# Def Squad rap group

Def Squad
- Def Squad is a rap supergroup.
- It consists of Erick Sermon, Redman and Keith Murray.
- Jamal is an honorary member of the Def Squad.
- They had each been featured on tracks by each other before forming as a group.
- The Def Squad was formed following the disbandment of the Hit Squad.
- The Hit Squad broke up after struggles between EPMD members Erick Sermon and Parrish Smith.

# DeSoto Records Label

DeSoto Records
- It is an American record label.
- It is based in Washington, D.C.
- It was founded in 1989.
- It is run by Bill Barbot and Kim Coletta.
- Bill Barbot and Kim Coletta were formerly of the band Jawbox.
- It was first founded by members of the band Edsel.
- Edsel released their first single, "My Manacles".
- Jawbox used the name DeSoto for their first EP.
- It has released over 40 records.
- It has released 7" singles.
- It has released CDs.
- It has released LP vinyl records.
- It is distributed by Fontana Distribution.
- It is based in Guelph, Ontario, Canada.
- It was founded in 1999 by Lisa Moran and Tyler Clarke Burke.
- It was founded as a vehicle for releasing albums by their friends.
- It became an influential player in Canadian music.
- The Constantines' self-titled 2001 release was on the label.
- Its releases were distributed by Outside Music.
- Sleaszy Rider Records is an independent record label.
- It was founded in 1999 by Tolis G. Palantzas.
- The head office of the label is located in Greece.
- It is mainly distributed in Europe by Sony Music/EMI.
- It distributes releases in Greece from numerous labels, including Roadrunner Records, SPV, and Pagan Records.
- John Kirtland co-founded Kirtland Records with his wife, Jenny Kirtland.
- Jenny Kirtland is a member of The Polyphonic Spree choir.
- Kirtland Records leveraged the Bush back catalog rights.
- Kirtland Records secured a national distribution deal with RED Distribution.
- RED Distribution remains the label's distributor.
- Kirtland Records became the record label for the Burden Brothers.
- Kirtland Records became the record label for The Polyphonic Spree.
- Kirtland Records became the record label for Toadies.
- Kirtland Records became the record label for The Vanished.
- Kirtland Records became the record label for
- He is also known as LeRoi Evans and LeRoy Evans.
- He is an American record producer.
- He is a recording engineer.
- He is a songwriter.
- He is a musician.
- He is an entrepreneur.
- He is a businessman.
- He is the CEO and co-owner of JAMBOX Entertainment.
- He currently resides in midtown Manhattan, New York.
- Roxy Recordings is an independent record label.
- It is based in Kungsholmen, Stockholm, Sweden.
- Its office is the former site of Cheiron Studios and its successor The Location.
- Universal Music Group bought it in August 2011.
- It is owned by Playground Music Scandinavia.
- It is mostly active on the Swedish market.
- Agnes Carlsson and Erik Hassle were former signed artists.
- Agnes sold almost one million copies of "Release Me" in 2009.
- "Release Me" was released under Roxy's licence in 35 countries.
- Erik Hassle was successful with his hit "Hurtful" in the UK
- Golgoth 13 were a French band.
- They were formed in 2000 in Bayonne (France) by Sébastien Lasserre (guitar) and Grégory Sentenac (organ).
- Sylvain Aubert joined on scratches and sampling.
- They recorded their first album "Golgoth 13 et leur "fantastic rodéo sound"" in August 2000.
- Hervé Zwingelstein joined as a fourth member, on bass guitar.
- Grégory Sentenac was replaced by Stéphane Paulini (organ).
- Stéphane Garin joined on organ and percussion.
- They separated in 2007.
- Kill Rock Stars is an independent record label.
- It was founded in 1991 by Slim Moon and Tinuviel Sampson.
- It is based in both Olympia, Washington, and Portland, Oregon.
- It was originally known for its commitment to underground punk rock bands.
- It was originally known for its commitment to the Olympia area music scene.

# Djenar Maesa Ayu

Djenar Maesa Ayu was born on 14 January 1973.
Djenar Maesa Ayu was born in Jakarta, Indonesia.
Djenar Maesa Ayu is also known as Nay.
Djenar Maesa Ayu is an Indonesian novelist.
Djenar Maesa Ayu is a short story writer.
Djenar Maesa Ayu is an actress.
Djenar Maesa Ayu is a screenwriter.
Djenar Maesa Ayu is a filmmaker.
Djenar Maesa Ayu's work has been described as "provocative and lurid".
Djenar Maesa Ayu's work has been described as unique and brave.
Djenar Maesa Ayu is considered a member of the informal movement labeled sastra wangi.

# Dog Star Man Films

Dog Star Man
- Dog Star Man is a series of short experimental films
- The films were directed by Stan Brakhage
- Jane Wodening featured in the films
- The series was released during 1961 to 1964
- It comprises a prelude and four parts

# Don Khong Island

- Khong Island is the largest island
- Khong Island is also called Don Khong
- Khong Island is the seat of administration
- Khong Island is located in the Si Phan Don riverine archipelago
- Khong Island is located in the Mekong River
- Khong Island is located in Khong District
- Khong Island is located in Champasak Province
- Khong Island is located in southern Laos
- Khong Island or Don Khong

# Door Creek, Wisconsin

Door Creek, Wisconsin
- Door Creek is also known as Buckeye.
- Door Creek is also known as Deer Creek.
- Door Creek is located in the town of Cottage Grove.
- Door Creek is located in Dane County.
- Door Creek is located in Wisconsin.
- Door Creek is an unincorporated community.
- Indian Heights is located on Lake Koshkonong.
- Indian Heights is located east-northeast of Edgerton.
- Indian Heights is located in the town of Albion.
- Indian Heights is located in the United States.
- The population of Dane was 968 at the 2000 census.
- The unincorporated community of Lutheran Hill is located partially in the town.

# Dunbar Hospital, Detroit

Dunbar Hospital
- It was the first hospital for the black community in Detroit, Michigan.
- It is located at 580 Frederick Street.
- It is the administrative headquarters of the Detroit Medical Society.
- It was listed on the National Register of Historic Places in 1979.
- It is currently the administrative headquarters of the Detroit Medical Society.

# Dust on the Bottle (single)

- Dust on the Bottle is a single by David Lee Murphy.
- It is from the album Out with a Bang B.
- The B-side is Mama 'n Them.
- It was released on August 7, 1995.
- It was released in the format of a cassette single.
- The genre is country, country rock.
- The length is 3:44.
- The label is MCA.
- David Lee Murphy is the songwriter.
- Tony Brown and David Lee Murphy are producers.
- It followed the single Party Crowd.
- It preceded the single Out with a Bang.

# DVD Flick Software

DVD Flick
- DVD Flick is an open source DVD authoring application
- DVD Flick is for Windows
- DVD Flick was developed by Dennis Meuwissen
- DVD Flick is released under the GNU General Public License
- DVD Flick is capable of importing audio tracks
- DVD Flick is capable of importing video files
- DVD Flick is capable of importing subtitles
- DVD Flick can compose a DVD-Video movie
- DVD Flick can burn to a disc
- DVD Flick can create an ISO image

# EA Sports Games

EA Sports
- EA Sports is a division and brand of Electronic Arts
- EA Sports creates and develops sports video games
- EA Sports used to be a marketing gimmick of Electronic Arts
- They tried to imitate real-life sports networks
- They called themselves the ``EA Sports Network ''(EASN)
- They used pictures and endorsements with real commentators such as John Madden
- It grew up to become a sub-label on its own
- EA Sports releases game series such as NBA Live
- EA Sports releases game series such as FIFA
- EA Sports releases game series such as NHL
- EA Sports releases game series such as Madden NFL
- EA Sports releases game series such as NASCAR
- The best selling EA Sports series is the FIFA series
- Over 100 million units of the FIFA series have been sold
- Futbol is the most popular sport
- Baseball is a popular sport
- Volleyball is a popular sport
- Basketball is a popular sport
- Tennis is a popular sport
- Fox Sports 1 launched August 17, 2013.
- Fox Sports 1 is owned by Fox Entertainment Group (21st Century Fox).
- Fox Sports 1's slogan is "The 1".
- Fox Sports 1 is available in the United States, Puerto Rico, and the Caribbean.
- Fox Sports 1's broadcast area is the United States, Puerto Rico, and the Caribbean.
- Fox Sports 1's headquarters are in Los Angeles, California.
- Fox Sports 1 replaced Speed (2005 -- 2013).
- Fox Sports 1 has sister channels: Fox Sports 2, Fox Soccer Plus, Fox
- Spry Fox is a video game producing company
- Spry Fox is headquartered in Seattle, United States
- Spry Fox was founded in 2010 by David Edery and Daniel Cook
- Spry Fox produced the game Triple Town
- Triple Town is a freemium strategy puzzle game
- Triple Town has city-building game elements
- Triple Town is for social networks and mobile devices
- Spry Fox produced the game Steambirds
- Steambirds is a strategy flying game
- Steambirds is for mobile devices
- Spry Fox produced the game Road Not Taken
- Road Not Taken is a roguelike puzzle game
- Spry Fox co-

# Early Recording Instrument Placement

Phonograph Record
- Drums could be effectively used and heard on early jazz and military band recordings if placed properly
- The loudest instruments, such as drums and trumpets, were positioned farthest from the collecting horn
- Lillian Hardin Armstrong was a member of King Oliver's Creole Jazz Band
- King Oliver's Creole Jazz Band recorded at Gennett Records in 1923
- Louis Armstrong was a young second trumpet in King Oliver's Creole Jazz Band
- Initially, Oliver and Louis Armstrong stood next to each other and Oliver's horn could not be heard
- Louis Armstrong was placed fifteen feet away in the corner
- Some performers were placed on a moveable platform
- A moveable platform could draw performers nearer or further away as required

# Echo Falls Mystery Series

- Down The Rabbit Hole is the first book in the Echo Falls mystery series.
- Peter Abrahams is the author of Down The Rabbit Hole.
- Ingrid is in the wrong place at the wrong time.
- Ingrid's shoes are in the wrong place at the wrong time.
- Getting Ingrid's shoes back will mean getting tangled up in a murder investigation.
- The murder investigation is complicated.
- Sherlock Holmes is Ingrid's idol.
- Ingrid has soccer practice.
- Ingrid has schoolwork.
- Ingrid has the lead role in her town's production of Alice in Wonderland.
- Ingrid realizes she must solve the murder on her own.
- Things in Echo Falls keep getting curiouser and curiouser.

# Eddie Argos

Eddie Argos
* Eddie Argos was born Kevin Macklin.
* Eddie Argos was born on 25 October 1979.
* Eddie Argos is the lead singer of Art Brut.
* Eddie Argos is a writer of comics.
* Eddie Argos is English.
* Art Brut is an English rock band.

# Edita Mazurevičiūtė (cyclist)

Edita Mazurevičiūtė
- Edita Mazurevičiūtė was born on 10 January 1996.
- Edita Mazurevičiūtė is a track cyclist from Lithuania.
- She represented Lithuania at the 2015 UCI Track Cycling World Championships.

# Edmund, Earl of Kent

Edmund of Woodstock, 1st Earl of Kent
- Edmund of Woodstock was born on 5 August 1301.
- Edmund of Woodstock died on 19 March 1330.
- Edmund of Woodstock was the sixth son of Edward I of England.
- Edmund of Woodstock was a younger half-brother of Edward II.
- Edward I intended to make substantial grants of land to Edmund.
- Edward II failed to follow through on Edward I's intentions.
- Edward II showed favouritism towards Piers Gaveston.
- Edmund remained loyal to his brother, Edward II.
- Edmund was created Earl of Kent in 1321.
- Edmund played an important part in Edward's administration.
- Edmund acted as a diplomat.
- Edmund acted as a military commander.
- Edmund helped suppress a rebellion against the King in 1321–22.
- Sir William Maule was the eldest son of Sir Peter Maule and Christina de Valognes.
- Sir William Maule was Baron of Panmure and Benvie.
- Sir William Maule was married to Ethana de Vallibus.
- Ethana de Vallibus was the daughter of John Vaux, Lord of Dirleton.
- Sir William Maule left one son, Henry Maule.
- Henry Maule succeeded him as Baron.
- Edward Stafford, 3rd Baron Stafford was born on 7 January 1535.
- Edward Stafford, 3rd Baron Stafford died on 18 October 1603.
- Edward Stafford, 3rd Baron Stafford was the second surviving son of Henry Stafford, 1st Baron Stafford and Ursula Pole.
- Edward Stafford, 3rd Baron Stafford was the younger brother of Henry Stafford, 2nd Baron Stafford.
- Edward Stafford, 3rd Baron Stafford served in Parliament for Stafford.
- Edward Stafford, 3rd Baron Stafford succeeded his brother to the barony in 1566.
- Nikola Radonja was born around 1330.
- Nikola Radonja died in 1399.
- Nikola Radonja was a Serbian nobleman.
- Nikola Radonja was a chronicler.
- Nikola Radonja was a member of the Branković dynasty.
- Nikola Radonja was the eldest son of Branko Mladenović.
- Nikola Radonja is remembered as the author of "Gerasim's Chronicle."
- Nikola Radonja was also known as Nikola Radonja Branković.
- Nikola Radonja was also known as Gerasim.
- Nikola Radonja was also known as Roman.

# Edward Dannreuther: Life

Edward George Dannreuther was born on 4 November 1844 in Strasbourg.
Edward George Dannreuther died on 12 February 1905 in Hastings.
Edward George Dannreuther was a German pianist.
Edward George Dannreuther was a writer on music.
Edward George Dannreuther resided in England from 1863.
Edward George Dannreuther’s father established a piano manufacturing business in Cincinnati.
Edward George Dannreuther’s father had crossed the Atlantic.
Edward George Dannreuther went to Leipzig in 1859.
Edward George Dannreuther’s father wanted him to enter banking as a career.
Edward George Dannreuther found the prospect of banking uncongenial.

# Edward VIII Birth Details

Edward VIII
- Edward was born on 23 June 1894
- He was born at White Lodge, Richmond Park
- White Lodge is on the outskirts of London
- Edward was born during the reign of Queen Victoria
- He was the eldest son of the Duke and Duchess of York
- The Duke and Duchess of York later became King George V and Queen Mary
- His father was the son of King Edward VII and Queen Alexandra
- His mother was the eldest daughter of Francis and Mary Adelaide
- His mother was the eldest daughter of the Duke and Duchess of Teck
- At the time of his birth, he was third in the line of succession to the throne
- He was third in the line of succession behind his grandfather and father
- François-Ferdinand-Philippe-Louis-Marie d'Orléans was born on 14 August 1818
- François-Ferdinand-Philippe-Louis-Marie d'Orléans died on 16 June 1900
- He was the third son of Louis Philippe, Duke of Orléans
- He was the son of Marie Amalie of Bourbon-Sicilies
- He was an admiral of the French Navy
- He was a talented artist
- By birth in the UK or a qualified British Overseas Territory to a parent who is a British citizen at the time of the birth, one can obtain British nationality.
- By birth in the UK or a qualified British Overseas Territory to a parent who is settled in the UK or that Overseas Territory, one can obtain British nationality.
- British citizenship by descent is only transferable to one generation down from the parent who is a British citizen otherwise than by descent, if the child is born abroad.
- By naturalisation, one can obtain British nationality.
- By registration, one can obtain British nationality.
- By adoption, one can obtain British nationality.
- British nationality can be obtained by birth abroad, which constitutes ``by descent
- By birth abroad, which constitutes ``by descent
- Lex sanguinis: By birth abroad, which constitutes ``by descent ''if one of the parents is a British citizen otherwise than by descent (for example by birth, adoption, registration or naturalisation in the UK).
- Lex soli: By birth in the UK or a qualified British Overseas Territory to a parent who is a British
- Edward Malet came from a family of diplomats.
- Edward Malet's father was Sir Alexander Malet, British minister to Württemberg and later to the German Confederation.
- Edward Malet attended Eton College for three years.
- Edward Malet entered the foreign service at the age of 17.
- Buckingham Palace is the London residence and administrative headquarters of the reigning monarch of the United Kingdom.
- Buckingham Palace is located in the City of Westminster.
- Buckingham Palace is often at the centre of state occasions and royal hospitality.
- Buckingham Palace has been a focal point for the British people at times of national rejoicing and mourning.
- The pronunciation of Buckingham Palace is / ˈbʌkɪŋəm ˈpælɪs /.
- Buckingham Palace is the London residence and administrative headquarters of the monarch of the United Kingdom.
- Located in the City of Westminster.
- It is often at the centre of state occasions and royal hospitality.
- It has been a focal point for the British people at times of national rejoicing and mourning.
- The issuance of birth certificates in the U.S. is a function of the Vital Records Office of the states, capital district, territories and former territories.
- Birth in the U.S. establishes automatic eligibility for American citizenship.
- The U.S. State Department issues a Consular Report of Birth Abroad for children born to U.S. citizens.
- Births on military bases in foreign territory are included in the Consular Report of Birth Abroad.
- Anselm Tupper was born in Easton, Massachusetts.
- Anselm Tupper was born on October 11, 1763.
- Anselm Tupper grew up in Chesterfield, western Massachusetts.
- Anselm Tupper enlisted in May 1775.
- Anselm Tupper enlisted at the age of eleven.
- Anselm Tupper joined Captain Robert West's Chesterfield company.
- Anselm Tupper was assigned to Colonel John Fellows' regiment (17th Massachusetts Bay Provincial Regiment).
- Anselm Tupper's father, Benjamin Tupper, was already major in the regiment.
- Cornelius Clifford places his birth no earlier than 296 and no later than 298.
- Athanasius indicates no first hand recollection of the Maximian persecution of 303.
- The Arians accused Athanasius of not having yet attained the canonical age (30).
- Athanasius could not have been properly ordained as Patriarch of Alexandria in 328.
- The Orthodox Church places his year of birth around 297.
- A birth certificate from a local authority is commonly provided to the federal government to obtain a U.S. passport
- The issuance of birth certificates is a function of the Vital Records Office of the states, capital district, territories and former territories.
- The U.S. State Department does issue a Consular Report of Birth Abroad for children born to U.S. citizens.
- A birth certificate from a local authority is commonly provided to the federal government to obtain a U.S. passport
- The issuance of birth certificates is a function of the Vital Records Office of the states, capital district, territories and former territories.
- The U.S. State Department does issue a Consular Report of Birth Abroad for children born

# Eetookashoo Bay Waterway

- Eetookashoo Bay is a waterway in Qikiqtaaluk Region, Nunavut, Canada.
- It is located at the northern end of Axel Heiberg Island.
- It is located between Cape Thomas Hubbard and Cape Stallworthy.
- The bay is named in honor of Eetookashoo ("Itukassuk").
- Eetookashoo ("Itukassuk") had traveled with Frederick Cook.
- Eetookashoo ("Itukassuk") had traveled with Donald Baxter MacMillan.

# Elisabeth Luther

Elisabeth Luther
- Elisabeth Luther was the first daughter and second child born to Martin Luther and Katharina von Bora.
- She did not survive infancy.
- He was educated at Luther Theological Seminary (in Saint Paul, Minnesota).
- He was educated at Princeton University.
- He was educated at the University of Tübingen in Germany.
- He served as a pastor in Mason City, Iowa.
- He joined the faculty of Luther Theological Seminary as professor of New Testament.
- Young Man Luther: A Study in Psychoanalysis and History is a 1958 book by psychologist Erik Erikson.
- It was one of the first psychobiographies of a famous historical figure.
- Erikson found in Martin Luther a good model of his discovery of "the identity crisis".
- Erikson was sure he could explain Luther's spontaneous eruption, during a monastery choir practice, "I am not!".
- Dexter Scott King was born January 30, 1961.
- He is the second son of Martin Luther King Jr. and Coretta Scott King.
- He is the brother of Martin Luther King III, Bernice King, and Yolanda King.
- Erikson's stages of psychosocial development is a comprehensive psychoanalytic theory.
- Erikson articulated it in collaboration with Joan Erikson.
- It identifies a series of eight stages that a healthy developing individual should pass through from infancy to late adulthood.

# Elk Ridge, Maryland

Elk Ridge is a mountain ridge
Elk Ridge is part of the Blue Ridge Mountains
Elk Ridge is located west of South Mountain
Elk Ridge runs roughly parallel to South Mountain
Elk Ridge runs from Rohrersville in the north
Elk Ridge runs to the Potomac River across from Harpers Ferry, West Virginia, in the south
The ridge continues as Blue Ridge Mountain in Virginia and West Virginia
The southern end of the ridge is known as Maryland Heights
Maryland Heights is part of Harpers Ferry National Historical Park

# English Middle Ages Conflicts

England in the Middle Ages
- Richard focused on protecting his possessions in France.
- Richard fought in the Third Crusade.
- John inherited England in 1199.
- John lost Normandy and most of Aquitaine after years of war with France.
- John fought campaigns to regain lost possessions.
- John's efforts to raise revenues led to confrontation with English barons.
- In 1215, the Magna Carta was signed to restore peace.
- John died having fought the rebel barons and their French backers to a stalemate.
- Royal power was re-established by barons loyal to Henry III.
- England's power structures remained unstable.
- The Second Barons' War broke out in 1264.
- Simon de Montfort captured the king.
- Edward defeated rebel factions between 1265 and 1267.
- Edward restored his father to power.
- Martin Luther separated the religious and the worldly realms in principle.
- Believers were obliged to use reason to govern the worldly sphere in an orderly and peaceful way.
- Luther's doctrine of the priesthood of all believers upgraded the role of laymen in the church considerably.
- Members of a congregation had the right to elect a minister.
- Members of a congregation had the right to vote for his dismissal.
- Calvin strengthened the role of laymen in the church.
- Calvin included elected laymen (church elders, presbyters) in his representative church government.
- The Huguenots added regional synods and a national synod to Calvin's system of church self-government.
- This system

# Equity Music Group

Equity Music Group
- Equity Music Group was an American country music record label
- Equity Music Group was founded in 2003
- Equity Music Group was founded by Clint Black
- The label was distributed by Koch Entertainment
- Koch Entertainment is now E1 Entertainment
- Tim DuBois was born May 4, 1948 in Southwest City, Missouri
- Tim DuBois is Nashville, Tennessee-based
- Tim DuBois attended Oklahoma State University
- Tim DuBois received a B.A. and M.A. in Accounting
- Tim DuBois was awarded an honorary PHD in Accounting in 2016
- Tim DuBois has been recognized for numerous honors and awards for his contributions to the music industry
- Tim DuBois has taken part in multiple aspects of the industry including songwriting, record labels, management, and production
- Dubois (also spelled DuBois or Du Bois, from the French "of the woods/forest") is a surname.
- Notable people with the surname include:
- "When I Call Your Name" is a song co-written and recorded by Vince Gill.
- "When I Call Your Name" was released in May 1990.
- "When I Call Your Name" reached number 2 on the Billboard Hot Country Singles & Tracks chart.
- "When I Call Your Name" was written by Vince Gill and Tim DuBois.
- Patty Loveless performed backing vocals on the song.
- Barry Beckett played piano on the track.
- The Common Linnets performed a cover of the song.
- The Common Linnets performed a cover of the song to celebrate 50 years of the CMA Awards.
- "Take It All Back " is a song written and recorded by Judah & the Lion.
- "Take It All Back " is a song from their second studio album Folk Hop N 'Roll.
- "Take It All Back " was released as a single.
- Cletus the Van Records released "Take It All Back ".
- Cletus the Van Records is the band's label.
- Go Down Records is an independent record label
- Go Down Records is based in Savignano sul Rubicone, Italy
- It was founded by Leonardo Cola
- It was founded by Max Ear
- Leonardo Cola and Max Ear are part of the Italian band OJM.
- Immanu El started as a musical experiment in 2004.
- Immanu El was started by Claes Strängberg.
- Claes Strängberg was 16 years old when Immanu El started.
- Claes Strängberg was soon joined by his twin brother Per.
- Immanu El was joined by David Lillberg.
- Immanu El was joined by Jonatan Josefsson.
- Immanu El performed supporting Logh.
- Immanu El performed supporting Loney, Dear.
- Immanu El was booked to perform at Rookiefestivalen in Hultsfred.
- Rookiefestivalen in Hultsfred was hosted by Hultsfred

# Erin Pitt Biography

Erin Pitt
- Erin Pitt was born in Hamilton, Ontario
- Erin Pitt is one of six siblings
- Erin Pitt has two sisters
- Erin Pitt has three brothers
- Erin Pitt has attended the Hamilton Academy of Performing Arts
- Erin Pitt studies acting
- Erin Pitt studies singing
- Erin Pitt studies dancing
- Erin Pitt has performed with the Hamilton City Ballet

# Essex County Park Building

- The Essex County Park Commission Administration Building is located in Newark, Essex County, New Jersey, United States.
- The building was built in 1916.
- The building was added to the National Register of Historic Places on November 11, 1977.
- The James W. Clise House is a house located within Marymoor Park.
- The James W. Clise House is located in Redmond, Washington, United States.
- The James W. Clise House is listed on the National Register of Historic Places.
- The Mountrail County Courthouse was built in 1914.
- The Mountrail County Courthouse is located in Stanley, North Dakota.
- The Mountrail County Courthouse served Mountrail County as its courthouse continuously since 1914.
- The Mountrail County Courthouse was designed by architects Buechner & Orth.
- The Mountrail County Courthouse is an example of Academic Revival architecture.
- The Mountrail County Courthouse is an example of Late 19th and 20th Century Revivals architecture.
- The Mountrail County Courthouse was listed on the National Register of Historic Places in 1978.
- A area was included in the listing for the Mountrail County Courthouse.

# Ex on the Beach (Series 7)

Ex on the Beach (British TV series)
- The seventh series began on 20 June 2017.
- The seventh series was filmed on the island of Bali in Indonesia.
- The series was confirmed on 26 February 2017.
- The cast members were confirmed on 23 May 2017.
- Chloe Ferry was in the cast.
- Marty McKenna was in the cast.
- Max Morley was in the cast.
- Josh Ritchie was in the cast.
- Savannah Kemplay was in the cast.
- Marty appeared in the third series of the show.
- Josh appeared in the sixth series of the show.

# Executionist Movement

Szlachta
- The "executionist movement" began to take form about that time.
- The "executionist movement" is also known as "egzekucja praw" in Polish.
- "Egzekucja praw" means "execution of the laws" in Polish.
- Members of the "executionist movement" sought to curb the power of the magnates at the Sejm.
- Members of the "executionist movement" sought to strengthen the power of king and country.
- In 1562, the "executionist movement" forced the magnates to return leased crown lands to the king.
- In 1562, the "executionist movement" forced the king to create a standing army (wojsko kwarciane).
- Jan Zamoyski was a member of the "executionist movement."
- The "executionist movement" lost its political force after Jan Zamoyski's
- The Constitutional Movement was a right wing political group in the United Kingdom.
- It was formed in 1979 by Andrew Fountaine.
- It was originally the National Front Constitutional Movement, a splinter group from the National Front.
- It offered a more moderate alternative to the National Front.
- It claimed to have 2000 members by 1980.
- Blair was born in Holley, New York.
- In 1839, Blair's family moved to LaSalle County, Illinois.
- In 1851, Blair encountered missionaries from the Latter Day Saint movement.
- On October 8, 1851, Blair was baptized by William Smith.
- William Smith was the younger brother of Joseph Smith.
- Joseph Smith was the founder of the Latter Day Saint movement.
- Chengara Surendran was born on 31 January 1968.
- Chengara Surendran is a member of the 14th Lok Sabha of India.
- Chengara Surendran represented the Adoor constituency of Kerala.
- Chengara Surendran is a member of the Communist Party of India (CPI) political party.

# Father of the Nation Title

Father of the Nation
- "Father of the nation" was a title used by leaders in postcolonial Africa.
- Leaders used the title to refer to their role in the independence movement.
- Leaders used the title as a source of legitimacy.
- Leaders used paternalist symbolism as a source of continued popularity.
- Joseph Stalin was bestowed with the title "Father of Nations" in 1949.
- Stalin was given the title for his establishment of "people's democracies".
- The title "Father of the Nation" is sometimes politically contested.
- The 1972 Constitution of Bangladesh declared Sheikh Mujibur Rahman to be "father of the nation".
- The BNP government removed the declaration in 2004.
- Sheikh Hasina led the Awami League, which protested the removal.
- A motion to proclaim Andrej Hlinka "father of the nation" failed in Slovakia in September 200
- André Duchesne was a French geographer and historian.
- André Duchesne (sometimes spelled "Du Chesne", Latinized "Andreas Chesneus", "Andreas Quercetanus", or "Andreas Querneus").
- André Duchesne (May 1584 – May 30, 1640).
- André Duchesne is generally styled the father of French history.
- There is no formal provision that recipients of the Bharat Ratna should be Indian citizens.
- Mother Teresa was awarded the Bharat Ratna in 1980.
- Khan Abdul Ghaffar Khan of Pakistan was awarded the Bharat Ratna in 1987.
- Nelson Mandela, the former South African president, was awarded the Bharat Ratna in 1990.
- Sachin Tendulkar became the youngest person and first athlete to receive the honour.
- Dhondo Keshav Karve was awarded on his 100th birthday in a special ceremony on 18 April 1958.
- As of 2015, the award has been conferred upon

# File Time Stamps and Time Zones

Daylight Saving Time
- The text mentions Daylight Saving Time in relation to seasonal time.

# Fizeau–Foucault apparatus

- Fizeau–Foucault apparatus is used to measure the speed of light.
- The term refers to two types of instrument.
- Hippolyte Fizeau and Léon Foucault were friends and collaborators.
- Fizeau and Foucault used the Daguerreotype process to take images of the Sun between 1843 and 1845.
- Fizeau and Foucault characterized absorption bands in the infrared spectrum of sunlight in 1847.

# Fonejacker Comedy Programme

Fonejacker
- Fonejacker is a British comedy programme.
- It is broadcast on E4.
- It features prank calls.
- The prank calls involve a number of different characters.
- The characters are performed by Kayvan Novak.
- Kayvan Novak is a British Iranian television actor.
- It first appeared in May 2006.
- It became a full series in 2007.
- Frank TV was an American sketch comedy show.
- It starred Frank Caliendo, Mike MacRae, and Freddy Lockhart.
- Frank Caliendo hosted the show.
- Frank Caliendo performed in sketches in full makeup as characters he impersonated.

# Foolin' Myself (album)

Foolin' Myself
- It is an album of trio performances.
- Jaki Byard is the pianist.
- It was recorded in 1988.
- It was released on the Italian Soul Note label.
- It is the 20th studio album by American jazz musician Joe Lovano.
- It was released on the Blue Note label.
- It was released in 2006.
- It features a five-part "Streams of Expression Suite."
- It features a three-part "Birth of the Cool Suite."
- It features three other shorter works.
- The "Birth of the Cool Suite" was conducted by Gunther Schuller.
- The "Birth of the Cool Suite" utilizes melodic themes inspired by Miles Davis' work from his 1948 and 1950 nonet.
- It features George Garzone.
- It features Ralph

# Fort Mitchell, Kentucky

Fort Mitchell, Kentucky
- Fort Mitchell is a home rule-class city
- Fort Mitchell is in Kenton County, Kentucky
- Fort Mitchell is in the United States
- The population of Fort Mitchell was 8,207 at the 2010 census
- Snappy Tomato Pizza is a pizza chain that started in Fort Mitchell, Kentucky
- The chain has over 60 locations nationwide
- Its headquarters are in Burlington, Kentucky
- The chain specializes in pizza, but also serves calzones, hoagies, salads, pasta, dessert and appetizers

# Fox River Escapees

Prison Break Season 2
- The season begins eight hours after the escape.
- Paul Scheuring describes the second season as "The Fugitive times eight."
- The season is likened to the "second half of The Great Escape."
- The eight escapees split up and journey across the country.
- Brad Bellick gets fired from the prison.
- Brad Bellick chases after the inmates for the reward money.
- Charles Westmoreland buried a large cache of money long ago.
- Alexander Mahone is assigned to track down the eight fugitives.
- Alexander Mahone is working for The Company.
- The Company wants all eight men dead.
- Governor Frank Tancredi has been killed.
- Sara remains with Michael.
- The brothers try to bring down now-President Reynolds.
- Sara allows herself to be arrested and faces trial.
- Paul Kellerman's testimony exonerates Lincoln and Sara.
- Half of

# François Pillet, Senator

François Pillet
- François Pillet was born on 13 May 1950.
- François Pillet is a member of the Senate of France.
- François Pillet represents the Cher department.
- François Pillet is a member of the Union for a Popular Movement.
- Le calife de Bagdad ("The Caliph of Baghdad") is an "opéra comique" in one act by François-Adrien Boieldieu.
- Claude Godard d'Aucourt de Saint-Just wrote the libretto for Le calife de Bagdad.
- Le calife de Bagdad was first performed at the Opéra-Comique, Paris on 16 September 1800.
- Le calife de Bagdad became highly popular throughout Europe.
- It was Boieldieu's first major triumph.
- Luigi Cherubini reproached Boieldieu, "Aren't you ashamed of such a great success,
- "Un jour, un enfant" is one of four winning songs in the Eurovision Song Contest 1969.
- Frida Boccara sang "Un jour, un enfant" in French.
- Frida Boccara represented France with "Un jour, un enfant".
- Salomé represented Spain with "Vivo cantando".
- Lulu represented the United Kingdom with "Boom Bang-a-Bang".
- Lenny Kuhr represented the Netherlands with "De troubadour".
- Jean-Michel Boucheron was born on December 15, 1946 in Angoulême, Charente.
- Jean-Michel Boucheron is a French politician.
- Jean-Michel Boucheron was a member of the National Assembly of France (1978-1988).
- Jean-Michel Boucheron was mayor of Angoulême.
- Jean-Michel Boucheron was briefly Secretary of State for Local Authorities.
- Jean-Michel Boucheron represented a portion of the Charente department in the Assembly.
- Jean-Michel Boucheron is a member of the Socialist Party.

# Full Cooperation (song)

Full Cooperation is a song by Def Squad
Def Squad is an American hip hop group
"El Niño" is an album
"El Niño" was released in 1998
"Full Cooperation" was released on April 14, 1998
"Full Cooperation" was released in promotion of "El Niño"
"Full Cooperation" is the only single from "El Niño"

# Full-Time Employment

Full-time employment
- Full-time employment is employment in which a person works a minimum number of hours defined by their employer.
- Full-time employment often comes with benefits like annual leave, sick leave, and health insurance.
- Some mistakenly think part-time jobs are not careers.
- Legislation exists to stop employers from discriminating against part-time workers.
- Full-time jobs generally pay more than part-time jobs per hour.
- The Fair Labor Standards Act (FLSA) does not define full-time or part-time employment.
- The definition of full-time employment is generally determined by the employer.
- Employers generally require 35 to 40 hours per week to be defined as full-time.
- Full-time employees are eligible for benefits.
- Part-time jobs are mistakenly thought by some to not be careers.
- They generally pay more than part-time jobs per hour.
- This is similarly discriminatory if the pay decision is based on part-time status as a primary factor.
- The definition by employer can vary and is generally published in a company's Employee Handbook.
- Companies commonly require from 35 to 40 hours per week to be defined as full-time and therefore eligible for benefits.

# Fuori corso sitcom

Fuori corso
- Fuori corso was an Italian sitcom
- It was written by Vincenzo Coppola
- It was written by Ciro Ceruti
- It was written by Ciro Villano
- Ciro Ceruti and Ciro Villano starred in the comedy.

# Gallaratese, Milan District

- Gallaratese is a district of Milan, Italy.
- Gallaratese is part of the Zone 8 administrative division.
- It is located 7 km north-west of the city centre.
- It borders on the "comune" of Pero to the north.
- It borders on the district of Trenno to the west.
- It borders on the district of Lampugnano to the south.
- Its ideal border to the east is the eponymous street.
- The eponymous street is named after Gallarate.
- The eponymous street leads to the town of Gallarate.
- Menteng is an administrative village.
- Menteng is located in the Menteng district of Indonesia.
- It has a postal code of 10310.
- It is located on the southern area of the Menteng Project.

# GeminiJets Model Airplanes

GeminiJets
- GeminiJets is a diecast model airplane manufacturer
- GeminiJets is based in Las Vegas, Nevada, United States
- GeminiJets was founded in 1998
- GeminiJets was originally named SkyJets
- ADI (Airliners Distributing Inc.) is the founding company
- ADI holds production licenses from Boeing
- ADI holds production licenses from Airbus
- ADI holds production licenses from McDonnell Douglas
- ADI holds production licenses from Embraer
- ADI makes and markets aircraft in several different scales

# General Electric Headquarters

GE
- GE is a multinational conglomerate.
- GE is headquartered in Fairfield, Connecticut.
- GE's main offices are located at 30 Rockefeller Plaza at Rockefeller Center in New York City.
- 30 Rockefeller Plaza at Rockefeller Center is known as the Comcast Building.
- The building was formerly known as the GE Building.
- The GE Building had a prominent GE logo on the roof.
- NBC's headquarters and main studios are located in the building.
- GE has been associated with the center through its RCA subsidiary.
- GE moved its corporate headquarters from the GE Building on Lexington Avenue to Fairfield in 1974.
- The EMD E6 was a passenger train locomotive.
- The EMD E6 was manufactured by Electro-Motive Corporation.
- The EMD E6 was manufactured by General Motors Electro-Motive Division.
- The EMD E6 was manufactured in La Grange, Illinois.
- The cab version, E6A, was manufactured from November 1939 to September 1942.
- 91 E6A locomotives were produced.
- The booster version, E6B, was manufactured from April 1940 to February 1942.
- 26 E6B locomotives were produced.
- The E6 was the seventh model in
- Thomas Baring was known as "Tom".
- Thomas Baring was the tenth child of Henry Baring of Cromer Hall.
- Thomas Baring was the fifth of his father's second marriage.
- Thomas Baring was a younger full brother of Edward Baring, 1st Baron Revelstoke.
- Thomas Baring began his career in the Liverpool office of Barings Bank.
- Thomas Baring moved to New York City to join Kidder Peabody.
- In 1890, Kidder Peabody split its dual Boston-New York firm.
- Baring became a partner in the separated New York firm.
- Baring and George C. Magoun formed Baring, Mag
- GE has been associated with the center since its construction in the 1930s.

# Giovanni Cifolelli

Giovanni Cifolelli
- Giovanni Cifolelli was an Italian mandolin virtuoso and dramatic composer.
- The date and place of Giovanni Cifolelli’s birth are unknown.
- In 1764, Giovanni Cifolelli appeared in Paris as a mandolin virtuoso.
- Giovanni Cifolelli was highly esteemed as a performer.
- Giovanni Cifolelli was highly esteemed as a teacher.
- Giovanni Cifolelli published his "Method for the mandolin" while residing in Paris.
- Giovanni Cifolelli’s "Method for the mandolin" met with great success throughout France.
- Giovanni Cifolelli’s "Method for the mandolin" was the most popular of its period.
- His date and place of birth are unknown.
- He made his appearance in Paris in 1764.
- He was highly esteemed, both as a performer and teacher.
- He published his "Method for the mandolin" while residing in Paris.
- His "Method for the mandolin" met with great success throughout France.
- His "Method for the mandolin" was the most popular of its period.
- Suso Cecchi D'Amico was born on 21 July 1914 in Rome.
- Suso Cecchi D'Amico died on 31 July 2010 in Rome.
- Suso Cecchi D'Amico won the 1980 David di Donatello Award for lifetime career.
- Suso Cecchi D'Amico was an Italian screenwriter and actress.
- Suso Cecchi D'Amico worked with virtually all of the most celebrated post-war Italian film directors.
- Suso Cecchi D'Amico wrote or co-wrote many award winning films.

# Glénan Islands Archipelago

- The Glénan islands are an archipelago.
- The Glénan islands are located off the coast of France.
- They are located in the south of Finistère.
- They are near Concarneau.
- They are near Fouesnant.
- The Glénan islands comprise nine major islands.
- The nine major islands are Saint-Nicolas, the Loc'h, Penfret, Cigogne, Drenec, Bananec, Brunec, Guiriden and Guéotec.
- There are over a dozen smaller islets.
- Quignénec is a smaller islet.
- Brilimec is a smaller islet.
- Kastell Bargain is a smaller islet.
- Île aux Moutons is considered to be a part of the archipelago.
- The islands belong to the commune of Fouesnant.

# Glittertind - Landkjenning Album

Landkjenning
- It is the second full-length album by the Norwegian folk rock band Glittertind.
- It was released on May 27, 2009.
- It was released through Napalm Records.
- All instruments and vocals were done by Torbjørn Sandvik and Geirmund Simonsen.
- Erlend Viken played Harding fiddle.
- Stefan Theofilakis played flutes.
- Kaja Fjellberg Pettersen played cello.
- Kris Verwimp did the cover-artwork.
- Julien Riesen did the cover-layout.

# Global Allele Distributions

- Coop et al. (2009) found a selected allele that differentiates the French from the Yoruba and Han
- The selected allele could be strongly clinal across Europe
- The selected allele could be at high frequency in Europe and absent elsewhere
- The global geographic distributions of putatively selected alleles are largely determined by their frequencies in Yoruba, French and Han
- The global distributions fall into three major geographic patterns
- The three geographic patterns are non-African sweeps
- The three geographic patterns are west Eurasian sweeps
- The three geographic patterns are East Asian sweeps

# Gmina Włodawa

Gmina Włodawa
- Gmina Włodawa is a rural gmina
- Gmina Włodawa is in Włodawa County
- Gmina Włodawa is in Lublin Voivodeship
- Gmina Włodawa is in eastern Poland
- Gmina Włodawa is on the border with Belarus
- Gmina Włodawa is on the border with Ukraine
- The seat of Gmina Włodawa is the town of Włodawa
- The town of Włodawa is not part of the territory of the gmina.
- The seat of Gmina Włodawa is the town of Włodawa, although the town is not part of the territory of the gmina.
- Kis-Küküllő was an administrative county of the Kingdom of Hungary.
- Kis-Küküllő is in central Romania.
- Kis-Küküllő is in central Transylvania.
- Kis-Küküllő is the Hungarian name for the Târnava Mică River.
- The capital of the county was "Dicsőszentmárton" (now Târnăveni).
- Gmina Włodawa is a rural gmina (administrative district)
- Its seat is the town of Włodawa, although the town is not part of the territory of the gmina.

# Grant Green - Grant's First Stand

Grant's First Stand is an album.
Grant Green is an American jazz guitarist.
Grant Green performs on the album.
The album was released in 1961.
The album was released on the Blue Note label.
Earlier recordings by Grant Green were released as "First Session" in 2001.
- Jazz Contemporary is an album by American jazz trumpeter Kenny Dorham.
- The album was recorded in 1960.
- The album was released on the Time label.
- The album features the recording debut of pianist Steve Kuhn.

# Grant Green's Gooden's Corner

Gooden's Corner
- It is an album by Grant Green.
- It is by American jazz guitarist Grant Green.
- The album was recorded in 1961.
- It was released on the Japanese Blue Note label.
- It was released in 1980.
- The tracks were released in 1997.
- The tracks were released as part of "The Complete Quartets with Sonny Clark".

# Grant Green - The Latin Bit

The Latin Bit
- It is an album by Grant Green
- It was released on the Blue Note label
- It was recorded in 1962
- It is inspired by Latin American music
- It is a loose concept album
- It is an album by Dewey Redman
- It was recorded in 1978
- It was released on the Galaxy label
- It is by an American jazz saxophonist
- More Blues and the Abstract Truth is an album by Oliver Nelson
- More Blues and the Abstract Truth is an album by an American jazz composer
- More Blues and the Abstract Truth is an album by an American jazz conductor
- More Blues and the Abstract Truth is an album by an American jazz arranger
- More Blues and the Abstract Truth was recorded in 1964
- More Blues and the Abstract Truth was released on the Impulse! label
- It's What's Happenin' is an album by Clark Terry
- It's What's Happenin' is an album by an American jazz trumpeter
- It's What's Happenin' was recorded in 1967
- It's What's Happenin' was released on the Impulse! label
- It was remastered in 2012
- It was reissued to commemorate the 50th anniversary of Impulse! Records
- It was reissued together with "The Happy Horns of Clark Terry"
- "The Happy Horns of Clark Terry" is a solo leader record by Clark Terry
- "The Happy Horns of Clark Terry"
- It was a one-off 1994 Latin supergroup
- It consisted of Ray Barretto
- It consisted of Sheila E.
- It consisted of Tito Puente
- It consisted of Tito Nieves
- It consisted of Paquito D'Rivera
- It consisted of Dave Valentin
- It consisted of Grover Washington, Jr.
- It consisted of Tony Pabon
- It's What's Happenin' is subtitled The Varitone Sound of Clark Terry.
- More Blues and the Abstract Truth features performances.
- More Blues and the Abstract Truth was recorded for the Impulse! label.
- More Blues and the Abstract Truth features Oliver Nelson.
- More Blues and the Abstract Truth is an album by American jazz composer, conductor and arranger Oliver Nelson.

# Grant Green - The Main Attraction

- The Main Attraction is an album.
- The album is by Grant Green.
- Grant Green is an American jazz guitarist.
- The album was recorded in 1976.
- The album was released on the Kudu label.
- Peter Andreas Morén is a Swedish musician.
- He was born on 5 May 1976 in Mora, Sweden.
- He is the guitarist and vocalist of the indie rock trio Peter Bjorn and John.
- He is a founding member of the Stockholm-based artist collective INGRID.
- The Main Attraction is an album by American jazz guitarist Grant Green featuring performances recorded in 1976 and released on the Kudu label.
- The album features performances recorded in 1976.
- The album features performances.
- Soundsigns is an album.
- The album is by the American jazz saxophonist Dewey Redman.
- The album was recorded in 1978.
- The album was released on the Galaxy label.

# Great Value Brand

Great Value
- Products are often claimed to be as good as national brand offerings.
- Products are typically sold at a lower price.
- The lower price is due to lower marketing and advertising expense.
- It is a house or store brand.
- The line does not consist of goods produced by Walmart.
- It is a labeling system for items manufactured and packaged by agricultural and food corporations.
- Corporations that manufacture and package items include ConAgra and Sara Lee.
- Sara Lee also manufactures and brands foods for a variety of other chain stores.
- The labeling system often does not list the location of manufacture.
- Wal-Mart contends that all Great Value products are produced in the United States.
- If a product is not produced in the United States, the country of origin would be listed.

# Green in Ancient Egypt

Green
- Green had very positive associations for the ancient Egyptians.
- The hieroglyph for green represented a growing papyrus sprout.
- Green was connected to vegetation, vigor, and growth.
- The ruler of the underworld, Osiris, was typically portrayed with a green face.
- Green was a symbol of good health and rebirth.
- Palettes of green facial makeup were made with malachite.
- Green makeup was worn by both the living and dead.
- Green makeup was worn around the eyes to protect from evil.
- Tombs contained small green amulets in the shape of scarab beetles.
- Scarab beetles were made of malachite.
- Scarab beetles would protect and give vigor to the deceased.
- The sea was called the "Very Green."
- Animals typically use the color green as camouflage.
- Green animals include amphibians, reptiles, some fish, birds and insects.
- Most fish, reptiles, amphibians, and birds appear green because of a reflection of blue light coming through an over-layer of yellow pigment.
- Broadleaf forests typically have a yellow-green light about them.
- Turacoverdin is a chemical which can cause a green hue in birds.
- Invertebrates such as insects or mollusks often display green colors because of porphyrin pigments.
- This can cause their feces to look green.
- Flavins (lychochromes) and hemanovadin are chemicals which generally contribute to greenness among organisms.
- The Green Party of the United States was founded 17 years ago (2001 - 04).
- The Green Party of the United States split from Greens / Green Party USA.
- The Green Party of the United States is preceded by Citizens Party.
- The headquarters of the Green Party of the United States is 6411 Orchard Avenue, Suite 101, Takoma Park, Maryland 20912.
- The Green Party of the United States publishes a newspaper called Green Pages.
- The Green Party of the United States has a youth wing called Young Greens.
- Native Son is a 1941 Broadway drama.
- Paul Green wrote Native Son.
- Richard Wright wrote Native Son.
- Native Son was based on Wright's novel "Native Son".
- Orson Welles produced Native Son.
- John Houseman produced Native Son.
- Bern Bernard was an associate producer of Native Son.
- John Morcom designed the scenery for Native Son.
- Native Son ran for 114 performances.
- Native Son ran from March 24, 1941 to June 28, 1941.
- Native Son was performed at the St. James Theatre.
- Welles directed Native Son.
- Salix arbuscula is the mountain willow.
- Salix arbuscula is a low, much branched shrub (to 0.7 metres).
- Salix arbuscula has a limited distribution in Northern Europe.
- Salix arbuscula occurs from north Scandinavia eastwards to Siberia.
- In Scotland, Salix arbuscula can be found on damp rocky mountain slopes and ledges.
- In Scotland, Salix arbuscula is generally at altitudes above 600 metres.
- In Scotland, Salix arbuscula is rarely outside Perthshire and Argyll.

# Green Lake, Chisago City

Green Lake (Chisago City, Minnesota)
- Green Lake is in Chisago City, Minnesota.
- Green Lake is in the United States.
- Green Lake is sometimes referred to as "Big Green Lake".
- Little Green Lake is connected to Green Lake by a channel.
- The waters of Green Lake are green.
- The waters of Green Lake are green because of high algae content.

# Greenfield, Indiana City

Greenfield, Indiana
- Greenfield is a city in Hancock County, Indiana.
- Greenfield is the county seat of Hancock County.
- Greenfield is part of the Indianapolis metropolitan area.
- The population was 20,602 at the 2010 census.
- The estimated population in 2016 was 21,709.
- Greenfield lies in Center Township.
- Mark Dismore was born in Greenfield, Indiana.
- Mark Dismore is a former driver in the Indy Racing League.
- Mark Dismore was the 1990 Toyota Pacific champion.
- Mark Dismore won the 1993 24 Hours of Daytona with Dan Gurney's All American Racers.
- Mark Dismore made 3 CART starts in 1991.
- Mark Dismore was badly injured in a practice crash for the Indianapolis 500.
- Mark Dismore suffered a broken neck in the crash.
- Mark Dismore drove for Team Menard in the 1996 Indy 500.

# Hacksaw Blades Dimensions

Hacksaw
- The most common blade is the 12 inch or 300 mm length.
- Hacksaw blades have two holes near the ends for mounting them in the saw frame.
- The 12 inch / 300 mm dimension refers to the center to center distance between these mounting holes.

# Handel's Messiah Structure

- The work has a three-part structure.
- The three parts approximate to Handel's three-act operas.
- Jennens subdivided the parts into scenes.
- Each scene is a collection of individual numbers or movements.
- Movements take the form of recitatives, arias and choruses.
- There are two instrumental numbers.
- The opening Sinfony is in the style of a French overture.
- The pastoral Pifa is often called the pastoral symphony.
- The pastoral Pifa is at the mid-point of Part I.

# Hannibal's Invasion of Rome

Hannibal is a 1995 novel by Ross Leckie.
The novel is about Hannibal's invasion of Rome beginning in 218 BC.
The story is narrated by Hannibal in his retirement.
It is the first book in the "Carthage" trilogy.
The trilogy covers the Punic Wars.
The novel received mixed reviews.
Reviews criticized the extreme violence in the narrative.
Hannibal is a historical novel.
Hannibal is by a Scottish writer.
- Sempronia (170 BC – after 101 BC) was a Roman noblewoman.
- Sempronia was the sister of Tiberius Gracchus (died 133 BC) and Gaius Gracchus (died 121 BC).
- Sempronia was the wife of a Roman general Scipio Aemilianus.
- Sempronia lived in the Middle and Late Roman Republic.
- Hannibal is an American television series.
- Hannibal is a psychological horror–thriller television series.
- Hannibal was developed by Bryan Fuller for NBC.
- The series is based on characters and elements appearing in Thomas Harris' novels "Red Dragon", "Hannibal" and "Hannibal Rising".
- The series focuses on the relationship between Will Graham and Dr. Hannibal Lecter.
- Will Graham is an FBI special investigator (played by Hugh Dancy).
- Dr. Hannibal Lecter is a forensic psychiatrist (played by Mads Mikkelsen).
- Dr. Hannibal Lecter is destined to become Will Graham's most cunning enemy.
- Dr. Hannibal Lecter is the only person who can understand
- Scipio's father, Publius Scipio, was killed at the Battle of the Upper Baetis in 211 BC.
- Scipio's uncle, Gnaeus Cornelius Scipio Calvus, was killed at the Battle of the Upper Baetis in 211 BC.
- Hasdrubal Barca was Hannibal's brother.
- Hasdrubal was a general of the Carthaginian forces in Hispania.
- Mago was a general of the Carthaginian forces in Hispania.
- Hasdrubal Gisco was a general of the Carthaginian forces in Hispania.
- Scipio was 25 years old when he arrived in Hispania.
- The Punica is a Latin epic poem in seventeen books.
- The Punica is written in dactylic hexameter.
- The Punica was written by Silius Italicus (c. 28 – c. 103 AD).
- The Punica comprises some twelve thousand lines (12,202).
- The Punica's theme is the Second Punic War.
- The Punica focuses on the conflict between Hannibal and Scipio Africanus.
- The Punica was re-discovered in either 1416 or 1417 by Poggio Bracciolini.
- The Punica is the longest surviving Latin poem from antiquity.
- Red Dragon is a 2002 horror film.
- Anthony Hopkins stars as psychiatrist and serial killer Dr. Hannibal Lecter.
- It is a prequel to The Silence of the Lambs (1991) and Hannibal (2001).
- The novel was originally adapted into the film Manhunter (1986).
- The Battle of Cissa was part of the Second Punic War.
- The battle was fought in the fall of 218 BC.
- The battle was fought near the Greek town of Tarraco in north-eastern Iberia.
- Gnaeus Cornelius Scipio Calvus defeated an outnumbered Carthaginian army under Hanno.
- The Romans gained control of the territory north of the Ebro River.
- Hannibal had subdued the territory north of the Ebro River a few months prior in the summer of 218 BC.
- This was the first battle that the Romans had ever fought in Iberia.
- Colonel John ``Hannibal ''Smith is a fictional character.
- Colonel John ``Hannibal ''Smith is one of the four protagonists of the 1980s action - adventure television series The A-Team.
- The producers originally had James Coburn in mind to play the part of Hannibal.
- It eventually ended up going to George Peppard.
- Hannibal Day served as an officer in the regular army before and during the American Civil War.
- Hannibal Day briefly commanded a brigade in the Army of the Potomac.
- Fëanor () is a fictional character from J. R. R. Tolkien's legendarium.
- Fëanor plays an important part in "The Silmarillion".
- He was the eldest son of Finwë, the High King of the Noldor, and his first wife Míriel Serindë.
- Fëanor's mother, Míriel, died shortly after giving birth, having given all her strength and essence to him.
- "For Fëanor was made the mightiest in all parts of body and mind: in valour, in endurance, in beauty, in understanding, in skill, in strength and subtlety alike: of all the Children of Ilúvatar

# Hans Albert Einstein

Hans Albert Einstein
- Hans Albert Einstein was born on May 14, 1904.
- Hans Albert Einstein died on July 26, 1973.
- Hans Albert Einstein was the second child of Albert Einstein and Mileva Marić.
- Hans Albert Einstein was the first son of Albert Einstein and Mileva Marić.
- Hans Albert Einstein was a Swiss-American engineer.
- Hans Albert Einstein was an educator.
- Hans Albert Einstein was a long-time professor of Hydraulic Engineering at the University of California, Berkeley.
- Barry Onouye is a structural engineer.
- Barry Onouye is an author of multiple textbooks on structural engineering and design.
- Barry Onouye is an emeritus faculty member in the Department of Architecture at the University of Washington.

# Hansen's Planar Surveying Problem

Hansen's Problem
- It is a problem in planar surveying.
- It is named after Peter Andreas Hansen.
- Peter Andreas Hansen lived from 1795 to 1874.
- Peter Andreas Hansen worked on the geodetic survey of Denmark.
- There are two known points "A" and "B".
- There are two unknown points "P" and "P".
- An observer measures angles to each of the other three points from "P" and "P".
- The problem is to find the positions of "P" and "P".
- The angles measured are ("α", "β", "α", "β").

# Heartbeat in the Brain Film

Heartbeat in the Brain
- It is a 1970 documentary film.
- It was produced and directed by Amanda Feilding.
- Amanda Feilding is an advocate of trepanation.
- Amanda Feilding was 27 years old at the time.
- She was a student at the time.
- She drilled a hole in her forehead with a dentist's drill.
- The film includes motion studies of Birdie, her pet pigeon.

# Heidelberger RK Rugby Club

- Heidelberger RK is one of two professional rugby clubs in Germany
- SC 1880 Frankfurt is the other professional rugby club in Germany
- Hans-Peter Wild owns a soft drink manufacturing business
- Hans-Peter Wild supported the club's turn to professionalism

# Henry IV and Ambassador

Henry IV Receiving the Spanish Ambassador
- It is a painting in the Troubador style.
- It was painted in 1817.
- The painter was Jean Auguste Dominique Ingres.
- It shows Henry IV of France.
- It shows Marie de Medici.
- It shows Henry IV's children.
- It shows the Spanish ambassador.

# Hinagdanan Cave, Bohol

Hinagdanan Cave
- Hinagdanan Cave is in Dauis
- Hinagdanan Cave is on Panglao Island
- Hinagdanan Cave is in Bohol Province
- Hinagdanan Cave is in the Philippines
- It is a naturally lighted cavern
- It has a deep lagoon
- It has many large stalactites
- It has many large stalagmites

# Hipermercado Géant Location

- Hipermercado Géant is located just outside Montevideo.
- It is located on Giannattasio Avenue.
- Giannattasio Avenue connects Montevideo with Ciudad de la Costa.
- Ciudad de la Costa is the fastest growing area in Uruguay in recent years.
- The surrounding area is not very highly populated.
- It attracts buyers from the east part of Montevideo.
- It attracts buyers from Ciudad de la Costa.
- It is easily accessible by car.
- It has low prices.

# Holley, New York Village

Holley, New York
- Holley is a village in the town of Murray
- Holley is in Orleans County, New York
- The population of Holley was 1,811 at the 2010 census
- Holley is part of the Rochester Metropolitan Statistical Area
- Rochester Community Schools District serves Rochester.
- Rochester Community Schools District serves Oakland Township.
- Rochester Community Schools District serves Rochester Hills.
- Rochester Community Schools District serves parts of Orion Township.
- Rochester Community Schools District serves parts of Auburn Hills.
- Rochester Community Schools District serves parts of Shelby Township.
- Rochester Community Schools District serves parts of Washington Township.
- Rochester Community Schools District serves northeast Oakland County.
- Rochester Community Schools District serves northwest Macomb County.
- The district has upwards of 14,500 students.
- The district has 21 buildings.
- All 21 buildings are located in Rochester Hills and Oakland Township, Michigan.
- The Administration Center is
- Beckwith is a township in eastern Ontario, Canada.
- It is located in Lanark County on the Mississippi River.
- It is located within Canada's National Capital Region.
- County Road 13 runs between the village of Dragsvik in Balestrand municipality and the village of Moskog in Førde municipality.
- County Road 13 is in Sogn og Fjordane county, Norway.
- Until 2010, County Road 13 was part of National Road 13.
- County Road 13 and a short section of County Road 55 are one of eighteen National Tourist Routes in Norway.
- The road crosses the Gaularfjellet mountains.
- Ragnar Søegaard is chairman of Ruter.
- Ruter is the public transport authority for Oslo and Akershus, Norway.
- The Ruter council consists of 7 council members, together with Ragnar Søegaard.
- Ammerud is a part of Grorud Borough in Oslo, Norway
- Ammerud is known for its large Le Corbusier style housing blocks
- The borough administration is located here.
- Corfe Mullen is a village in Dorset, England.
- Corfe Mullen is on the north-western urban fringe of the South East Dorset conurbation.
- Corfe Mullen is part of the rural district of East Dorset.
- The population of Corfe Mullen was 10,133 (2011).
- Corfe Mullen is served by six churches.
- Corfe Mullen is served by five pubs.
- Corfe Mullen is served by five schools.
- Corfe Mullen is served by a library.
- Corfe Mullen is served by various shops and local businesses.
- Corfe Mullen is served by a village hall.
- Corfe Mullen is served by many
- Donje Crniljevo () is a village in Serbia.
- It is situated on the banks of the Tamnava river.
- It is in the Koceljeva municipality.
- It is in the Mačva District of Central Serbia.
- The village had a Serb ethnic majority.
- The population of the village was 981 in 2002.

# Homewood, South Carolina

Homewood, South Carolina
- Homewood is a small unincorporated community
- Homewood is in Horry County, South Carolina
- Homewood is just north of Conway
- Homewood is in the northeastern part of the state
- Homewood is at the junction of South Carolina Highway 319 and U.S. Highway 701
- There is an elementary school in the community
- Many inhabitants make a living from family farms
- They grow tobacco
- They grow corn
- They grow soybeans
- They grow tomatoes

# Hotel Berlin Film

Hotel Berlin
- Hotel Berlin is a drama film.
- It is set in Berlin near the close of World War II.
- It was made by Warner Bros.
- It was made from late 1944 to early 1945.
- It was directed by Peter Godfrey.
- It stars Faye Emerson.
- It stars Helmut Dantine.
- It stars Raymond Massey.
- It stars Andrea King.
- It is based on the novel "Hotel Berlin '43" by Vicki Baum.
- "Hotel Berlin '43" was published in New York in 1944.
- It is a sequel to "Menschen im Hotel".
- "Menschen im Hotel" was adapted to film as "Grand Hotel" (1932).
- Ausente is a 2011 film.
- Ausente is a Spanish-language film.
- It is directed by Marco Berger.
- Marco Berger is an Argentine director.
- Ausente (English translation and title) is "Absent".
- Ausente tackles the notion of sexual abuse of students.
- In Ausente, a young man wants to lure his teacher into a sexual relationship.
- The Hôtel de Soissons was built in Paris, France.
- It was built between 1574 and 1584.
- It was a "hôtel particulier" (grand house).
- It was built for Catherine de' Medici (1519–89).
- The architect was Jean Bullant (1515–78).
- Inju: The Beast in the Shadow is a 2008 film.
- Inju: The Beast in the Shadow (French: Inju, la bête dans l'ombre).
- It is a film by Barbet Schroeder.
- It stars Benoît Magimel.
- It stars Lika Minamoto.
- It was filmed on location in Tokyo.

# Iditarod Awards and Prizes

Iditarod Trail Sled Dog Race
- The ``Golden Harness '' is frequently given to the lead dog or dogs of the winning team.
- The ``Golden Harness '' is decided by a vote of the mushers.
- In 2008, the ``Golden Harness '' was given to Babe.
- Babe was the lead dog of Ramey Smyth.
- Ramey Smyth finished 3rd in the 2008 race.
- Babe was almost 11 years old when she finished the race.
- It was Babe's ninth Iditarod.
- The`` Rookie of the Year'' award is given to the musher who places the best among those finishing their first Iditarod.
- A red lantern signifying perseverance is awarded to the last musher to cross the finish line.
- The total purse for the 2013 race was US $600,000.
- The

# Infante Henrique, Duke of Coimbra

Infante Henrique, Duke of Coimbra
- Infante Henrique was born on 6 November 1949.
- Infante Henrique died on 14 February 2017.
- Infante Henrique was an Infante of Portugal.
- Infante Henrique was a member of the former Portuguese Royal Family.
- Infante Henrique was the youngest son of Duarte Nuno, Duke of Braganza.
- Infante Henrique was the youngest son of Princess Maria Francisca of Orléans-Braganza.
- Infante Henrique was fifth in the line of succession to the former Portuguese throne at the time of his death.
- Duarte Pio, Duke of Braganza is head of the House of Braganza.
- The House of Braganza ruled Portugal until 1910.
- August Philipp, Duke of Schleswig-Holstein-Sonderburg-Beck was born on 11 November 1612.
- August Philipp, Duke of Schleswig-Holstein-Sonderburg-Beck died on 6 May 1675.
- August Philipp, Duke of Schleswig-Holstein-Sonderburg-Beck was a Danish-German prince.
- August Philipp, Duke of Schleswig-Holstein-Sonderburg-Beck was a member of the House of Oldenburg.
- August Philipp, Duke of Schleswig-Holstein-Sonderburg-Beck acquired the estate of Beck in Westfalen in 1646.
- August Philipp, Duke of Schleswig
- Philippe, Duke of Orléans was born on 21 September 1640.
- Philippe, Duke of Orléans died on 9 June 1701.
- Philippe, Duke of Orléans was the younger son of Louis XIII of France and Anne of Austria.
- Philippe, Duke of Orléans's older brother was Louis XIV.
- Philippe was styled Duke of Anjou from birth.
- Philippe became Duke of Orléans upon the death of his uncle Gaston in 1660.
- Philippe received the dukedoms of Valois and Chartres in 1661.
- Following Philippe's victory in battle in 1671, Louis
- Sigrid Sture was the daughter of Svante Stensson Sture and Märta Erikdotter Leijonhufvud.
- Sigrid Sture was the niece of queen Margaret Leijonhufvud.
- Sigrid Sture was the granddaughter of regent Christina Gyllenstierna.
- Sigrid Sture married Ture Pedersson Bielke.
- Sigrid Sture was the mother of Svante Turesson Bielke.
- Sigrid Sture became the royal governor of Stranda hundred after the death of her husband in 1577.
- Sigrid Sture held the position of royal governor of Stranda hundred for over 30 years

# Infruset Premiere Event

Infruset
- The first public performance of "Infruset" was on October 28, 2012.
- The performance was celebrated as a cinema event.
- The event included broadcasts in cinemas and theaters in Sweden, Germany and Switzerland.
- The premiere consisted of two parts.
- One part was a biography of Gustaf Fröding.
- One part was interviews with band members.
- The other part was a live performance of new songs.

# International Children's Prize

International Children's Peace Prize
- The International Children's Peace Prize is awarded annually.
- The prize is awarded to a child.
- The child must have made a significant contribution to advocating children's rights.
- The child must have improved the situation of vulnerable children.
- Vulnerable children include orphans.
- Vulnerable children include child labourers.
- Vulnerable children include children with HIV / AIDS.
- The Programme for International Student Assessment is a worldwide study.
- The study is performed by the Organisation for Economic Co-operation and Development (OECD).
- The study is performed in member and non-member nations.
- The study assesses 15 - year - old school pupils.
- The study assesses scholastic performance on mathematics, science, and reading.
- It was first performed in 2000.
- It is repeated every three years.
- Its aim is to provide comparable data.
- Its aim is to enable countries to improve their education policies and outcomes.
- It measures problem solving and cognition in daily life.
- Julia's House is a children's hospice.
- Julia's House is located in Corfe Mullen, Dorset, England.
- It is a hospice in Dorset for children with life-limiting conditions.
- The majority of the children who are cared for by Julia's House are unlikely to live beyond the age of 18.
- The hospice costs £1.9 million to be maintained.
- Only 3% of this cost is provided by the government.
- Jolene Chin Yeng-Mun is a beauty pageant queen.
- Jolene Chin Yeng-Mun is from Kuala Lumpur, Malaysia.
- Jolene Chin Yeng-Mun is also known as Chan Ying Man, or Chen Ying Wen (Traditional Chinese: 陳影雯).
- She won the title of Miss Astro Chinese International in 2004.
- She received the Miss Friendship Award in 2004.
- She received the Miss Elegance Award in 2004.
- She represented Malaysia at the Miss Chinese International Pageant.
- She won the Miss Chinese International Friendship Award in 2005.
- She can speak English.
- She can

# International Day of the Girl

International Day of the Girl Child
- Also called International Day of the Girl
- Also called Day of Girls
- It is an international day
- Its significance is raising awareness of issues facing girls internationally
- Issues include education
- Issues include nutrition
- Issues include child marriage
- Issues include legal rights
- Issues include medical rights
- It is celebrated annually
- It was first celebrated on 11 October 2012
- The No Child Left Behind Act of 2001 was a U.S. Act of Congress.
- It reauthorized the Elementary and Secondary Education Act.
- It included Title I provisions applying to disadvantaged students.
- It supported standards-based education reform.
- It was based on the premise that setting high standards and establishing measurable goals could improve individual outcomes in education.
- It required states to develop assessments in basic skills.
- To receive federal school funding, states had to give these assessments to all students at select grade levels.
- Type International
- Significance Raise awareness of issues facing girls internationally surrounding education, nutrition, child marriage, legal and medical rights
- Date 11 October
- Frequency annual
- First time 11 October 2012
- Girls tend to be asked by their families to perform more domestic work than boys.
- Girls often perform domestic work at younger ages than boys.
- Employment as a paid domestic worker is the most common form of child labor for girls.
- In East and Southeast Asia, parents often see work as a domestic servant as a good preparation for marriage.
- Domestic service exposes workers to serious risks, such as violence, exploitation and abuse by the employers.
- Girls either stop their education, or are often subjected to a double or triple burden of work.
- This situation is common in parts of Asia and Latin America.

# iPod Manufacturing Conditions

iPods are mainly manufactured by workers who earn no more than US$50 per month
iPods are mainly manufactured by workers who work 15-hour shifts
The Mail on Sunday reported that iPods are mainly manufactured by workers who earn no more than US$50 per month
The Mail on Sunday reported that iPods are mainly manufactured by workers who work 15-hour shifts
Apple investigated the case with independent auditors
Some of the plant's labour practices met Apple's Code of Conduct
Employees worked over 60 hours a week for 35% of the time
Employees worked more than six consecutive days for 25% of the time

# Ippolito de' Medici Portrait

- The Portrait of Ippolito de' Medici is a 1532-33 portrait.
- The portrait is by Titian.
- The portrait is now in the Palazzo Pitti.
- The portrait is of Ippolito de' Medici.
- Giuliano de' Medici was born on 25 March 1453.
- Giuliano de' Medici died on 26 April 1478.
- Giuliano de' Medici was the second son of Piero de' Medici (the Gouty) and Lucrezia Tornabuoni.
- Giuliano de' Medici was co-ruler of Florence, with his brother Lorenzo the Magnificent.
- Giuliano de' Medici complemented his brother's image as the "patron of the arts" with his own image as the handsome, sporting, "golden boy."
- Maria Maddalena de' Medici was a Tuscan princess.
- Maria Maddalena de' Medici was born on 29 June 1600.
- Maria Maddalena de' Medici died on 28 December 1633.
- Maria Maddalena de' Medici was the eighth daughter of Ferdinando I and Christina of Lorraine.
- Maria Maddalena de' Medici was the sister of Cosimo II.
- Nannina de' Medici (born Lucrezia de' Medici) was born on 14 February 1448.
- Nannina de' Medici died on 14 May 1493.
- Nannina de' Medici was the second daughter of Piero di Cosimo de' Medici and Lucrezia Tornabuoni.
- Nannina de' Medici was the elder sister of Lorenzo de' Medici.
- Nannina de' Medici married Bernardo Rucellai.
- Her father's name was Piero, so she is sometimes known as Lucrezia di Piero de' Medici.
- Margherita de' Medici was Duchess of Parma and Piacenza.
- Margherita de' Medici was born on 31 May 1612.
- Margherita de' Medici died on 6 February 1679.
- Margherita de' Medici married Odoardo Farnese, Duke of Parma.
- Margherita was regent of Piacenza in 1635.
- Margherita was regent of the entire duchy from 1646 until 1648.
- Margherita was regent during her son's minority.
- The Age of the Medici was originally released in Italy as L'età di Cosimo de Medici.
- The Age of the Medici is a 1973 3-part TV series.
- The series is about the Renaissance in Florence.
- The series was directed by Roberto Rossellini.
- The series was shot in English.
- The series failed to achieve a North American release.
- The series was later dubbed into Italian.
- The series was shown on state television.
- The films are: "Cosimo de Medici", "The Power of Cosimo" and "Leon Battista Alberti: Humanism".
- It is Fred Ward's debut role.
- Pietro de' Medici was born on 3 June 1554.
- Pietro de' Medici died on 25 April 1604.
- Pietro de' Medici was the youngest son of Cosimo I de' Medici.
- Pietro de' Medici was the son of Eleonora di Toledo.
- Gian Giacomo Medici was the brother of Giovanni Angelo Medici.
- Giovanni Angelo Medici was later to be elected Pope as Pius IV.
- Gian Giacomo Medici and Giovanni Angelo Medici were scions of an impoverished though patrician family of Milan.
- The family was not connected with the Medici of Florence.
- The Medici heraldic "palle" appeared in a contemporary engraving ("illustration").
- Gian Giacomo Medici had the nickname "Il Medeghino", the "little Medici".
- The Medici Fountain is in the Jardin du Luxembourg.
- The Medici Fountain is in the 6th arrondissement in Paris.
- The Medici Fountain was built in about 1630.
- The Medici Fountain was built by Marie de' Medici.
- Marie de' Medici was the widow of King Henry IV of France.
- Marie de' Medici was regent of King Louis XIII of France.
- The Medici Fountain was moved and rebuilt in 1864-66.
- Garzia de' Medici was born on July 5, 1547.
- Garzia de' Medici died on December 6, 1562.
- Garzia de' Medici was the son of Cosimo I de' Medici, Grand Duke of Tuscany.
- Garzia de' Medici was the son of Eleanor of Toledo.
- Garzia de' Medici was the subject of a famous painting by Bronzino when he was an infant.
- Garzia de' Medici died of malaria while traveling to Pisa.
- His brother, Cardinal Giovanni, also died of the disease a few days before him.
- Giulio di Giuliano de' Medici was born on 26 May 1478.
- Giulio di Giuliano de' Medici was head of the Catholic Church.
- Giulio di Giuliano de' Medici was ruler of the Papal States.
- Giulio di Giuliano de' Medici reigned from 19 November 1523 to 25 September 1534.
- Pope Clement VII died on 25 September 1534.
- The Portrait of Carlo de' Medici is a painting by Andrea Mantegna.
- The portrait was executed in 1466.
- The portrait is now housed in the Uffizi Gallery of Florence.
- Giovanni di Bicci de' Medici was born in Florence, Italy.
- He was the son of Averardo de' Medici and Jacopa Spini.
- Averardo de' Medici died in 1363.
- Giovanni and his four brothers inherited a respectable amount of wealth from Averardo.
- Giovanni received very little of the inheritance.
- Vieri de’ Medici was a prominent banker in Florence.
- Vieri helped Giovanni begin his career in the Florentine banking system.
- Giovanni worked as a junior partner in the Rome branch.
- Vieri de’ Medici retired in 1393.
- Giovanni founded the Medici bank in 1397.

# Irish Supreme Court

Supreme Court
- The Supreme Court is the highest court in Ireland.
- It has authority to interpret the constitution.
- It can strike down laws and activities of the state.
- It can find laws and activities of the state to be unconstitutional.
- It is the highest authority in the interpretation of the law.
- Its further appellate jurisdiction from lower courts is defined by law.
- The Irish Supreme Court consists of the Chief Justice and seven other judges.
- Judges of the Supreme Court are appointed by the President.
- Judges of the Supreme Court are appointed in accordance with the binding advice of the Government.
- The Supreme Court sits in the Four Courts in Dublin.

# Italian Eritrea's Industrial Center

Eritrea
- In 1922, Benito Mussolini's rise to power in Italy brought profound changes to the colonial government in Italian Eritrea.
- In May 1936, Benito Mussolini declared the birth of the Italian Empire.
- Italian Eritrea was enlarged with northern Ethiopia's regions.
- Italian Eritrea and Italian Somaliland were merged with Ethiopia.
- The merger created the new Italian East Africa administrative territory.
- The Fascist period was characterized by imperial expansion.
- The Fascist period was in the name of a "new Roman Empire".
- The Italian government chose Eritrea to be the industrial center of Italian East Africa.
- After "il Duce" declared the birth of Italian Empire in May 1936, Italian Eritrea (enlarged with northern Ethiopia's regions) and Italian Somaliland were merged with the just conquered Ethiopia in the new Italian East Africa ("Africa Orientale Italiana") administrative territory.
- This Fascist period was characterized by imperial expansion in the name of a "new Roman Empire".
- Benito Mussolini's rise to power in Italy in 1922 brought profound changes to the colonial government in Eritrea.
- Eritrea was chosen by the Italian government to be the industrial center of Italian East Africa.

# Italy Rugby Union Team

Italy national rugby union team
- Italy has a national rugby union team.
- Italy played Argentina on 24 October 1978, winning 19 - 6 at Stadio Mario Battaglini, Rovigo.
- Italy played Ireland on 6 May 1995, winning 22 - 12 at Stadio Comunale di Monigo, Treviso.
- Argentina played Italy on 4 June 1995, winning 25 - 31 at Buffalo City Stadium, East London, South Africa.
- Ireland played Italy on 4 January 1997, losing 29 - 37 at Lansdowne Road, Dublin.
- France played Italy on 22 March 1997, losing 32 - 40 at Stade Lesdiguières, Grenoble.
- Italy played Ireland on 20 December 1997, winning
- The Stadio San Nicola is located in Bari, Italy.
- The Stadio San Nicola was designed by Renzo Piano.
- The Stadio San Nicola is a multi-use all-seater stadium.
- The stadium resembles a 'flower'.
- The stadium consists of 26 'petals'.
- The upper tiers of the higher ring are separated by 8-metre empty spaces.
- The Stadio San Nicola is the home stadium of F.C. Bari 1908.
- Stadio Arduino Mangoni is a multi-purpose stadium.
- Stadio Arduino Mangoni is located in Isola del Liri, Italy.
- It is mainly used for football matches.
- It hosts the home matches of Isola Liri in Serie D.
- The stadium has a capacity of 3,000 spectators.
- The stadium meets Lega Pro criteria.
- Stadio Ciro Vigorito is a multi-use stadium in Benevento, Italy.
- Stadio Ciro Vigorito was formerly known as Stadio Santa Colomba.
- It is currently used mostly for football matches.
- It is the home stadium of Benevento Calcio.
- The stadium is able to hold 25,000 people.
- The stadium was opened in 1979.
- Carmelo Imbriani was born on 10 February 1976.
- Carmelo Imbriani died on 15 February 2013.
- Carmelo Imbriani was a footballer.
- Carmelo Imbriani was a coach of Benevento in Lega Pro Prima Divisione.
- Stadio Erasmo Iacovone is a multi-use stadium in Taranto, Italy.
- It is the home ground of Taranto Sport.
- The stadium holds 27,584 people.
- Qui studio a voi stadio (QSVS) is a sports talk and debate television program.
- It is produced by Telelombardia.
- It is aired on various affiliated local television channels in Italy.
- It is entirely devoted to Italian Soccer.
- It is particularly focused on Serie A.
- Stadio San Paolo is located in the western suburb of Fuorigrotta in Naples, Italy.
- Stadio San Paolo is the third largest football stadium in Italy after the San Siro and Stadio Olimpico.
- For the 1960 Summer Olympics in Rome, it hosted the football preliminaries.
- It is the home of Napoli.
- The stadium was built in 1959.
- The stadium underwent extensive renovations in 1989 for the 1990 World Cup.
- The present capacity of the San Paolo is 60,240.
- Stadio Antonio Bianco is located in Gallipoli, Italy.
- It is the home ground of Gallipoli Calcio.
- The stadium holds 5,000 people.
- Dean Sampson is an English former professional rugby league footballer.
- Dean Sampson played as a .
- Dean Sampson spent his entire professional career at the Castleford Tigers.
- Dean Sampson made over 400 appearances for Castleford between 1987 and 2005.
- Dean Sampson represented England at international level.
- Dean Sampson represented Great Britain at international level.
- Dean Sampson was selected to go on the 1992 Great Britain Lions tour of Australia and New Zealand.
- René Wenzel was born on 20 April 1960.
- René Wenzel was born in Copenhagen, Denmark.
- René Wenzel is a Danish cycle racing coach.
- René Wenzel works as a consultant.
- René Wenzel was a former coach of USA Cycling's national junior team.
- René Wenzel was a coach of Koege Cykel Ring in Denmark.
- René Wenzel was the first cycling teacher at a sports college in Denmark, the Gentofte Studenter Kursus.
- Villa Foscari is located in Mira, near Venice, northern Italy.
- Villa Foscari is also known as "La Malcontenta".
- The spouse of one of the Foscaris was allegedly locked up in the house.
- The spouse was locked up because she allegedly didn't live up to her conjugal duty.
- Villa Foscari was designed by the Italian architect Andrea Palladio.
- The Dundas Shamrocks Junior Rugby League Football Club was formed in the mid-1960s.
- The club was an attachment to St Patrick's Marist College Dundas' sports auxiliary.
- The club played in the Balmain Junior Rugby League competition.
- The school sports auxiliary ceased to exist in the mid-1990s.
- The club was rechristened the Dundas Shamrocks.
- The club has been a member of the Balmain Junior Rugby League since its inception in the 1960s.
- The club provides teams for age groups from under 6's to A-Grade.
- New Zealand became the first ever Rugby World Cup Champions.
- New Zealand defeated France 29 points to 9 at Eden Park in Auckland.
- France played Australia in one of the semi-finals.
- New Zealand played Wales in one of the semi-finals.
- There were 16 nations in the competition.
- Invitations were sent out to fill remaining places.
- Seven places were automatically filled by the IRFB members.

# Ivanhoe, Sampson County

Ivanhoe, North Carolina
- Ivanhoe is a census-designated place.
- Ivanhoe is in Sampson County, North Carolina.
- Ivanhoe is in the United States.
- The population of Ivanhoe was 311 at the 2000 census.

# Ivo Visković's Political Career

Ivo Visković was a member of the Civic Alliance of Serbia (1990-1996)
Ivo Visković was a member of the Social Democratic Union from 1996 until 2001
Ivo Visković began his diplomatic career in 2001
Ivo Visković was a member of the European Movement in Serbia
Ivo Visković was chairman of the Forum on International Relations from 2006 to 2008

# Jack Wilson - Something Personal

Something Personal
- It is an album by Jack Wilson
- Jack Wilson is an American jazz pianist
- It was recorded in 1967
- It was released on the Blue Note label
- It is an album by jazz trumpeter Freddie Hubbard
- It was recorded in 1971
- It features string arrangements by Don Sebesky
- It was his third album released on Creed Taylor's CTI label
- It features performances by Herbie Hancock
- It features performances by Eric Gale
- It features performances by George Benson
- It features performances by Ron Carter
- It features performances by Jack DeJohnette
- It features performances by Airto Moreira
- It features performances by Richard Wyands
- It is part of a loose trilogy including "Red Clay" and "Straight Life"
- It won a 1972 Grammy Award for "Best Jazz

# Jackie Jackson - Be the One

Be the One is Jackie Jackson's second studio album.
Be the One was released on September 9, 1989.
Paul Jackson, Jr. was a musician on the album.
Jeff Lorber was a musician on the album.
Robert Brookins was a musician on the album.
Gerald Albright was a musician on the album.

# James Redfield

James Redfield
- James Redfield is an American author
- James Redfield is a lecturer
- James Redfield is a screenwriter
- James Redfield is a film producer
- James Redfield is notable for his novel "The Celestine Prophecy"
- Piper Eressea Kerman was born on September 28, 1969
- Piper Kerman is 49 years old
- Piper Kerman was born in Boston, Massachusetts
- Piper Kerman attended Smith College
- Piper Kerman is married to Larry Smith
- Piper Kerman's notable work is "Orange Is the New Black: My Year in a Women's Prison"
- Piper Kerman has a website at piperkerman.com
- Piper Kerman has a website at www.thepipebomb.com
- Ellen Steiber is an American novelist
- Ellen Steiber is an author of books for young readers
- Ellen Steiber wrote books based on "The X-Files"
- Ellen Steiber wrote books based on "Full House"
- William Childress is an American writer
- William Childress is an author
- William Childress is a poet
- William Childress is a photojournalist
- William Childress was born in Hugo, Oklahoma
- William Childress was born on February 5, 1933
- William Childress has received numerous awards, prizes, and accolades for his writing and poetry
- William Childress is regarded as one of the foremost poets of the Korean War by at least two critics
- Theresa Schwegel is an American author of crime fiction.
- Theresa Schwegel was born on July 20, 1975.
- Theresa Schwegel won the Edgar Award for best first novel from the Mystery Writers of America for "Officer Down" in 2006.
- Theresa Schwegel received the Chicago Public Library Foundation's 21st Century Award for achievement in writing by an author with ties to Chicago in 2008.
- He is notable for his novel "The Celestine Prophecy".
- Glenda Goss is an American author
- Glenda Goss is a music historian
- Glenda Goss has special interests in music and culture
- Glenda Goss has special interests in early modernism
- Glenda Goss has special interests in critical editing
- Glenda Goss has special interests in European-American points of cultural contact
- Glenda Goss's most notable work has revolved around the life and works of the Finnish composer, Jean Sibelius.

# Jan Hendrik van den Berg

Jan Hendrik van den Berg
- Jan Hendrik van den Berg was born on June 11, 1914.
- Jan Hendrik van den Berg died on September 22, 2012.
- Jan Hendrik van den Berg was Dutch.
- Jan Hendrik van den Berg was a psychiatrist.
- Jan Hendrik van den Berg worked in phenomenological psychotherapy.
- Jan Hendrik van den Berg worked in metabletics.
- Jan Hendrik van den Berg is the author of "A different existence".
- Jan Hendrik van den Berg is the author of "The changing nature of man".
- Jan Hendrik van den Berg wrote numerous articles.
- Jan Hendrik van den Berg wrote numerous books.
- Jan Hendrik van den Berg was notable for his work in phenomenological psychotherapy (cf. phenomenology).
- Jan Hendrik van den Berg was notable for his work in metabletics, or "psychology of historical change."

# Jason Sampson (MMA)

Jason Sampson
- Jason Sampson was born on February 21, 1982.
- Jason Sampson is an American professional mixed martial artist.
- Jason Sampson currently competes in the flyweight division of Legacy FC.
- Jason Sampson has been a professional competitor since 2009.
- Jason Sampson has previously competed for Bellator.
- Jason Sampson has previously competed for Shark Fights.
- Timothy Wallace Credeur II was born on July 9, 1977.
- Tim Credeur is a retired American mixed martial artist.
- Tim Credeur was a cast member of SpikeTV's "The Ultimate Fighter 7".
- Tim Credeur was defeated by Jesse Taylor in the semi-finals of "The Ultimate Fighter 7".
- Tim Credeur was brought back into the competition following the disqualification of Jesse Taylor.
- Tim Credeur lost to C.B. Dollaway via decision.

# Jean-Christophe Mitterrand Arrest

Jean-Christophe Mitterrand was freed on 11 January 2001.
Danielle Mitterrand posted a bail of 5 million francs (€762,000) to secure his release.
He was indicted again on July 4, 2001.
The charges against him were "complicity of arms traffic".
Magistrates Philippe Courroye and Isabelle Prévost-Desprez handled his case.
Alain Richard, the Socialist Minister of Defence, filed a complaint in January 2001.

# Jean-Michel Oughourlian Biography

Jean-Michel Oughourlian
- Jean-Michel Oughourlian was born on 20 August 1940.
- He was born in Beirut, Lebanon.
- His father was Armenian.
- His father fled the 1915-1922 genocide.
- His mother was Colombian.
- He arrived in France at the age of ten.

# Jean Terrasson, French Priest

- The Great Fire of London occurred in 1666.

# Jennifer Saunders Awards

Jennifer Saunders
- Jennifer Jane Saunders was born on 6 July 1958.
- Jennifer Jane Saunders is an English comedian.
- Jennifer Jane Saunders is an English screenwriter.
- Jennifer Jane Saunders is an English actress.
- Jennifer Saunders has won three BAFTAs.
- Jennifer Saunders has won a BAFTA Fellowship.
- Jennifer Saunders has won an International Emmy Award.
- Jennifer Saunders has won a British Comedy Award.
- Jennifer Saunders has won a Rose d'Or Light Entertainment Festival Award.
- Jennifer Saunders has won two Writers' Guild of Great Britain Awards.
- Jennifer Saunders has won a People's Choice Award.
- Anthony Veiller was born on 23 June 1903.
- Anthony Veiller died on 27 June 1965.
- Anthony Veiller was an American screenwriter.
- Anthony Veiller was an American film producer.
- Anthony Veiller was the son of Bayard Veiller.
- Anthony Veiller was the son of Margaret Wycherly.
- Anthony Veiller wrote for 41 films between 1934 and 1964.
- The role of Katniss Everdeen made Guinness World Records to recognise Lawrence as the highest - grossing action heroine of all time.
- Her reprisal of Mystique in X-Men: Days of Future Past (2014) earned her two People's Choice Awards for Favorite Actress and Favorite Action Movie Actress.
- In 2015, she starred as the eponymous inventor in the biopic Joy.
- In 2015, she won her third Golden Globe Award in the Best Actress -- Motion Picture Comedy or Musical category.
- In 2015, she received another Academy Award for Best Actress nomination.
- She received several awards and nominations for her performances in the other

# Jesse Bennett, Physician

Jesse Bennett
- Jesse Bennett was born on July 10, 1769
- Jesse Bennett died on July 13, 1842
- Jesse Bennett was the first American physician to perform a successful Caesarean section
- Jesse Bennett performed a Caesarean section on his own wife
- Jesse Bennett's wife gave birth to their only child on January 14, 1794
- Benjamin Stillingfleet was born in Wood Norton, Norfolk
- Benjamin Stillingfleet was born in 1702
- Benjamin Stillingfleet's parents were Mary Ann and Edward Stillingfleet
- Edward Stillingfleet was a physician
- Benjamin Stillingfleet was one of four children
- Benjamin Stillingfleet was the only son
- Benjamin Stillingfleet's grandfather died in 1699
- Benjamin Stillingfleet's grandfather left no money to Edward Stillingfleet
- Benjamin Stillingfleet's grandfather disapproved of Edward Stillingfleet's opinions
- Benjamin Stillingfleet's grandfather disapproved of Edward Stillingfleet's marriage
- Robert Guillaume was born Robert Peter Williams
- Robert Guillaume was an American actor
- Robert Guillaume is known for his role as Isaac Jaffe on Sports Night
- Robert Guillaume is known for his role as Benson on the TV series Soap
- Robert Guillaume is known for his role as Benson on the spin- off Benson
- Robert Guillaume voiced the mandrill Rafiki in The Lion King
- Robert Guillaume's career spanned more than 50 years
- Robert Guillaume worked extensively on stage
- Robert Guillaume worked extensively on television
- Robert Guillaume worked extensively on film
- Robert Guillaume was nominated for a Tony Award for his portrayal of Nathan Detroit in Guys and Dolls
- Robert Guillaume won an Emmy Award for
- Nwankwo Kanu was born in Owerri, Nigeria.
- Kanu began his career at Nigerian league club Federation Works.
- Kanu played for Iwuanyanwu Nationale.
- Kanu was signed by Dutch Eredivisie AFC Ajax in 1993 for €207,047.
- Kanu made his Ajax debut the following year.
- Kanu scored 25 goals in 54 appearances for Ajax.
- Kanu came on as a sub in Ajax's 1995 Champions League final win over AC Milan.

# Joan Llimona

Joan Llimona
- Joan Llimona i Bruguera was born in 1860.
- Joan Llimona i Bruguera died in 1926.
- Joan Llimona i Bruguera was a Spanish artist.
- Joan Llimona rose to popularity at the end of the Romantic movement in Europe.
- Joan Llimona was a key contributor to the modernist movement.
- Joan Llimona was born in Barcelona.
- Joan Llimona died in Barcelona.
- Joan Llimona made a lasting impact on the modernist movement in European art during the early 20th century.
- Many of Joan Llimona's works deal with religious scenes and beliefs.
- Joan Llimona's works often communicate controversial religious messages.
- F. A. Forbes was a "nom de plume".
- F. A. Forbes' "nom de plume" was Mother Frances Alice Monica Forbes, RSCJ.
- F. A. Forbes was a member of the Society of the Sacred Heart.
- F. A. Forbes was from Scotland.
- F. A. Forbes (1869–1936).
- F. A. Forbes was a religious author.

# John Deere World Headquarters

John Deere World Headquarters
- It is a complex of four buildings
- It is located on 1,400 acres (5.7 km²) of land
- It is located at One John Deere Place, Moline, Illinois, United States
- It serves as corporate headquarters for John Deere

# John Wilson Murray

The Great Detective
- "The Great Detective" was inspired by John Wilson Murray.
- John Wilson Murray was Canada's first government-appointed detective.
- The series is set in the latter part of the Victorian era.
- Inspector Alistair Cameron was a fictional counterpart of Murray.
- Inspector Cameron was assisted by Dr. Chisholm.
- Dr. Chisholm was a forensic scientist.
- The series was produced on location at Rockwood.
- The series was produced on location at Kleinburg.
- The series was produced on location at Shadow Lake.
- The series was produced in Ontario.
- The series was produced in Victoria.
- The series was produced in areas of downtown Toronto.
- The series was produced at CBC's television Studio 7.

# Joni Mitchell - Little Green

Little Green (song)
- "Little Green" is a song composed and performed by Joni Mitchell.
- It is the third track on her 1971 album "Blue".

# Josh LaBove, Actor

Josh LaBove
- Joshua Labove was born on March 22, 1986.
- Joshua Labove was born in Manhasset, New York.
- He has been credited in TV and film performances as a child actor.
- He was a child actor in the late 1980s.
- He was a child actor in the 1990s.
- Heather Morgan is an American actress and comedian.
- She was a cast member and writer on "The Dana Carvey Show".
- She wrote and performed such notable skits as Jenny and First Ladies as Dogs.
- The skits Jenny and First Ladies as Dogs were called "one of the two or three funniest things on the show" by writer and producer Robert Smigel.
- Morgan wrote, produced and starred in the movie "Bark!".
- "Bark!" was nominated for a Grand Jury Prize at the 2002 Sundance Film Festival.
- She is an alum of The Groundlings.
- Kevin Sussman was born on December 4, 1970.
- He is an American actor.
- He is known for playing Stuart Bloom on the CBS sitcom The Big Bang Theory.
- He is known for playing Walter on the ABC comedy - drama Ugly Betty.
- Starting with the sixth season of The Big Bang Theory, he was promoted to a series regular.

# Julien Dubuque Bridge

- The Julien Dubuque Bridge crosses the Mississippi River.
- It joins the cities of Dubuque, Iowa, and East Dubuque, Illinois.
- The bridge is part of U.S. Route 20 route.
- The Dubuque–Wisconsin Bridge three miles (5 km) north links Dubuque with Wisconsin.
- It is listed in the National Register of Historic Places.

# Karl Moor (Swiss banker)

- Karl Moor was born on 11 December 1852 in Fribourg.
- Karl Moor died on 14 June 1932 in Berlin.
- Karl Moor was a Swiss communist.
- Karl Moor was a channel for German financing of the 19th-century European Bolshevik movement.
- Yosyf Zisels was a member of the Ukrainian Helsinki group (UHG).
- Yosyf Zisels was involved in the samizdat movement.
- Yosyf Zisels was a human rights activist.
- Yosyf Zisels was a prominent activist in the Jewish movement in Ukraine.
- Yosyf Zisels was a political prisoner.
- William Bross Lloyd was born on February 24, 1875.
- William Bross Lloyd died on June 30, 1946.
- William Bross Lloyd was an American attorney.
- William Bross Lloyd was a political activist.
- William Bross Lloyd was the son of Henry Demarest Lloyd and Jessie Bross.
- William Bross Lloyd was the son of William Bross.
- William Bross Lloyd was a founding member of the Communist Labor Party of America.
- William Bross Lloyd was a financial angel of the Communist Labor Party of America.
- William Bross Lloyd was a forerunner of the Communist Party USA.

# Karl Ulrichs' Classification Scheme

- One of the earliest sexual orientation classification schemes was proposed in the 1860s.
- Karl Heinrich Ulrichs proposed the classification scheme in the 1860s.
- Ulrichs published a series of pamphlets privately.
- The classification scheme was meant only to describe males.
- The classification scheme separated males into three basic categories.
- The categories were dionings, urnings and uranodionings.
- An urning can be categorized by degree of effeminacy.
- The categories correspond with the categories of sexual orientation used today.
- The categories are heterosexual, homosexual, and bisexual.
- Ulrichs outlined a set of questions to determine if a man was an urning.
- Ulrichs outlined definitions for each category of his classification scheme.

# Kenny Dorham and Ernie Henry

2 Horns / 2 Rhythm
- It is an album by Kenny Dorham.
- Kenny Dorham is an American jazz trumpeter.
- The album features performances with Ernie Henry.
- The album was recorded in 1957.
- The album was released on the Riverside label.
- It was Ernie Henry's last recording session.
- This was Henry's last recording session.
- Jazz Contemporary is an album by American jazz trumpeter Kenny Dorham.
- The album featuring performances was recorded in 1960.
- The album was released on the Time label.
- The album features the recording debut of pianist Steve Kuhn.

# Kilikiti and Ano

- Tuvalu is a country.
- Kilikiti is a sport played in Tuvalu.
- Kilikiti is similar to cricket.
- Ano is a sport specific to Tuvalu.
- Ano is played with two round balls.
- The balls used for Ano are 12 cm (5 in) in diameter.
- Ano is a localised version of volleyball.
- The balls used for Ano are made from pandanus leaves.
- Team members try to stop the Ano hitting the ground.
- Traditional sports in the late 19th century included foot racing.
- Traditional sports in the late 19th century included lance throwing.
- Traditional sports in the late 19th century included quarterstaff fencing.
- Traditional sports in the late 19th century included wrestling.
- Christian missionaries disapproved of traditional sports.

# Kimbrough Memorial Stadium

Kimbrough Memorial Stadium
- Kimbrough Memorial Stadium is in Canyon, Texas.
- It is owned by Canyon Independent School District.
- It is primarily used for American football.
- It is the home stadium for Canyon High School.
- It is the home stadium for Randall High School.
- It is the former home of West Texas A&M University.
- It holds 20,000 people.
- It was built in 1959.
- It was originally called Buffalo Bowl on Canyon Hill.
- It was renamed Kimbrough Memorial Stadium in 1971.
- It was renamed in honor of Frank Kimbrough.
- Frank Kimbrough was a West Texas State University football coach.
- Frank Kimbrough was a West Texas State University athletic director.
- Historic Broken Bow Memorial Stadium has served as the home of the Broken Bow Savages.
- It was constructed in 1936.
- It was constructed by the National Youth Administration.
- It was constructed as part of the Works Progress Administration.
- Canyon is the county seat of Randall County, Texas.
- The population of Canyon was 13,303 at the 2010 census.
- Canyon is part of the Amarillo, Texas, metropolitan statistical area.
- Canyon is the home of West Texas A&M University.
- Canyon is the home of Panhandle–Plains Historical Museum.
- Canyon is the home of the world-famous outdoor musical drama "Texas".

# Konqueror Web Browser

Konqueror
- It is a free and open-source web browser.
- It is a file manager.
- It provides web access.
- It provides file-viewer functionality.
- It provides functionality for file systems.
- It can access local files.
- It can access files on a remote FTP server.
- It can access files in a disk image.
- It forms a core part of the KDE Software Compilation.
- It was developed by volunteers.
- It can run on most Unix-like operating systems.
- The KDE community licenses and distributes it.
- It is licensed under the GNU General Public License version 2.

# Krešimir Čuljak

Krešimir Čuljak
- Krešimir Čuljak was born on 18 September 1970.
- Krešimir Čuljak was born in Zagreb.
- Krešimir Čuljak is a Croatian rower.
- Krešimir Čuljak won a bronze medal in the eights competition.
- Krešimir Čuljak won the medal at the 2000 Summer Olympics.
- Krešimir Čuljak's teammates included Igor Boraska.
- Krešimir Čuljak's teammates included Nikša Skelin.
- Krešimir Čuljak's teammates included Siniša Skelin.
- Krešimir Čuljak's teammates included Branimir Vujević.
- Krešimir Čuljak's teammates included Tomislav Smoljanović.
- Krešimir Čuljak's teammates included Tihomir Franković.
- Baptiste Gros competed at the 2014 Winter Olympics for France.
- He placed 40th in the qualifying round in the sprint.
- He failed to advance to the knockout stages.

# Kris Benson Career

- Kris Benson was drafted first overall by the Pittsburgh Pirates in 1996.
- Benson had a strong rookie season in 1999.
- Benson had an even stronger season in 2000.
- Benson underwent Tommy John surgery after the 2000 season.
- Benson posted three more good seasons from 2004 to 2006.
- Benson played for the Pittsburgh Pirates, the New York Mets, and the Baltimore Orioles.
- Benson underwent rotator cuff surgery.
- Benson was never again an effective Major League pitcher after rotator cuff surgery.

# KVLY - TV Mast

KVLY - TV mast
- It is 628.8 m (2,063 ft) tall.
- It was built in 1963.
- It is a guyed mast.
- It is used for VHF - UHF transmission.
- It is located in the United States.
- It is located in Blanchard, North Dakota.
- It is the tallest mast in the world.
- Its coordinates are 47 ° 20 ′ 31.85 ''N 97 ° 17 ′ 21.13'' W.

# Kylian Mbappé Facts

Kylian Mbappé
- Kylian Mbappé received the Best Young Player Award at the 2018 FIFA World Cup.
- Kylian Mbappé’s full name is Kylian Mbappé Lottin.
- Kylian Mbappé’s date of birth is 20 December 1998.
- Kylian Mbappé’s age is 19.
- Kylian Mbappé was born in Paris, France.
- Kylian Mbappé’s height is 1.78 m.
- Kylian Mbappé’s height is 5 ft 10 in.
- Kylian Mbappé plays as a forward.
- Kylian Mbappé’s current team is Paris Saint - Germain.
- Kylian Mbappé’s number is 7.
- Kylian Mbappé played for AS Bondy from 20
- The final took place on 15 July.
- The final took place at the Luzhniki Stadium in Moscow.
- France won the match 4 -- 2.
- France claimed their second World Cup title.
- It marked the fourth consecutive title won by a European team.
- Abderrahim Achchakir was born on December 15, 1986.
- Abderrahim Achchakir plays for FAR Rabat.
- Abderrahim Achchakir is a member of the Morocco national team.
- Abderrahim Achchakir was a member of the Morocco national team at the 2013 Africa Cup of Nations in South Africa.

# Lago District, Mozambique

Lago District
- Lago District is a district of Niassa Province
- Lago District is in north-western Mozambique
- The principal town is Metangula
- Lago District is bordered to the west by Lake Nyasa
- Lago District is bordered on the south by Lichinga
- Lago District is bordered on the east by Sanga District
- Lago District shares its northern boundary with Tanzania

# Lago Verde (Queyras)

Lago Verde (Queyras)
- Lago Verde means "green lake" in Italian.
- It is located in Italy.
- It is close to the French border.
- It is located near the Queyras valley.
- Notogawa Station is the only Japan Railway station in Higashiomi.
- Notogawa Station is a rapid stop on the JR Biwako Line.
- The station is located between Omi-Hachiman and Hikone.
- The town shares a small border with Lake Biwa.
- Notogawa Station is located between Omi-Hachiman and Hikone.
- Notogawa Station (Location: N35.179899,E136.165913) is the only Japan Railway station in Higashiomi.
- The station is a rapid stop on the JR Biwako Line.

# Law of Holes Adage

- The adage has been attributed to a number of sources.
- It appeared in print on page six of The Washington Post dated October 25, 1911.
- The Washington Post published it in 1911 as: ``Nor would a wise man, seeing that he was in a hole, go to work and blindly dig it deeper... ''
- It was published in The Bankers Magazine in 1964.
- The Bankers Magazine published it in 1964 as:`` Let me tell you about the law of holes: If you find yourself in a hole, stop digging.''
- It is a 2003 American adventure comedy - drama film.
- It was directed by Andrew Davis.
- It was produced by Lowell D. Blank, Mike Medavoy and Teresa Tucker - Davies.
- It has music by Joel McNeely.
- It is based on the 1998 eponymous novel by Louis Sachar.
- Louis Sachar also wrote the screenplay.

# Le Mauricien Newspaper

- Le Mauricien is a French-language newspaper.
- Le Mauricien is based and distributed in Mauritius.
- The newspaper was founded in 1908.
- The newspaper is released daily.
- Le Mauricien is one of the most read newspapers in Mauritius.
- The publishers are Le Mauricien Ltd.
- Le Mauricien Ltd. also publishes "Week-End".
- Le Mauricien Ltd. also publishes "Week-End Scope".
- Le Mauricien Ltd. also publishes "Turf Magazine".
- It is an independent newspaper.

# Leroy M. Zimmerman

Leroy M. Zimmerman
- Leroy M. Zimmerman was born on December 27, 1932.
- Leroy M. Zimmerman died on December 6, 2002.
- Leroy M. Zimmerman was a Republican.
- Leroy M. Zimmerman was a member of the Pennsylvania House of Representatives.
- Leroy Township is in Ingham County, Michigan.
- The population of Leroy Township was 3,653 at the 2000 census.
- Leroy Township is a civil township.
- Leroy Township is in the U.S. state of Michigan.
- Leroy A. Mendonca was a soldier in the United States Army during the Korean War.
- Leroy A. Mendonca posthumously received the Medal of Honor.
- Leroy A. Mendonca's actions occurred on July 4, 1951.
- Pierre Paul Leroy-Beaulieu was born on December 9, 1843.
- Pierre Paul Leroy-Beaulieu died on December 9, 1916.
- Pierre Paul Leroy-Beaulieu was a French economist.
- Pierre Paul Leroy-Beaulieu was the brother of Henri Jean Baptiste Anatole Leroy-Beaulieu.
- Pierre Paul Leroy-Beaulieu was educated at the Lycée Bonaparte and the École de Droit.
- Pierre Paul Leroy-Beaulieu studied at Bonn and Berlin.
- Pierre Paul Leroy-Beaulieu wrote for "Le Temps", "Revue nationale" and "Revue contemporaine".
- Leroy (lørwa) is one of the most common surnames in northern France.
- Leroy is a male given name in English-speaking countries.
- As a surname it is sometimes written Le Roy.
- It is an archaic spelling of le roi, meaning "the king".
- It is the equivalent of the English surname King.
- / ləˈrɔɪ / lə - ROY is the pronunciation of Leroy.
- Vincent Voiture was born on February 24, 1597.
- Vincent Voiture died on May 26, 1648.
- Vincent Voiture was a French poet and writer of prose.
- Vincent Voiture's father was a rich wine merchant of Amiens.
- Vincent Voiture was introduced to Gaston, Duke of Orléans by a schoolfellow, the count Claude d'Avaux.
- Vincent Voiture accompanied Gaston, Duke of Orléans to Brussels and Lorraine on diplomatic missions.

# Life at the Top (Novel)

Life at the Top
- It is the third novel by John Braine.
- It was first published in 1962.
- It was published by Eyre & Spottiswoode in the UK.
- It was published by Houghton Mifflin & Co. in the US.
- It continues the story of Joe Lampton.
- Joe Lampton is an ambitious young man of humble origins.
- A 1965 film adaptation of the novel was made.
- Laurence Harvey starred in the 1965 film adaptation.
- A two-part television adaptation was broadcast by BBC television in September 2012.
- Matthew McNulty was in the lead role in the television adaptation.
- The television adaptation had been delayed because of copyright difficulties.
- It is a novel by Donald Hamilton.
- It was first published in 1964.
- It continues the exploits of Matt Helm.
- It was the seventh novel of the series.
- "Happily Ever After" is Part 6 in the 6 issue story arc of Archie Marries Veronica / Archie Marries Betty.
- The story arc was originally presented in Archie # 605.
- The story features a futuristic look into the life of Archie Andrews and Betty Cooper.
- Archie Andrews and Betty Cooper raise a pair of fraternal twins.

# Lionel Medeiros, Footballer

Lionel Medeiros
- Lionel Jesus Gonçalves Medeiros was born on 14 April 1977.
- Lionel Jesus Gonçalves Medeiros was born in Orléans, France.
- Lionel Medeiros is a retired footballer.
- Lionel Medeiros played as a central defender.
- Lionel Medeiros is Portuguese.
- Magalie Pottier was born on 16 March 1989.
- Magalie Pottier was born in Vallet.
- Magalie Pottier is a French racing cyclist.
- Magalie Pottier represents France in BMX.
- Magalie Pottier was selected to represent France at the 2012 Summer Olympics.
- Magalie Pottier finished in seventh place in the women's BMX event.
- Arlind Rustemi was born on 7 February 1986.
- Arlind Rustemi was born in Vlorë.
- Arlind Rustemi is an Albanian footballer.
- Arlind Rustemi plays as a forward.
- Arlind Rustemi played for KF Vlora in the Albanian First Division as of the 2010–11 season.
- Arlind Rustemi moved to Maltese side Rabat Ajax in October 2011.
- Arlind Rustemi scored on his debut for Rabat Ajax.
- Gervais Batota was born on 10 March 1982.
- Gervais Batota was born in Brazzaville.
- Gervais Batota is French-Congolese.
- Gervais Batota currently plays for FCM Târgoviște.
- In January 2011, Gervais Batota signed a -year contract with FUS de Rabat.
- Silvio Vella was born on 8 February 1967.
- Silvio Vella was born in Toronto.
- Silvio Vella played for Rabat Ajax.
- Silvio Vella played for Hibernians.
- Silvio Vella is currently the head coach of Rabat Ajax.
- Malcolm Licari was born on 18 April 1978.
- Malcolm Licari was born in Pietà, Malta.
- Malcolm Licari plays for Pietà Hotspurs.
- Malcolm Licari plays for Marsaxlokk.
- Malcolm Licari plays for Floriana.
- Malcolm Licari plays for Balzan.
- Malcolm Licari plays as a striker.
- Malcolm Licari occasionally plays as a defender.
- Malcolm Licari used to be captain of Marsaxlokk.
- Malcolm Licari moved to Floriana at the end of 2011.
- Thabiso Nkoana was born on 28 October 1992.
- Thabiso Nkoana is a South African footballer.
- Thabiso Nkoana plays for Ajax Cape Town.
- Thabiso Nkoana plays as a striker.
- Bantu Mzwakali was born on 9 November 199.
- Bantu Mzwakali is a South African football midfielder.
- Bantu Mzwakali plays for Premier Soccer League club Ajax Cape Town.
- Bantu Mzwakali plays for the South Africa U20.
- Sander Westerveld was born on 23 October 1974.
- Sander Westerveld is Dutch.
- Sander Westerveld is a former professional football goalkeeper.
- Sander Westerveld is the goalkeeping coach of Ajax Cape Town.

# Los Vendidos Play

- Los Vendidos is a one-act play.
- Los Vendidos means The Sold Ones or The Sellouts in Spanish.
- Luis Valdez is a Chicano playwright.
- Luis Valdez is a founding member of El Teatro Campesino.
- The play was written in 1967.
- The play was first performed at the Brown Beret junta in Elysian Park, East Los Angeles.
- The play examines stereotypes of Latinos in California.
- The play examines how Latinos are treated by local, state, and federal governments.

# Lou Donaldson - Musty Rusty

Musty Rusty
- It is an album by jazz saxophonist Lou Donaldson.
- It was recorded for the Cadet label.
- The album was recorded in 1965.
- It was performed by Lou Donaldson with Bill Hardman, Billy Gardner, Grant Green, and Ben Dixon.
- Tijuana Jazz is an album by American jazz vibraphonist Gary McFarland and trumpeter Clark Terry.
- It was recorded in 1965.
- It was released in the UK on the HMV label as CLP3541.
- The Jazz Skyline is an album by American jazz vibraphonist Milt Jackson.
- It was recorded in 1956.
- It was released on the Savoy label.

# Louis Philippe I

Louis Philippe I
- Louis Philippe I (6 October 1773 – 26 August 1850) was King of the French from 1830 to 1848.
- His father was Louis Philippe II, Duke of Orléans.
- His father took the name "Philippe Égalité".
- Philippe Égalité initially supported the French Revolution.
- Louis Philippe fled the country following the deposition and execution of his cousin King Louis XVI.
- His father denounced his actions and voted for Louis XVI's death.
- His father was imprisoned and executed that same year.
- Louis Philippe spent 21 years in exile.
- He returned during the Bourbon Restoration.
- He was proclaimed king in 1830 after Charles X was forced to abdicate by the July Revolution.
- His reign is known as the July Monarchy.
- The July Monarchy was dominated by wealthy
- Louise Élisabeth d'Orléans was one of the seven daughters of Philippe II, Duke of Orléans, and his wife, Françoise Marie de Bourbon.
- Her mother was a legitimised daughter of Louis XIV of France and his mistress, Madame de Montespan.
- She was known as Élisabeth.
- As a member of the reigning House of Bourbon, Élisabeth was a "princesse du sang".
- The Great King is a 1942 German drama film.
- The Great King was directed by Veit Harlan.
- Otto Gebühr starred in The Great King.
- The film depicts the life of Frederick the Great.
- Frederick the Great ruled Prussia from 1740 to 1786.
- The film received the "Film of the Nation" distinction.
- The film was part of a popular cycle of "Prussian films".
- Philip III was King of Spain, Portugal, Naples, Sicily, and Sardinia.
- Philip III was Duke of Milan.
- Philip III reigned from 13 September 1598 to 31 March 1621.
- Philip III was born on 14 April 1578 in Madrid, Spain.
- Philip III died on 31 March 1621 in Madrid, Spain.
- Philip III was buried in El Escorial.
- Philip III married Margaret of Austria in 1599.
- Margaret of Austria died in 1611.
- Philip III's children included Anne, Queen of France.
- Marie - Joseph Paul Yves Roch Gilbert du Motier de Lafayette was born on 6 September 1757 in Chavaniac, France.
- He died on 20 May 1834 in Paris, France.
- He is nicknamed "The Hero of the Two Worlds" (Le Héros des Deux Mondes in French).
- He is buried in Picpus Cemetery.
- He served in the French Army and the Continental Army.
- He was a Major General (U.S.) and a Lieutenant General (France).
- He participated in the American Revolutionary War.
- He participated in the Battle of Brandywine.
- He participated in the Battle of Gloucester Valley Forge.
- Paul Phélypeaux de Pontchartrain (1569 – 21 October 1621) was a French statesman.
- He served Marie de' Medici and her son Louis XIII.
- He served during a period of conflict between Catholics and Protestants in France, the French Wars of Religion.
- He was one of the negotiators of the Treaty of Loudun in 1616.
- The Vasari Corridor was built in five months.
- Duke Cosimo I de' Medici ordered the construction of the Vasari Corridor in 1565.
- Giorgio Vasari designed the Vasari Corridor.
- The Vasari Corridor was commissioned in connection with the marriage of Francesco, Cosimo's son, with Johanna of Austria.

# Love and War in the Apennines

Love and War in the Apennines
- It is a 1971 memoir.
- It is a Second World War memoir.
- It has some changes of names and people and places.
- It has some composite characters.
- It was dramatised as the 2001 film "In Love and War".
- The film "In Love and War" starred Callum Blue.
- The film "In Love and War" starred Barbora Bobuľová.
- It was written by Eric Newby.
- Trevor Stamp was the son of Josiah Stamp, 1st Baron Stamp.
- He succeeded his brother and father as Baron Stamp when they were killed during the war by German bombing.
- He was a member of the Liberal Party in the House of Lords but later became a cross-bencher.

# Macbeth and Macduff

Macbeth
- A battle culminates in Macduff's confrontation with Macbeth.
- Macbeth kills Young Siward in combat.
- English forces overwhelm Macbeth's army.
- English forces overwhelm Macbeth's castle.
- Macbeth boasts he can not be killed by any man born of woman.
- Macduff was ``from his mother's womb / Untimely ripp'd''.
- Macduff is not`` of woman born''.
- Macduff fulfills the second prophecy.
- Macbeth misinterpreted the witches' words.
- Macbeth realises he is doomed.
- Macduff kills and beheads Macbeth.
- Macduff fulfills the remaining prophecy.
- Macbeth is initially a valorous and loyal general to the elderly King Duncan.
- The play is based mainly upon Raphael Holinshed's account.
- Macbeth's wife flattered him.
- Macbeth rationalizes that murdering his king and usurping the throne is the right thing to do.
- The prophecies of the witches prove misleading.
- Macbeth alienates the nobility of Scotland.
- Macbeth's wife and children had earlier been murdered by Macbeth's death squads.
- Macbeth at first refuses to duel Macduff.
- Macbeth vows, ``I will not yield to kiss the ground before young Malcolm's feet, to be baited by a rabble's curse.''
- Prince
- Macduff charges into the main castle and confronts Macbeth.
- Macduff presents Macbeth's head to Malcolm.
- Macduff calls on the other thanes to declare their allegiance with him.

# MacDonald Airfield, WWII

- MacDonald Airfield was built during World War II.
- MacDonald Airfield is west of Stuart Highway.
- MacDonald Airfield is north of Pine Creek.
- MacDonald Airfield was built alongside the former northern road.
- MacDonald Airfield is in the Northern Territory, Australia.
- Milingimbi Airport is located east northeast of Milingimbi.
- Milingimbi Airport is on Milingimbi Island.
- The airport received funding for security upgrades in 2006.
- Henbury Meteorites Conservation Reserve is a protected area.
- Henbury Meteorites Conservation Reserve is in the Northern Territory of Australia.
- Henbury Meteorites Conservation Reserve is located in the locality of Ghan.

# Margaret Blair Young

Margaret Blair Young
- Margaret Blair Young was born in 1955.
- Margaret Blair Young is an American author.
- Margaret Blair Young is a filmmaker.
- Margaret Blair Young is a writing instructor.
- Margaret Blair Young taught for thirty years at Brigham Young University.
- Elizabeth Frances Ingram was an American operatic contralto.
- Elizabeth Frances Ingram was born on 5 November 1888.
- Elizabeth Frances Ingram died on 12 April 1974.
- Elizabeth Frances Ingram was of English birth.
- Elizabeth Frances Ingram had an active career in North America during the 1910s and 1920s.
- Ann Grifalconi was born on September 22, 1929.
- Ann Grifalconi is an American author.
- Ann Grifalconi is an American illustrator of children's books.
- Ann Grifalconi was born in New York.
- Ann Grifalconi studied art at the Cooper Union School of Art.
- Ann Grifalconi received a certificate in advertising art in 1950.
- Ann Grifalconi worked in advertising and display for several years.
- Ann Grifalconi taught art and design at the High School of Fashion Industries.
- Ann Grifalconi left to become a full-time illustrator and author.
- Theresa Schwegel was born on July 20, 1975.
- Theresa Schwegel is an American author of crime fiction.
- Theresa Schwegel won the Edgar Award for best first novel from the Mystery Writers of America for "Officer Down" in 2006.
- Theresa Schwegel received the Chicago Public Library Foundation's 21st Century Award for achievement in writing by an author with ties to Chicago in 2008.

# Margareta von Ascheberg

Margareta von Ascheberg
- Margareta von Ascheberg was the youngest child of Field Marshal Rutger von Ascheberg and Magdalena Eleonora Busseck.
- On 26 January 1691, she married colonel count Kjell Christopher Barnekow (d. 1700) in Malmö.
- She kept her name after marriage and style herself »Grevinnan Ascheberg» (Countess Ascheberg).
- The couple had four children.
- She accompanied her spouse on his military commissions.
- She gave birth to their youngest sons during the Bombardment of Brussels in 1695.
- As was the custom of the Swedish nobility as that time, she kept her name after marriage and style herself »Grevinnan Ascheberg» (Countess Ascheberg).

# Marilou Berry Family

Marilou Berry
- Marilou Berry is the daughter of Josiane Balasko.
- Josiane Balasko was born Balašković.
- Marilou Berry is the daughter of Philippe Berry.
- Philippe Berry was born Benguigui.
- Marilou Berry is the niece of Richard Berry.
- Marilou Berry’s mother is of Croatian descent.
- Marilou Berry’s father is of Maghrebi Jewish descent.
- Marilou Berry was uninterested in school studies.
- Marilou Berry left high school.
- Marilou Berry enrolled at the Conservatoire de Paris.
- Leonora Dori Galigaï was born on 19 May 1568.
- Leonora Dori Galigaï died on 8 July 1617.
- Leonora Dori was of Italian origin.
- Leonora Dori was a French courtier.
- Leonora Dori was a favourite of Marie de' Medici.
- Leonora Dori was married to Concino Concini.
- Concino Concini was later the marquis d'Ancre.
- Concino Concini was later the marshal d'Ancre.
- Leonora Dori’s husband was influential during Marie's reign as Queen Mother and
- The Han-era family was patrilineal.
- Multiple generations of extended family members did not occupy the same house.
- Fathers' input on offspring's spouse was considered more important than mothers'.
- Monogamous marriages were normal.
- Nobles and high officials were wealthy enough to afford and support concubines.
- Both men and women were able to divorce their spouses and remarry.
- Nina Companeez was a French screenwriter and film director.
- Nina Companeez was born on 26 August 1937.
- Nina Companeez died on 9 April 2015.
- Nina Companeez was the younger daughter of Jacques Companéez.
- Jacques Companéez was a Russian Jewish émigré screenwriter.
- Nina Companeez was the younger sister of Irène Companeez.
- Irène Companeez was a contralto.
- Nina Companeez was the mother of actress Valentine Varela.

# Marin County Civic Center

Marin County Civic Center
- The Marin County Civic Center is located in San Rafael, California.
- The Marin County Civic Center was designed by Frank Lloyd Wright.
- The Marin County Civic Center is in the United States.
- Groundbreaking for the Civic Center Administration Building took place in 1960.
- Aaron Green was Wright's protégé.
- The Civic Center Administration Building was completed in 1962.
- The Hall of Justice was begun in 1966.
- The Hall of Justice was completed in 1969.
- Veterans Memorial Auditorium opened in 1971.
- The Exhibit Hall opened in 1976.
- The Walter V. Davidson House is located at 57 Tillinghast Place in Buffalo, New York.
- The Walter V. Davidson House was designed by Frank Lloyd Wright.
- The Walter V. Davidson House was built in 1908.
- The Walter V. Davidson House is an example of Wright's Prairie School architectural style.
- The Walter V. Davidson House is a contributing property to the Parkside East Historic District.
- Frederick Law Olmsted laid out the Parkside East Historic District in 1876.
- Isabel Roberts House is a classic 1908 Prairie House.
- Isabel Roberts House is located at 603 Edgewood Place in River Forest, Illinois.
- It was built for Isabel Roberts and her widowed mother, Mary Roberts.
- The Isabel Roberts House is from the studio of Frank Lloyd Wright.

# Market Square, High Point

Market Square (High Point, North Carolina)
- Market Square is a furniture showroom complex.
- It is located in High Point, North Carolina.
- It is owned by International Market Centers.
- It is the largest building in North Carolina on the National Register of Historic Places (NRHP).
- It is the sixth largest building in the United States.
- It was formerly known as Tomlinson Chair Manufacturing Company Complex.
- It was listed on the NRHP under that name.
- It includes the oldest factory building in the city.
- Its renovation has been credited with making High Point a successful furniture exhibition center.
- A 16-story addition was built in 1990.
- The 16-story addition is one of the city's tallest buildings.

# Marketwired Press Release Service

Marketwired
- Marketwired is a press release distribution service
- Marketwired is headquartered in Toronto, Ontario, Canada
- Marketwired was founded in 1993
- Marketwired was incorporated in the U.S. in 1999
- Marketwired distributes press releases via the Associated Press
- Marketwired distributes press releases via Bloomberg
- Marketwired distributes press releases via new media methods
- Marketwired distributes press releases via other services

# Marshall Eriksen Character

Marshall Eriksen
- Marshall Eriksen is a How I Met Your Mother character.
- Jason Segel portrayed Marshall Eriksen in 2011.
- Marshall Eriksen first appeared in the ``Pilot'' episode.
- Marshall Eriksen's last appearance was in the ``Last Forever'' episode.
- Marshall Eriksen was created by Carter Bays and Craig Thomas.
- Marshall Eriksen's gender is male.
- Marshall Eriksen's occupation was Lawyer (2005 -- 2018).
- Marshall Eriksen's occupation is Judge (2018 --).
- Marshall Eriksen's father was Marvin Eriksen (deceased).
- Marshall Eriksen's mother is Judy Eriksen.
- Marshall Eriksen's spouse is Lily Aldrin (2007 -- present).
- Marshall Eriksen has a child named Marvin Waitforit Eriksen.
- Marshall Eriksen has

# Marshall Islands - US Occupation

Marshall Islands
- The Marshall Islands were captured and occupied by the United States during World War II.
- The Marshall Islands are located in Micronesia.
- The Marshall Islands passed formally to the United States in 1947.
- The Marshall Islands were part of the Trust Territory of the Pacific Islands.
- The Trust Territory of the Pacific Islands was established pursuant to Security Council Resolution 21.

# Mart Stam's New Objectivity

Mart Stam
- His style of design has been classified as New Objectivity.
- New Objectivity was an art movement formed during the depression in 1920's Germany.
- New Objectivity was a counter-movement.
- New Objectivity was an outgrowth of Expressionism.

# Martha Creek Provincial Park

Martha Creek Provincial Park
- It is a provincial park in British Columbia, Canada
- It is located on the Lake Revelstoke Reservoir
- It is north of the city of Revelstoke
- Pine Mountain State Resort Park is located in Bell County, Kentucky, United States.
- The park opened in 1924 as Kentucky's first state park.
- Each spring, the park hosts the annual Kentucky Mountain Laurel Festival, as it has since 1933.
- A portion of the park is a legally dedicated nature preserve by the Office of Kentucky Nature Preserves.
- It is located in the Canadian Rockies
- It is on the border of Alberta and British Columbia
- It is northwest of Kicking Horse Pass
- It straddles the shared border of Banff National Park with Yoho National Park
- It was named in 1903 after George Morris Bosworth
- George Morris Bosworth was an executive and long-time employee of the Canadian Pacific Railway

# Mary Ann Sampson, Artist

Mary Ann Sampson is an American artist.
Mary Ann Sampson lives and works in Ragland, Alabama.
Mary Ann Sampson is a book artist.
Mary Ann Sampson specializes in miniatures.
Mary Ann Sampson specializes in broadsides.
Most of Mary Ann Sampson’s works are "uniques" or "one-of-a-kinds."
Mary Ann Sampson explores the book as a means of expressing visual ideas.
Mary Ann Sampson’s visual ideas stem from recollections of personal events.
Mary Ann Sampson’s visual ideas stem from experiences derived from living in Alabama.
Mary Ann Sampson lives in a rural environment of Alabama.

# Mary's Boy Child Song

Mary's Boy Child
- "Mary's Boy Child" is a 1956 Christmas song.
- It was written by Jester Hairston.
- It is widely performed as a Christmas carol.

# Mathura Refinery

Mathura Refinery
- Mathura Refinery is one of the biggest oil refineries of Asia
- Mathura Refinery has 8.0 MMTPA refining capacity
- Mathura Refinery is an oil refinery of the Indian Oil Corporation
- Mathura Refinery is a highly technologically advanced oil refinery
- Mathura Refinery provides local employment opportunities
- Mathura Refinery is located in the city

# Men's Greco-Roman 57 kg

- The Men's Greco-Roman 57 kg was part of the wrestling program at the 1984 Summer Olympics.
- The event was held at the Anaheim Convention Center.
- The event was held in Anaheim, California.

# Mian Haji Sahib, Pakistan

Mian Haji Sahib
- Mian Haji Sahib is a town.
- It is in the Islamabad Capital Territory of Pakistan.
- It is located at 33° 22' 50N 73° 20' 40E.
- It has an altitude of 479 metres.
- It has an altitude of 1574 feet.

# Michael Feinstein - Romance on Film

- Romance on Film, Romance on Broadway is an album.
- The album was released in 2000.
- Michael Feinstein is the vocalist on the album.
- Alan Broadbent arranged the album.
- John Oddo arranged the album.
- It was Feinstein's third album for the Concord label.

# Michaela Quinn and Byron Sully

Dr. Michaela Quinn
Byron Sully
Matthew Cooper
Colleen Cooper
Colleen Cooper Cook
Brian Cooper
Jane Seymour
Joe Lando
Chad Allen
Erika Flores
Shawn Toovey

# Michel Guerry, French Senator

Michel Guerry
- Michel Guerry was born on 2 December 1932.
- Michel Guerry is a French politician.
- Michel Guerry is a member of the Senate of France.
- Michel Guerry is a member of the Union for a Popular Movement Party.
- Jean-Marie Cavada was born on 24 February 1940 in Épinal, Vosges.
- Jean-Marie Cavada served as a Member of the European Parliament for Ile de France from 2004 until 2019.
- Jean-Marie Cavada is president of the European Movement France since 3 December 2011.
- Christophe Béchu was born on 11 June 1974 in Angers, Maine-et-Loire.
- Christophe Béchu is a French politician.
- Christophe Béchu is President of the General Council of the Maine-et-Loire department since 2004.
- Christophe Béchu was a Member of the European Parliament (MEP) elected in the 2009 European election to 2011 for the West France constituency.
- Christophe Béchu was formerly a member of DL.
- Christophe Béchu was a member of the Union for a Popular Movement, later The Republicans.
- Christophe Béchu left The Republicans in early December
- Antonia Parvanova was born on 26 April 1962 in Dobrich.
- Antonia Parvanova is a Bulgarian politician.
- Antonia Parvanova is a Member of the European Parliament.
- Antonia Parvanova is a member of the National Movement Simeon II.
- Antonia Parvanova is part of the Alliance of Liberals and Democrats for Europe.
- Antonia Parvanova became an MEP on 1 January 2007 with the accession of Bulgaria to the European Union.
- Roselyne Bachelot-Narquin is generally known as Roselyne Bachelot.
- Roselyne Bachelot was born on 24 December 1946 in Nevers, Nièvre.
- Roselyne Bachelot is a former Minister of Solidarity and Social Cohesion.
- Roselyne Bachelot is a member of the Union for a Popular Movement.
- Roselyne Bachelot is part of the European People's Party.
- Franck Proust was born on 2 May 1963, in Poitiers.
- Franck Proust is a French politician of the Union for a Popular Movement.
- Franck Proust is a member of the European Parliament since 2011.
- Franck Proust is first vice-chair of the French EPP Group delegation in the European Parliament.
- Franck Proust is first deputy mayor of Nîmes.
- Franck Proust is an insurance agent in Nîmes.
- Franck Proust was originally an entrepreneur.
- Glenda Goss is an American author.
- Glenda Goss is a music historian.
- Glenda Goss's special interests are music and culture.
- Glenda Goss's special interests are early modernism.
- Glenda Goss's special interests are critical editing.
- Glenda Goss's special interests are European-American points of cultural contact.
- Glenda Goss's most notable work has revolved around the life and works of Jean Sibelius.
- Hector Bianciotti was born on 18 March 1930.
- Hector Bianciotti died on 12 June 2012.
- Hector Bianciotti was Argentine-born.
- Hector Bianciotti was a French author.
- Hector Bianciotti was a member of the Académie française.

# Mick Taylor Biography

Mick Taylor
- Birth name is Michael Kevin Taylor
- Also known as Little Mick
- Date of birth is 17 January 1949
- Age is 69
- Place of birth is Welwyn Garden City, England
- Genres include Rock and Blues
- Occupations include Musician, singer, and songwriter
- Instruments include Guitar
- Years active are 1964 -- present
- Labels include Columbia, Decca, Rolling Stones, Atlantic, EMI, Virgin, CBS, Maze Records
- Associated acts include John Mayall's Bluesbreakers, The Rolling Stones, The Jack Bruce Band, Carla Olson, The Gods, Mike Oldfield

# Minsk Region, Belarus

Minsk Region
- Minsk Region is one of the regions of Belarus.
- Minsk Region is also known as Minsk Voblasć.
- Minsk Region is also known as Minsk Oblast.
- The administrative center of Minsk Region is Minsk.
- Minsk is a separate administrative territorial entity of Belarus.
- As of 2011, the population of Minsk Region is 1,411,500.
- Cherdynsky District is an administrative district (raion) of Perm Krai, Russia.
- Cherdynsky District borders with the Komi Republic in the north.
- Cherdynsky District borders with Krasnovishersky District in the east.
- Cherdynsky District borders with Solikamsky District in the south.
- Cherdynsky District borders with Kosinsky District in the southwest.
- Cherdynsky District borders with Gaynsky District in the west.
- The area of the district is .
- The administrative center of Cherdynsky District is the town of Cherdyn.
- The population of Cherdyn accounts for 20.0% of
- Akshinsky District is an administrative and municipal district (raion) of Zabaykalsky Krai, Russia.
- It is located in the south of the krai.
- It borders with Ononsky District of Zabaykalsky Krai.
- It borders with Ulyotovsky District of Zabaykalsky Krai.
- It borders with Kyrinsky District of Zabaykalsky Krai.
- It borders with Mongolia.
- The administrative center of Akshinsky District is the rural locality (a "selo") of Aksha.
- The population of Akshinsky District is 12,080
- Minsk Region or Minsk Voblasć or Minsk Oblast (, "Minskaja vobłasć" ; , "Minskaja oblastj") is one of the regions of Belarus.
- Its administrative center is Minsk, although it is a separate administrative territorial entity of Belarus.
- As of 2011, the region's population is 1,411,500.
- Beryslav Raion is one of the 18 administrative raions of Kherson Oblast in southern Ukraine.
- Its administrative center is located in the city of Beryslav.
- Its population was 55,976 as of the 2001 Ukrainian Census.
- Current population:
- Its administrative center is Minsk.
- It is a separate administrative territorial entity of Belarus.
- As of 2011, the region’s population is 1,411,500.
- Nərimanabad is a village in the Lankaran Rayon of Azerbaijan.
- Nərimanabad is also known as Narimanov, Sara, and Sara-Ostrov.
- The population of Nərimanabad is 4,876.
- The municipality of Nərimanabad consists of the villages of Nərimanabad and Üzümçülük.
- Van Hook Township is in Mountrail County, North Dakota.
- In 2000, the population of Van Hook Township was 42.
- The estimated population of Van Hook Township in 2009 was 41.
- McCormack is an unorganized territory in Saint Louis County, Minnesota, United States.
- McCormack is located near Hibbing and Balkan Township.
- The population of McCormack was 237 at the 2000 census.

# Miquette Giraudy

Miquette Giraudy
- Miquette Giraudy was born on 9 February 1953.
- Miquette Giraudy was born in Nice, France.
- Miquette Giraudy is a keyboard player.
- Miquette Giraudy is a vocalist.
- Miquette Giraudy is best known for her work in Gong.
- Miquette Giraudy works with Steve Hillage.
- Miquette Giraudy and Steve Hillage form the core of the ambient band System 7.
- Miquette Giraudy has worked as an actress.
- Miquette Giraudy has worked as a film editor.
- Miquette Giraudy has worked as a writer.
- Miquette Giraudy uses different stage names in each role.
- Emmanuelle Boidron was born on 4 August 1978.
- Emmanuelle Boidron was born in Orléans, Loiret, France.
- Emmanuelle Boidron is a French actress.
- Emmanuelle Boidron appeared in the Navarro TV series.
- Emmanuelle Boidron played Yolande Navarro in the Navarro TV series.
- Claude Aveline was born on 19 July 1901.
- Claude Aveline died on 4 November 1992.
- Claude Aveline was born in Paris, France.
- Claude Aveline used the pen name Evgen Avtsine.
- Claude Aveline was a writer.
- Claude Aveline was a publisher.
- Claude Aveline was an editor.
- Claude Aveline was a poet.
- Claude Aveline was a member of the French Resistance.
- Claude Aveline authored numerous books and writings.
- Claude Aveline wrote novels.
- Claude Aveline wrote poems.
- Nathalie Boutefeu was born in 1968.
- Nathalie Boutefeu is a French actress.
- Nathalie Boutefeu is a film director.
- Nathalie Boutefeu is a screenwriter.
- Nathalie Boutefeu has appeared in 40 films since 1990.
- Nathalie Boutefeu starred in "The Butterfly's Dream".
- "The Butterfly's Dream" was screened in the Un Certain Regard section at the 1994 Cannes Film Festival.
- Eva Ionesco was born on 18 July 1965.
- Eva Ionesco came to international prominence as a child.
- Eva Ionesco is a film director.
- Eva Ionesco is a screenwriter.
- Valeria Bruni Tedeschi is an Italian-French actress.
- Valeria Bruni Tedeschi is a screenwriter.
- Valeria Bruni Tedeschi is a film director.
- Valeria Bruni Tedeschi's 2013 film, "A Castle in Italy," was nominated for the Palme d'Or at the 2013 Cannes Film Festival.
- Valeria Bruni Tedeschi is also spelled Bruni-Tedeschi.
- Valeria Bruni Tedeschi was born on 16 November 1964.

# Miss Sara Sampson

Miss Sara Sampson
- Miss Sara Sampson is a play by Gotthold Ephraim Lessing.
- The original spelling of Miss Sara Sampson is "Miß Sara Sampson".
- The play was written in 1755.
- The author was living in Potsdam when the play was written.
- Many scholars see it as one of the first bourgeois tragedies.
- It was represented at Frankfurt-on-the-Oder in 1755.
- It was very well received at Frankfurt-on-the-Oder.
- It was translated and acted in France.
- It met with success in France.
- It was Lessing's first real success as a playwright.
- The success of the play led to Lessing being asked to be the dramaturg at the German National Theatre in Hamburg.
- Emilia Galotti is a play in five acts by Gotthold Ephraim Lessing (1729–1781).
- The work premiered on 8 March 1772 in Brunswick.
- The work is a classic example of German "bürgerliches Trauerspiel" (bourgeois tragedy).
- The story is based upon the Roman myth of Verginia.
- Other works in this category include Schiller's "Kabale und Liebe" and Hebbel's "Maria Magdalene".
- The play was intended to be performed in one act without interruptions.
- Some 18th-century editors divided the play into three acts.
- The "Imaginary Cuckold" continues to be performed today in its original one-act version.
- A performance of the play by the actors of the Comédie-Française with stage direction by Thierry Hancisse was broadcast on France 3 television in 2002.
- A performance of the play was released on DVD in 2008.

# Moby Grape Compilation Album

The Place and the Time
- The Place and the Time is a compilation album.
- The album contains demos.
- The album contains outtakes.
- The album contains alternative versions.
- The album contains live versions.
- The album is by Moby Grape.
- The album was released by Sundazed Records.
- The album was released in 2009.
- The album was released in CD format.
- The album was released in double LP format.
- Great Grape is a compilation album.
- Great Grape was released by Columbia Records in 1972.
- Great Grape compiles songs from three of Moby Grape's Columbia albums - "Moby Grape", "Wow", and "Moby Grape '69".
- Columbia's decision to release Great Grape was based on trying to capitalize on any interest generated in Moby Grape by the then-recent release of a new studio album, "20 Granite Creek", on Reprise Records.

# Mok Kwai-lan, Wong Fei-hung's Spouse

Mok Kwai-lan
- Mok Kwai-lan’s date of birth was October 15, 1892.
- Mok Kwai-lan’s date of death was November 3, 1982.
- Mok Kwai-lan was the fourth spouse of Wong Fei-hung.
- Mok Kwai-lan was a spouse of a Lingnan martial arts grandmaster.
- Wong Fei-hung was a Lingnan martial arts grandmaster.

# Moorea-Maiao Commune

Moorea-Maiao
- Moorea-Maiao is a commune of French Polynesia.
- French Polynesia is an overseas territory of France.
- Moorea-Maiao is located in the Pacific Ocean.
- Moorea-Maiao is in the Windward Islands.
- In 2017, Moorea-Maiao had a population of 17,816.
- The commune is in the administrative subdivision of the Windward Islands.
- The commune is in the administrative subdivision of the Windward Islands.
- Poum is a commune in the North Province of New Caledonia.
- Poum is an overseas territory of France.
- Poum is located in the Pacific Ocean.
- The town of Poum is located at Latitude: 20° 13' 59" south, longitude: 164° 1' 23" east.
- Poum is located on the southern part of Banare Bay.
- Mouac Island is just offshore from Poum.
- Huahine is an island.
- Huahine is located among the Society Islands.
- Huahine is part of the Leeward Islands group "(Îles sous le Vent)."
- In 2017, Huahine had a population of 6,075.

# Mount Meigs Campus

Mount Meigs Campus
- The Mount Meigs Campus is a juvenile corrections facility.
- It is a facility of the Alabama Department of Youth Services.
- It is located in Mount Meigs, unincorporated Montgomery County.
- It serves as the agency's administrative headquarters.
- The campus can house 264 boys.
- It is next to Interstate 85 North.
- It is east of Downtown Montgomery.
- Since 2015, the J. Walter Wood Treatment facility for 24 girls is also located in the Mount Meigs Campus.
- The separate J. Walter Wood Treatment facility for 24 girls is also located in the Mount Meigs Campus.

# Music of Old Serbia

- Music of the Old Serbia is a debut vinyl album by Ensemble Renaissance.
- The album was released in 1983.
- It was released on the PGP RTB label.
- The album was also released as an audio cassette.
- It is Ensemble's first album with early music of Serbia.
- Ensemble Renaissance will revisit the theme of Serbian Medieval songs and dances on the Roots of the Balkan.
- Some material from this album will be remastered on the Music of Old Serbia - Chants from 14th to the 18th century.
- The Music of Old Serbia - Chants from 14th to the 18th century is dedicated exclusively to the Medieval Serbian chant.
- Kovilje is a village.
- Kovilje is in the municipality of Ivanjica, Serbia.
- The population of Kovilje is 18 inhabitants (as of 2011).
- Kovilje is situated between Mountains Golija and Javor.
- Kovilje is in central Serbia.
- Tilva Roš is a 2010 Serbian coming of age drama.
- The film follows a group of skaters from Bor.
- Bor is a small mining town in the eastern part of Serbia.
- The film takes place during their first summer after finishing high school.
- Banja Monastery () is a Serbian Orthodox Monastery.
- It is located near Priboj, Serbia.
- Monastery Banja presents Cultural Monument of Exceptional Importance in Serbia.

# National Cycle Route 57

- National Cycle Route 57 is part of the United Kingdom's National Cycle Network.
- It will run west to east when complete.
- It will run from Farmington, Gloucestershire near Northleach.
- It will run to Welwyn Garden City in Hertfordshire.
- The National Cycle Network is the national cycling route network of the United Kingdom.
- It was established to encourage cycling throughout Britain, as well as for the purposes of bicycle touring.
- It was created by the charity Sustrans.
- Sustrans were aided by a £42.5 million National Lottery grant.
- In 2017, the 16,575 mile network was used for over 786 million trips.

# NEMA Connectors

- NEMA connectors are power plugs and receptacles
- NEMA connectors are used for AC mains electricity
- NEMA connectors are used in North America
- NEMA connectors are used in other countries
- Standards for NEMA connectors are set by the US National Electrical Manufacturers Association
- NEMA wiring devices are made in current ratings from 15 to 60 amperes (A)
- NEMA wiring devices are made in voltage ratings from 125 to 600 volts (V)
- Different combinations create non-interchangeable connectors
- Connectors are unique for each combination of voltage
- Connectors are unique for each combination of electric current carrying capacity
- Connectors are unique for each combination of grounding system.

# New Richland, Minnesota

New Richland, Minnesota
- New Richland is a city in Waseca County, Minnesota, United States.
- The city was founded in 1877.
- The population was 1,203 at the 2010 census.
- New Richland is located in rural south-central Minnesota.
- New Richland is a small town with a strong agricultural base.
- In 2013, the NRHEG High School Women's Basketball team won the State Tournament.
- Emmaville is an unincorporated community in Hubbard County, Minnesota, United States.
- Emmaville is located half way between Park Rapids and Lake George.
- Emmaville is located at the junction of Hubbard County Roads 4 and 24.
- Emmaville is located within Clay Township and Lake Emma Township.
- Population estimates have been listed between 4 and 29.

# Niassa Reserve, Mozambique

- Niassa Reserve is in Cabo Delgado Province and Niassa Province, Mozambique.
- Niassa Reserve is the largest protected area in the country.
- Niassa Reserve is part of the Trans-Frontier Conservation Area.
- Niassa Reserve links to the Tanzanian Lukwika-Lumesule Game Reserve.
- Niassa Reserve will connect to the Lake Niassa Reserve when it is completed.
- Young Man Lake is located in Glacier National Park, in the U. S. state of Montana.
- Young Man Lake is in a cirque immediately east of Flinsch Peak.
- A series of waterfalls carries waters from the lake to nearby Boy Lake.

# Nigerian States and Territories

Nigerian States
- A Nigerian State shares sovereignty with the Federal Government of Nigeria.
- There are 36 States in Nigeria.
- The States are bound together by a federal agreement.
- There is a territory called the Federal Capital Territory (FCT).
- The Federal Capital Territory (FCT) is not a state.
- The Federal Capital Territory (FCT) is under the direct control of the Federal Government.
- There are 774 Local Government Areas.
- States have the power to ratify constitutional amendments.
- Brazil's 1988 Constitution included municipalities as autonomous political entities.
- Brazil's federation is tripartite, encompassing the Union, the States, and the municipalities.
- Each state in Brazil is divided into municipalities.
- Municipalities in Brazil have their own legislative council (câmara de vereadores).
- Municipalities in Brazil have a mayor (prefeito).
- Municipalities in Brazil are partly autonomous from both Federal and State Government.
- Each municipality in Brazil has a "little constitution", called "organic law".
- Mexico's federal constitution grants full-autonomy to municipalities.
- Mexico's federal constitution establishes the existence of municipalities as autonomous entities.
- Municipalities in Mexico
- In 2015, there were 54 sovereign states and 27 non-sovereign entities where English was an official language.
- Many country subdivisions have declared English an official language at the local or regional level.
- English is an official language in territories where it is used in citizen interactions with government officials.
- A Nigerian State is a federated political entity.
- The States are further divided into a total of 774 Local Government Areas.
- Under the Nigerian Constitution, states have the power to ratify constitutional amendments.
- In the late 19th century, European imperial powers occupied most of the continent.
- Ethiopia (known to Europeans as ``Abyssinia '') was one of only two fully independent states.
- Liberia was one of only two fully independent states.
- Egypt was never formally incorporated into any European colonial empire.
- Egypt was effectively under British administration until 1922.
- Sudan was never formally incorporated into any European colonial empire.
- British citizenship can be obtained by naturalisation.
- British citizenship can be obtained by registration.
- British citizenship can be obtained by adoption.
- British citizenship can be obtained by birth in the UK or a qualified British Overseas Territory to a parent who is a British citizen at the time of the birth, or to a parent who is settled in the UK or that Overseas Territory.
- British citizenship can be obtained by birth abroad, which constitutes ``by descent ''if one of the parents is a British citizen otherwise than by descent.
- British citizenship by descent is only transferable to one generation down from the parent who is a British citizen otherwise than by descent, if the child is born abroad.
- The issuance of birth certificates in the U.S. is a function of the Vital Records Office of the states, capital district, territories and former territories.
- Birth in the U.S. establishes automatic eligibility for American citizenship.
- The U.S. State Department issues a Consular Report of Birth Abroad for children born to U.S. citizens.
- Births on military bases in foreign territory are included in the Consular Report of Birth Abroad.
- Delta Women is a non-governmental organization.
- Delta Women was founded primarily to enable the women of Delta State, Nigeria.
- Delta Women advocates for women rights.
- Delta Women creates awareness.
- Delta Women holds seminars on child abuse.
- Delta Women campaigns on female sexual harassment in higher educational institutions.
- English is used in citizen interactions with government officials.
- A Nigerian State is a federated political entity, which shares sovereignty with the Federal Government of Nigeria.
- A birth certificate from a local authority is commonly provided to the federal government to obtain a U.S. passport.
- Darial is a town.
- Darial is in the Islamabad Capital Territory of Pakistan.
- Darial is located at 33° 23' 35N 73° 19' 45E.
- Darial has an altitude of 494 metres (1624 feet).
- Bann Na Mohra is a town in the Islamabad Capital Territory of Pakistan.
- It is located at 33° 27' 50N 73° 22' 10E.
- It has an altitude of 562 metres (1847 feet).
- The Parliament of India can pass a law to amend the Constitution and provide a Legislature with elected Members and a Chief Minister for a Union Territory.
- The President of India appoints an administrator or lieutenant - governor for each UT.
- There are seven union territories.
- Chandigarh is a joint capital of Punjab and Haryana.
- Union Territory is a type of territory.
- Mian Haji Sahib is a town in the Islamabad Capital Territory of Pakistan.
- It is located at 33° 22' 50N 73° 20' 40E.
- It has an altitude of 479 metres (1574 feet).
- Nigeria is divided into thirty-six states and one Federal Capital Territory.
- The states are further sub-divided into 774 Local Government Areas (LGAs).
- There were only three states at independence.
- The states are aggregated into six geopolitical zones: North West, North East, North Central, South East, South South, and South West.
- The plethora of states reflect the country's tumultuous history.
- The states reflect the difficulties of managing such a heterogeneous national entity at all levels of government.
- The plethora of states, of which there were only three at independence, reflect the country's tumultuous history and the difficulties of managing such a heterogeneous national entity at all levels of government.
- As it has done for Delhi and Puducherry.
- The Parliament of India can pass a law to amend the Constitution and provide a Legislature with elected Members and a Chief Minister for a Union Territory, as it has done for Delhi and Puducherry.
- There is also a territory called the Federal Capital Territory (FCT)
- The States are divided into 774 Local Government Areas
- There are 36 States in Nigeria, which are bound together by a federal agreement
- There are 36 States in Nigeria, which are bound together by a federal agreement.
- There is also a territory called the Federal Capital Territory (FCT), which is not a state.
- English is a language used in citizen interactions with government officials.
- Eleven states and two federal territories are located on the Malay Peninsula, collectively called Peninsular Malaysia (Semenanjung Malaysia) or West Malaysia.
- Two states are on the island of Borneo.
- The remaining one federal territory consists of islands offshore of Borneo.
- East Malaysia or Malaysian Borneo refers to two states on the island of Borneo and the remaining one federal territory.
- Out of the 13 states in Malaysia, 9 are hereditary monarchies.

# Nizampatnam Mandal, Guntur District

- Nizampatnam mandal is one of the 57 mandals in Guntur district.
- Nizampatnam mandal is in the state of Andhra Pradesh, India.
- It is under the administration of Tenali Revenue Division.
- The headquarters are located at Nizampatnam.
- The mandal is bounded by Repalle mandals.
- The mandal is bounded by Nagaram mandals.
- The mandal is bounded by Pittalavanipalem mandals.
- The mandal is bounded by Karlapalem mandals.
- The mandal lies on the shore of Bay of Bengal.
- A portion of the mandal lies on the banks of Krishna River.

# No Escape (1936 film)

No Escape (1936 film)
- No Escape is a 1936 British thriller film.
- The film was directed by Norman Lee.
- The film stars Valerie Hobson.
- The film stars Leslie Perrins.
- The film stars Robert Cochran.
- The screenplay concerns a man who attempts to hide his friend for a month.

# Nolwenn Leroy - Histoires Naturelles

Histoires Naturelles is Nolwenn Leroy's second album.
It was released on 5 December 2005 in France.
Most of the songs were written by Laurent Voulzy.
Most of the songs were written by Nolwenn Leroy.
The title track was written in English by Yasmin Shah.
The title track was written in English by Arnaud Rosenthal.
"Mélusine" was written by Yasmin Shah.
"London Fantasy" was co-written by members of English down-tempo band Sundae Club.
Leroy adapted all the English-language lyrics into French.

# NORC at the University of Chicago

NORC at the University of Chicago
- NORC at the University of Chicago is one of the largest independent social research organizations in the United States.
- It was established in 1941 as the National Opinion Research Center.
- Its corporate headquarters is located in downtown Chicago.
- It has offices in several other locations throughout the United States.
- It is organized as an independent corporation.
- More than half its board comes from faculty and administration of the university.
- It also jointly staffs some university academic research centers.

# North Hastings High School

North Hastings High School
- It is located in Bancroft, Ontario, Canada
- It serves students in the northern portion of Hastings County
- It is part of the Hastings and Prince Edward District School Board
- It offers specialized 4-credit courses
- These courses teach principles of resource management
- These courses teach principles of environmental studies
- These courses help students gain employment in resource-based careers
- It is located in Thorndike, Maine, United States
- It is a part of Maine School Administrative District 3
- It serves students from the towns of Brooks, Freedom, Jackson, Knox, Liberty, Monroe, Montville, Thorndike, Troy, Unity and Waldo.
- It was located in Ashland, Maine, USA.
- It was part of Maine School Administrative District 32, or MSAD 32.
- It served students from Ashland, Garfield Plantation, Masardis, Oxbow, Portage Lake and Sheridan, Maine.
- It had a student population of 200 in school grades 7–12.
- It had eighteen faculty members as well as administrators, a counselor and three support personnel.
- It had achieved accredited status with the New England Association of Schools and Colleges.
- NRHEG stands for New Richland, Hartland, Ellendale, Geneva
- The school is located in New Richland, Minnesota.
- NRHEG covers the towns of New Richland, Hartland, Ellendale, and Geneva.
- Any information about North Hastings High School
- Any information that is already in the current page
- Any information that is not directly from the new information
- Any conversational text (e.g. "Here's the list:")
- Any formatting that is not in the original wiki rules (e.g. bolding, italics)
- Any text that is not a bullet point or a
- The Salem County Vocational Technical Schools (SCVTS) is a countywide vocational and technical public school district.
- It serves the educational needs of residents of Salem County, New Jersey, United States.
- The district offers programs on both a full-time and shared-time basis.
- It operates in cooperation and partnership with the county’s elementary and secondary schools.
- It operates in cooperation and partnership with local and regional colleges and universities.
- It offers programs for both school-aged students and adults.
- McFarland School District is located in McFarland, in Dane County, Wisconsin, USA.
- It operates McFarland High School.
- It operates the Wisconsin Virtual Academy, a charter school.
- The population of Vermont was 839 at the 2000 census.
- The unincorporated communities of Elvers and Vermont are located in the town.

# Nova Sports Greece

Nova Sports
- Nova Sports is a premium Sports service in Greece.
- Nova Sports is owned by Forthnet Group.
- Forthnet Group is a subsidiary of Greek Telecommunications company Forthnet.
- It launched in 1994 as "Supersport".
- It was the first ever premium sports service in Greece.
- It is available exclusively on Nova.
- Nova is a DTH satellite service.
- Nova Sports is available terrestrially and via satellite only on Nova.
- Greece has been a member of the European Space Agency (ESA) since 2005.
- Greece's technology parks with incubator facilities include the Science and Technology Park of Crete (Heraklion), the Thessaloniki Technology Park, the Lavrio Technology Park and the Patras Science Park, the Science and Technology Park of Epirus (Ioannina).
- Cooperation between ESA and the Hellenic National Space Committee began in the early 1990s.
- In 1994 Greece and ESA signed their first cooperation agreement.
- Having formally applied for full membership in 2003, Greece became the ESA's sixteenth member on 16 March 2005.
- BSkyB utilises the VideoGuard pay-TV scrambling system owned by NDS, a Cisco Systems company.
- There are tight controls over use of VideoGuard decoders.
- VideoGuard decoders are not available as stand-alone DVB CAMs (conditional-access modules).
- BSkyB has design authority over all digital satellite receivers capable of receiving their service.
- The receivers must conform to the same user interface look-and-feel.
- The receivers offer a Personal video recorder (PVR) offering branded Sky+.

# Nughu Island, Solomon Islands

- Nughu is an island in the Solomon Islands
- Nughu is located in Guadalcanal Province
- The estimated terrain elevation above sea level is some 12 metres
- Bansaan is a boomerang-shaped island
- Bansaan is located off the mid-northern coast of Bohol Island
- Bansaan is part of the municipality of Talibon
- Bansaan is in the province of Bohol

# Nyuksensky District, Vologda Oblast

Nyuksensky District
- Nyuksensky District is an administrative and municipal district (raion)
- It is one of the twenty-six in Vologda Oblast, Russia
- It is located in the northeast of the oblast
- It borders with Ustyansky District of Arkhangelsk Oblast in the north
- It borders with Velikoustyugsky District in the east
- It borders with Kichmengsko-Gorodetsky District in the southeast
- It borders with Babushkinsky District in the south
- It borders with Totemsky District in the southwest
- It borders with Tarnogsky District in the west
- The area of the district is
- Its administrative center is the rural locality of Nyuksenitsa
- The population of the district is 11,714 (2002 Census)
- The population of Nyuksenitsa accounts for 43.7% of the

# Oak Lawn, Illinois

Oak Lawn, Illinois
- Oak Lawn is a suburb of Chicago
- It is located southwest of Chicago
- It shares borders with the city in two areas
- It is surrounded mostly by other suburbs
- The 2018 Illinois gubernatorial election takes place as part of the 2018 Illinois general election.
- The election elects the Governor of Illinois.
- Democratic and Republican general primary elections will take place on March 20, 2018.
- The general election will take place on November 6, 2018.

# Oblasts of the Soviet Union

- Oblasts were second-level entities of the Soviet Union.
- Oblasts were first-level entities of the republics of the Soviet Union.
- Kis-Küküllő was an administrative county of the Kingdom of Hungary.
- Its territory is now in central Romania (central Transylvania).
- Kis-Küküllő is the Hungarian name for the Târnava Mică River.
- The capital of the county was "Dicsőszentmárton" (now Târnăveni).
- The oblasts of the Soviet Union were second-level entities of the Soviet Union.
- The oblasts of the Soviet Union were first-level entities of the republics of the Soviet Union.
- Motru Coal Mine is an open-pit mining exploitation.
- It is one of the largest in Romania.
- It is located in Motru, Gorj County.
- The legal entity managing the Motru mine is the National Company of Lignite Oltenia.
- The National Company of Lignite Oltenia was set up in 1997.

# Occupation of Gori

Occupation of Gori
- The Occupation of Gori was a military occupation of Gori and its surrounding areas.
- The occupation started on 13 August 2008.
- The occupation was part of the Russo-Georgian War.
- Russian military forces started the occupation.
- The occupation ended on 22 August 2008.
- Russian units withdrew from the city on 22 August 2008.

# Ofu Airport, American Samoa

Ofu Airport
- Ofu Airport is located one mile (2 km) southeast of the village of Ofu.
- Ofu Airport is located on the island of Ofu.
- Ofu Airport is located in American Samoa.
- American Samoa is an unincorporated territory of the United States.
- Ofu Airport is publicly owned by Government of American Samoa.

# Ottoman Empire History

Ottoman Empire
- The Ottoman Empire had Constantinople as its capital.
- The Ottoman Empire controlled lands around the Mediterranean basin.
- The Ottoman Empire was at the centre of interactions between the Eastern and Western worlds for six centuries.
- The Ottoman Empire gradually declined into the late nineteenth century.
- The Ottoman Empire allied with Germany in the early 20th century.
- The Ottoman Empire joined World War I to recover its lost territories.
- The Ottoman Empire joined World War I on the side of Germany and the Central Powers.
- The Ottoman Empire was struggling with internal dissent during World War I.
- The Ottoman Empire had an Arab Revolt in its Arabian holdings.
- The Ottoman government committed atrocities against the Armenians.
- The Ottoman government committed atrocities against the Assyrians.
- The Ottoman government committed atrocities against the Pontic Greeks.
- The Ottoman Empire's defeat resulted in the emergence of a new state, Turkey.
- The Ottoman
- Empire Sports Network was an American regional sports network.
- Empire Sports Network was owned by the Adelphia Communications Corporation.
- The network was available on cable providers in upstate New York.
- The network stretched from Buffalo to Albany.
- The network was available in parts of northern Pennsylvania.
- The network was available in parts of eastern Ohio.
- The network ceased operations on March 7, 2005.
- The network ceased operations in the midst of Adelphia's financial collapse and bankruptcy.
- The Occupation of the Ruhr was a period of military occupation.
- The Occupation of the Ruhr occurred between 1923 and 1925.
- The Occupation of the Ruhr was by France and Belgium.
- The Occupation of the Ruhr was in response to the Weimar Republic's failure to continue its reparation payments.
- The Occupation of the Ruhr was in the aftermath of World War I.
- The Occupation of the Ruhr was of the German Ruhr valley.
- Benito Mussolini's rise to power in Italy in 1922 brought profound changes to the colonial government in Eritrea.
- Benito Mussolini declared the birth of Italian Empire in May 1936.
- Italian Eritrea (enlarged with northern Ethiopia's regions) and Italian Somaliland were merged with the just conquered Ethiopia in the new Italian East Africa ("Africa Orientale Italiana") administrative territory.
- This Fascist period was characterized by imperial expansion in the name of a "new Roman Empire".
- After "il Duce" declared the birth of Italian Empire in May 1936.
- Eritrea was chosen by the Italian government to be the industrial center of Italian East Africa.
- After "il Duce" declared the birth of Italian Empire in May 1936, Italian Eritrea (enlarged with northern Ethiopia's regions) and Italian Somaliland were merged with the just conquered Ethiopia in the new Italian East Africa ("Africa Orientale Italiana") administrative territory.
- The Unwinding: An Inner History of the New America is a 2013 non-fiction book.
- The book is by the American journalist George Packer.
- The book uses biographies of individual Americans to discuss forces in American history from 1978 to 2012.
- The book discusses the subprime mortgage crisis.
- The book discusses the decline of American manufacturing.
- The book discusses the influence of money on politics.
- The book includes profiles of a Youngstown, Ohio factory worker turned community organizer.
- The book includes profiles of a biodiesel entrepreneur from North Carolina.
- The book includes profiles of a Washington lobbyist and Congressional staffer.
- The book
- The Independent Turkey Party is a nationalist and Kemalist political party.
- The Independent Turkey Party is abbreviated as BTP.
- The Independent Turkey Party was founded on 25 September 2001.
- The Independent Turkey Party was founded by Haydar Baş.

# Pak Tam Chung Area

Pak Tam Chung
- Pak Tam Chung is an area in the southern part of the Sai Kung Peninsula
- Pak Tam Chung is in the New Territories of Hong Kong
- Pak Tam Chung is administratively under the Sai Kung District
- Pak Tam Chung () is an area in the southern part of the Sai Kung Peninsula in the New Territories of Hong Kong.
- It is administratively under the Sai Kung District.
- The transfer of sovereignty over Hong Kong from the United Kingdom to China took place on 1 July 1997.
- The event is referred to as ``the Handover ''internationally.
- The event is referred to as ``the Return'' in China.
- The event marked the end of British administration in Hong Kong.
- The event is often regarded as the watershed of the British Empire.
- Hong Kong has a total area of .
- 3.16% of Hong Kong is water.
- 60 islands are dispersed around Hong Kong.
- Lantau Island is the largest island by area.
- Lantau Island is located Southwest of the main peninsula.
- Lantau Island and the majority of the remaining islands are part of the New Territories.
- Victoria Harbour is a natural landform harbour.
- Hong Kong Island is separated from Kowloon by Victoria Harbour.
- The Kowloon Peninsula to the south of Boundary Street was added to Colonial Hong Kong in 1860.
- The New Territories to the north of Hong Kong Island were added to Colonial Hong Kong in 18

# Pam Ferris, Actress

- Pamela E. Ferris was born on 11 May 1948.
- She is a British actress.
- She starred as Ma Larkin in The Darling Buds of May.
- She starred as Laura Thyme in Rosemary & Thyme.
- She played Miss Trunchbull in Matilda.
- She played Aunt Marge in Harry Potter and the Prisoner of Azkaban.
- She played Sister Evangelina in Call the Midwife.
- Sara Sidner is an American journalist.
- She is a correspondent for CNN.
- She is a correspondent for CNN International.
- She was based in Jerusalem starting August 2012.
- She was formerly in New Delhi.
- She currently works in CNN's Los Angeles bureau.
- Johanne Luise Heiberg was the wife of Johan Ludvig Heiberg.
- Johanne Luise was a popular and leading lady of the Danish stage.
- She wrote an autobiographical reflection of her life.
- She praised Kierkegaard for his insight into her art.
- Christel Khalil was born on November 30, 1987.
- Christel Khalil is 30 years old.
- Christel Khalil's occupation is actress.
- Christel Khalil is known for The Young and the Restless as Lily Winters (2002 -- present).
- Christel Khalil married Stephen Hensley in 2008.
- Christel Khalil and Stephen Hensley divorced in 2011.
- Christel Khalil has children.
- Christel Khalil was born in Los Angeles, California.
- Christel Adnana Mina Khalil is Christel Khalil's full name.
- Christel Khalil's years active are 1993 -- present.
- Christel Khalil's spouse was Stephen Hensley (married 2008, divorced 2011).
- Marie-France Pisier was a French actress.
- Marie-France Pisier was a screenwriter.
- Marie-France Pisier was a director.
- She appeared in numerous films of the French New Wave.
- She twice earned the national César Award for Best Supporting Actress.
- Marie-France Pisier (born 10 May 1944, died 24 April 2011).

# Pangasinan School of Arts Trades

- Pangasinan School of Arts and Trades is also referred to as PSAT.
- Pangasinan School of Arts and Trades is a government institution.
- Pangasinan School of Arts and Trades is of technical vocation education and training higher learning.
- Pangasinan School of Arts and Trades is located in Alvear Street, Lingayen, Pangasinan, Philippines.
- Pangasinan School of Arts and Trades is registered by the Technical Education and Skills Development Authority.
- All PSAT programs are accredited by the Technical Education and Skills Development Authority (TESDA).

# Pangi Territory

- Pangi Territory is in Maniema Province.
- Pangi Territory is an administrative area.
- The headquarters of Pangi Territory is the town of Pangi.
- Pangi Territory is in the Democratic Republic of the Congo.
- Swan Miara is a village.
- Swan Miara is a union council.
- Swan Miara is in Mansehra District.
- Swan Miara is in Khyber-Pakhtunkhwa province.
- Swan Miara borders Abbottabad District.
- It is located south of the district.
- Pangi Territory is an administrative area in Maniema Province of the Democratic Republic of the Congo.
- The headquarters is the town of Pangi.
- Kiri Territory is an administrative region.
- Kiri Territory is in the Mai-Ndombe District.
- Kiri Territory is in Bandundu Province.
- The headquarters of Kiri Territory is the town of Kiri.

# Party for the Netherlands

Party for the Netherlands is a Dutch right-wing Fortuynist political party.
Party for the Netherlands (PVN) was founded in August 2006.
Party for the Netherlands was founded by Hilbrand Nawijn.
Hilbrand Nawijn is a member of the Dutch House of Representatives.

# Penelope Tree Family

Penelope Tree
- Penelope Tree is the only child of Ronald and Marietta Peabody Tree.
- Ronald was a British journalist, investor and Conservative MP.
- Marietta Peabody Tree was a U.S. socialite and political activist.
- She is the great-granddaughter of Marshall Field.
- She is the great-granddaughter of Endicott Peabody.
- She is the half-sister of Jeremy Tree.
- She is the half-sister of Frances FitzGerald.
- She is a niece of Endicott Peabody.

# Personal Copying Exemptions

Copyright Infringement

- Some countries require content being copied to be obtained legitimately.
- The personal copying exemption in some countries requires content to be from authorized sources.
- The Netherlands previously allowed copying from file-sharing networks.
- The Dutch government had assumed the personal copying exemption applied to any copying, even from file-sharing networks.
- In April 2014, the Court of Justice of the European Union ruled against legislation that made no distinction between lawful and unlawful sources.
- Downloading from file-sharing networks is no longer legal in the Netherlands.

# Pesanggrahan Subdistrict

Pesanggrahan, South Jakarta
- Pesanggrahan is a subdistrict of South Jakarta.
- Pesanggrahan is part of the capital territory of Jakarta, Indonesia.
- The Pesanggrahan River flows along the eastern edge of Pesanggrahan Subdistrict.
- To the west of Pesanggrahan Subdistrict is Tangerang Regency, Banten Province.
- Pesanggrahan is one of the administrative city which forms the capital territory of Jakarta, Indonesia.
- Pesanggrahan is one of the administrative city which forms the capital territory of Jakarta, Indonesia.

# Peter Blum, Afrikaans Poet

Peter Emil Julius Blum
- Peter Emil Julius Blum was born on 4 May 1925.
- Peter Emil Julius Blum was born in Trieste, Kingdom of Italy.
- Peter Emil Julius Blum died on 5 December 1990.
- Peter Emil Julius Blum died in London, England, UK.
- Peter Emil Julius Blum was an Afrikaans poet.
- Peter Emil Julius Blum emigrated to the Union of South Africa with his family as a child.
- Peter Emil Julius Blum was able to speak several languages from an early age.
- Peter Emil Julius Blum spoke German.
- Peter Emil Julius Blum spoke Italian.
- Johan Ludvig Heiberg was born on 14 December 1791.
- Johan Ludvig Heiberg was born in Copenhagen.
- Johan Ludvig Heiberg was a Danish poet.
- Johan Ludvig Heiberg was a playwright.
- Johan Ludvig Heiberg was a literary critic.
- Johan Ludvig Heiberg was a literary historian.
- Johan Ludvig Heiberg died on 25 August 1860.
- Johan Ludvig Heiberg promoted Hegelian philosophy.
- Johan Ludvig Heiberg introduced vaudeville to Denmark.
- Johan Ludvig Heiberg was the son of Peter Andreas Heiberg.
- Johan Ludvig Heiberg was the son

# Peter Ostrum, Charlie Bucket

Peter Gardner Ostrum
- Peter Gardner Ostrum was born in November 1957.
- Peter Gardner Ostrum is American.
- Peter Gardner Ostrum is a veterinarian.
- Peter Gardner Ostrum played Charlie Bucket in Willy Wonka & the Chocolate Factory.
- Peter Gardner Ostrum’s only film role was in the 1971 motion picture Willy Wonka & the Chocolate Factory.
- The pronunciation of Ostrum is /ˈoʊstrəm/.
- Peter Gardner Ostrum’s pronunciation is /ˈpiːtər ˈoʊstrəm /.
- Peter Gardner Ostrum is a former child actor.
- You Were There for Me is a collaboration studio album.
- You Were There for Me is a collaboration studio album of Peter Rowan and Tony Rice.
- The record marks their first full-fledged cooperation.
- Peter Rowan and Tony Rice had previously appeared on several albums together.

# Pettai Village, Karaikal

Pettai
- Pettai is a panchayat village.
- Pettai is a revenue village.
- Pettai is in Pondicherry Union Territory, India.
- Pettai is under the Thirunallar Taluk.
- Pettai was formerly under the Thirunallar Commune Panchayat.
- Pettai is in Karaikal District, Pondicherry Union Territory.
- Pettai is situated on the banks of the Arasalar River.
- Pettai is to the west of Karaikal town.
- Pettai is south of Thirunallar.

# Philadelphia Eagles History

Philadelphia Eagles - History
- In 1940, the team moved from Philadelphia Municipal Stadium to Shibe Park.
- Lud Wray's half-interest in the team was purchased by Art Rooney.
- Art Rooney had just sold the Pittsburgh Steelers to Alexis Thompson.
- Bell / Rooney and Thompson swapped franchises.
- Bell / Rooney's entire Eagles' corporate organization moved to Pittsburgh.
- The Steelers' corporate name remained "Philadelphia Football Club, Inc." until 1945.
- Thompson's Steelers moved to Philadelphia.
- The NFL does not consider this a franchise move.
- The current Philadelphia Eagles are a single unbroken entity from 1933.
- The Philadelphia Brass is a touring professional brass quintet.
- The Philadelphia Brass is based in Philadelphia, Pennsylvania.
- The Philadelphia Brass is noted and acclaimed for its members' excellent musicianship and humorous dispositions.
- The Philadelphia Brass has performed in over 500 concerts.
- The Philadelphia Brass has toured internationally.
- The Philadelphia Brass has toured throughout the United States of America.
- The Philadelphia Brass has given numerous clinics and master classes.
- The Philadelphia Brass is committed to public education.
- The Philadelphia Brass has coached musicians of all ages.
- Each member of The Philadelphia Brass is a noted music educator.
- Scott Petri was born in 1960.
- Scott Petri was a member of the Pennsylvania House of Representatives.
- Scott Petri was the Chairman of House Urban Affairs.
- Scott Petri was the Chairman of the House Ethics Committee.
- Scott Petri served as a member of the Liquor Control Committees.
- Scott Petri currently serves as executive director of the Philadelphia Parking Authority.
- William Perry was born on December 16, 1962.
- William Perry's date of birth is 1962 - 12 - 16.
- William Perry is 6 ft 2 in (1.88 m) tall.
- William Perry weighs 159 kg (350 lb).
- William Perry attended Clemson.
- William Perry was drafted in 1985, Round: 1, Pick: 22.
- William Perry played for the Chicago Bears (1985 -- 1993).
- William Perry played for the London Monarchs (1996).
- William Perry

# Philae Lander Mission

- The lander is named after the Philae obelisk.
- The Philae obelisk bears a bilingual inscription.
- The Philae obelisk was used to decipher Egyptian hieroglyphs.
- "Philae" was monitored from DLR's Lander Control Center in Cologne, Germany.
- Ulrich Walter was selected to join the German astronaut team in 1987.
- Ulrich Walter completed basic training at the German Aerospace Center from 1988 to 1990.
- Ulrich Walter was nominated to be in the prime crew for the second German Spacelab mission.
- Ulrich Walter held two post-doc positions at the Argonne National Laboratory, Chicago, Illinois.
- Ulrich Walter held a post-doc position at the University of California at Berkeley, California.

# PIAS Recordings

- In 2000, the label moved from Brussels to London.
- The label was renamed [PIAS] Recordings.
- [PIAS] Recordings released the first two albums by Sigur Rós.
- Mogwai signed to PIAS in 2001.

# Piping Technology and Products

Piping Technology and Products is privately owned.
Piping Technology and Products is a pipe support manufacturing and engineering company.
Piping Technology and Products is headquartered in Houston, Texas.
Piping Technology and Products is located in the United States.
US Bellows is a wholly owned subsidiary of Piping Technology and Products.
Sweco Fab is a wholly owned subsidiary of Piping Technology and Products.
Fronek Anchor/Darling Enterprise is a wholly owned subsidiary of Piping Technology and Products.
Pipe Shields is a wholly owned subsidiary of Piping Technology and Products.
Companies provide pipe supports.
Companies provide expansion joints.
Companies provide shock and vibration controls.
Companies provide pre-insulated supports.
Industries served include LNG.
Industries served include chemical.
Industries served include petrochemical.
Industries served include pulp & paper.
Industries served include aerospace.

# Pirate Party Belgium

Pirate Party (Belgium)
- The Pirate Party of Belgium is a political party in Belgium.
- It is based on the model of the Swedish Pirate Party.
- It supports reform of copyright law.
- It supports the abolition of patents.
- It supports respect for privacy.
- It was a founding member of Pirate Parties International.
- The Green Party of Tennessee is a state-level political party in Tennessee.
- It is a member of the Green Party of the United States.
- The party formed in 2001.

# Pittsburgh Youth Symphony Orchestra

Pittsburgh Youth Symphony Orchestra
- It is one of the oldest youth orchestra programs in the United States.
- It performed its first concert in 1945.
- The first concert was under the direction of Stanley H. Levin.
- The first concert was at Carnegie Music Hall.
- The first concert was in the Oakland neighborhood of Pittsburgh, PA.
- The idea originated with student musicians in the Music Festival of the In-and-About Pittsburgh Music Educators Club.
- It is often represented by its initials, PYSO.
- Members, alumni and supporters affectionately pronounce “PYSO” as “Pie-So”.

# Planet Cake Couture Cakes

Planet Cake
- Planet Cake has created over 12000 couture cakes.
- Planet Cake has created cakes for Nicole Kidman.
- Planet Cake has created cakes for Celine Dion.
- Planet Cake has created cakes for Rihanna.
- Planet Cake has created cakes for Katy Perry.
- Planet Cake has created cakes for Keith Urban.
- Planet Cake has created cakes for John Travolta.
- Planet Cake has created cakes for Lady Gaga.
- Planet Cake has created cakes for television.
- Planet Cake has created cakes for many magazines.
- Planet Cake has created a host of ‘stunt’ cakes.
- Planet Cake created a realistic replica of the Sydney Opera House for Australia Day 2011.
- The Sydney Opera House replica weighed over 1.3 tons.
- 32 cake decorators were required to make the Sydney Opera House replica.

# Plansee SE Corporation

Plansee SE
- Plansee SE is a corporation.
- Plansee SE’s head office is in Reutte, Austria.
- Plansee SE is a fully owned division of the Plansee Group.
- Plansee SE is a privately owned company.
- Plansee SE manufactures products based on high-performance materials.
- These materials are made from refractory metals.
- Refractory metals include molybdenum, tungsten, tantalum, niobium, chromium and their alloys.
- Plansee SE’s products are used in the lighting sector.
- Plansee SE’s products are used in the electronics sector.
- Plansee SE’s products are used in the medical sector.
- Plansee SE’s products are used in the coatings sector.
- Plansee SE’s products are used in the energy transmission and distribution sector.
- Plansee SE’s products are used in the system and furnace construction sectors.

# Porno Graffitti (band)

Porno Graffitti is a Japanese rock band
Porno Graffitti is from Onomichi, Hiroshima Prefecture, Japan
Porno Graffitti was formerly from Innoshima
Porno Graffitti got their name from the album "Pornograffitti" by the band Extreme
Porno Graffitti records under the SME Records label
Porno Graffitti's agency is Amuse, Inc.

# Port Blair, Andaman Islands

Port Blair
- Port Blair is the capital of the Andaman and Nicobar Islands.
- Port Blair is a union territory of India.
- Port Blair is situated in the Bay of Bengal.
- Port Blair is the local administrative sub-division (tehsil) of the islands.
- Port Blair is the headquarters for the district of South Andaman.
- Port Blair is the territory's only notified town.
- Port Blair houses the headquarters of the Andaman and Nicobar Police.
- Port Blair houses the headquarters of the Andaman and Nicobar Command.
- The Andaman and Nicobar Command is the first integrated tri-command of the armed forces of India.
- Port Blair (pronunciation (help info))
- The first integrated tri-command of the armed forces of India.
- The Citizen is a newspaper.
- The Citizen is based in Juba.
- Juba is the national capital of South Sudan.
- Juba is the state capital of Central Equatoria.
- The Citizen is based in Juba, the national capital of South Sudan and the state capital of Central Equatoria.
- Jirania is a small town in Tripura state of India.
- Jirania is on the banks of river Saidra.
- Jirania is a nagar panchayat.
- Jirania is the headquarters of Jirania Rural Development Block.
- Jirania is located in Sadar sub-divisions of West Tripura district.
- Jirania has 3 major high schools.
- Jirania's market is of great importance for the local business and its sustainence.
- Jirania lies on the National Highway 44 (Assam-Agartala Highway) of India.

# Premier League Broadcasts

Premier League
- The Premier League is popular in Asia.
- It is the most widely distributed sports programme in Asia.
- Fox Sports broadcasts almost all of the season's 380 matches live in Australia.
- Foxtel gives subscribers the option of selecting which Saturday 3pm match to watch.
- The matches are broadcast live on STAR Sports in India.
- Super Sports was awarded the broadcast rights in China.
- The six-year agreement in China began in the 2013–14 season.
- Sportsnet and TSN jointly own the Canadian broadcast rights.
- Both Sportsnet and TSN hold rights to 190 matches per season in Canada.
- The "Hockey Night in Canada" brand is owned by the CBC.
- CBC Sports exclusively used the "Hockey Night in Canada" brand through the end of the 2013–14 NHL season.
- Beginning in the 2014–15 NHL season, the "Hockey Night in Canada" brand is being licensed to Rogers Communications.
- Sportsnet-produced Saturday NHL broadcasts air on CBC Television.
- Sportsnet-produced Saturday NHL broadcasts also air on City and Sportsnet networks.
- Rogers Communications secured exclusive national multimedia rights to NHL games beginning in 2014–15.
- Rogers sublicensed Saturday night and playoff games to CBC.
- The sub-
- CBS will broadcast Super Bowl LIII.
- Super Bowl LIII is part of an annual cycle between the three main broadcast television partners of the NFL.
- Whitefield Park was a football ground in Cambuslang, Scotland.
- It was the home ground of Cambuslang F.C.
- Cambuslang F.C. used Whitefield Park between 1888 and 1897.
- Cambuslang F.C. played two seasons in the Scottish Football League at Whitefield Park.
- Regillio Simons started playing football at FC Amstelland.
- He played for SC Telstar, Fortuna Sittard, NAC, Willem II (football club), Kyoto Purple Sanga (Japan), ADO Den Haag and TOP Oss.
- In the 1998–99 season he had a big contribution with two goals in the 1–3 victory over Ajax in Amsterdam Arena.
- In that same year he scored four times in the 6–4 home win against PSV Eindhoven.
- After his professional career he defended several years the colors of FC Türkiyemspor, an Amsterdam amateur club playing in the top Sunday league.
- From summer 2008 he played for
- Llanberis F.C. are a Welsh football club.
- Llanberis F.C. currently play in the Welsh Alliance League Division 1.
- Their ground is located in the centre of the village.
- Their nickname is Y Darans.
- Bisley F.C. was based in Bisley in Surrey Heath, Surrey, England.
- Bisley F.C. played from 2001 in part of the Hellenic Football League.
- Bisley F.C. played until the 2009–10 season.
- Its players agreed to join the Farnborough F.C. Reserves.
- Bisley F.C. permitted Farnborough F.C. to takeover its "Lion Park" grounds.
- Bisley F.C. permitted Farnborough F.C. to takeover its position in the league.
- The site is used as Farnborough F.C.'s football academy and elite development centre.
- The Melbourne Football Club is nicknamed the Demons.
- The Melbourne Football Club plays in the Australian Football League (AFL).
- It plays its home games at the Melbourne Cricket Ground (MCG).
- Kynoch Park is a football ground in Keith.
- Kynoch Park is located in the north-east Scotland.
- Kynoch Park is the home ground of Keith F.C..
- Kynoch Park is located on Balloch Road.
- Kynoch Park has a capacity of 4,000.
- Kynoch Park has 370 seated.
- Dudley Road was a football ground in Wolverhampton in England.
- It was the home ground of Wolverhampton Wanderers between 1881 and 1889.
- It was used during the first season of the Football League.
- The Rabat Ajax Football Ground is the training ground of Maltese football team Rabat Ajax F.C.
- It is located in the town of Mtarfa.
- Mosset Park is a football ground in the town of Forres in the north-east of Scotland.
- It is the home ground of Highland Football League side Forres Mechanics F.C..
- It is located on Lea Road in the north of the town.
- It has a capacity of 2,700.
- It has 502 seated.
- Ernie Watts was born in Woolhampton in Berkshire.
- His earliest known club was Reading.
- He made 17 appearances in The Football League for Notts County.
- He was captain for West Ham United's final season at the Memorial Grounds.
- He joined New Brompton in 1904.
- He was a regular starter for New Brompton during the 1904–05 season.
- His later clubs included Grays Athletic and Clapton Orient.
- He had two more spells with Reading.

# Prince Kinsky of Wchinitz and Tettau

- Ulrich, 10th Prince Kinsky of Wchinitz and Tettau (; 15 August 189319 December 1938) was the titular pretender Prince Kinsky of Wchinitz and Tettau.
- Ulrich was born on 15 August 1893.
- Ulrich died on 19 December 1938.
- Ulrich was the titular pretender Prince Kinsky of Wchinitz and Tettau.
- The Ulrich Walser House is located at 711 North 2nd Street in Alma, Wisconsin, United States.
- The Ulrich Walser House was constructed in 1895 by Ulrich Walser.
- The Ulrich Walser House was placed on the National Register of Historic Places in 1982.
- Ulrich Joseph Franzen (January 15, 1921 – October 6, 2012) was a German-born American architect.
- Ulrich Joseph Franzen was known for his "fortresslike" buildings.
- Ulrich Joseph Franzen was known for his Brutalist style.
- Daniel Bremer Juell was born in Siljord in 1808.
- Daniel Bremer Juell’s father was district stipendiary magistrate ("sorenskriver") Ole Juell.
- Daniel Bremer Juell’s mother was Caroline Kathrine née Bremer.
- Daniel Bremer Juell married Caroline Boeck.
- Caroline Boeck was the daughter of captain Cæsar Boeck.
- Daniel Bremer Juell and Caroline Boeck had three children.

# Rashad Family Members

Phylicia Rashād is an actress.
Phylicia Rashād is a director.
Phylicia Rashād is a singer.
Debbie Allen is Phylicia Rashād’s older sister.
Debbie Allen is married to Norm Nixon.
Norm Nixon is a former NBA basketball player.
Phylicia Rashād was married to Victor Willis.
Victor Willis is a former lead singer of the group Village People.
Phylicia Rashād was married to Ahmad Rashād.
Ahmad Rashād is a former NFL football player.
Ahmad Rashād is a sportscaster.
Phylicia Rashād and Ahmad Rashād are the parents of Condola Rashād.
Condola Rashād is an actress.
- Morris Mike Medavoy was born January 21, 1941.
- Mike Medavoy is an American film producer.
- Mike Medavoy is an American film executive.
- Mike Medavoy is a co-founder of Orion Pictures (1978).
- Mike Medavoy was former chairman of TriStar Pictures.
- Mike Medavoy was former head of production for United Artists (1974–1978).
- Mike Medavoy is current chairman and CEO of Phoenix Pictures.
- Marshall Eriksen is a How I Met Your Mother character.
- Marshall Eriksen had a first appearance in ``Pilot``.
- Marshall Eriksen had a last appearance in ``Last Forever``.
- Marshall Eriksen was created by Carter Bays and Craig Thomas.
- Marshall Eriksen was portrayed by Jason Segel.
- Marshall Eriksen’s father is Marvin Eriksen (deceased).
- Marshall Eriksen’s mother is Judy Eriksen.
- Marshall Eriksen is married to Lily Aldrin (2007 -- present).
- Marshall Eriksen has children Marvin Waitforit Eriksen, Daisy Eriksen, and an unnamed third child.
- Marshall Eriksen is American.
- Marshall Eri
- Andrea Kremer was born February 25, 1959 in Philadelphia, Pennsylvania.
- Andrea Kremer is an American television sports journalist.
- Andrea Kremer has won multiple Emmy Awards.
- Andrea Kremer currently calls "Thursday Night Football" games for Amazon Prime Video.
- Andrea Kremer is the first all-women booth to call any major men's team sport, not just football.
- Andrea Kremer is Chief Correspondent for the NFL Network.
- Andrea Kremer previously led the network's coverage and in-depth reporting on health and safety.
- Andrea Kremer is a correspondent for HBO's "Real Sports with Bryant Gumbel".
- Andrea Kremer
- Meg Griffin is a Family Guy character.
- Meg Griffin first appeared in 1998.
- Meg Griffin first appeared in ``Pilot Pitch of Family Guy (Early version)``.
- Meg Griffin first appeared in ``Death Has a Shadow ``(Official version).
- Meg Griffin was created by Seth MacFarlane.
- Meg Griffin was voiced by Lacey Chabert (1999 -- 2000, 2011, 2012).
- Meg Griffin was voiced by Mila Kunis (1999 -- present).
- Meg Griffin was voiced by Tara Strong (singing voice).
- Meg Griffin is a high school student.
- Meg Griffin
- Angelica Sue Page is an American actress.
- Angelica Sue Page is an American director.
- Angelica Sue Page is an American producer.
- Angelica Sue Page is an American screenwriter.
- Angelica Sue Page (née Torn)
- Angelica Page legally and professionally changed her name in September 2011.
- Rip Torn is Angelica Page’s father.
- Geraldine Page is Angelica Page’s mother.
- Angelica was credited as Angelica Torn in her early career.
- Angelica Page was born February 17, 1964.
- Melissa Reeves was born March 14, 1967.
- Melissa Reeves’s other names are Melissa Brennan, Missy Brennan, Melissa B. Reeves, and Melissa Brennan Reeves.
- Melissa Reeves’s occupation is actress.
- Melissa Reeves has been active since 1983.
- Melissa Reeves married Scott Reeves in 1990.
- Melissa Reeves has children.

# RCBC Plaza Design & Construction

RCBC Plaza
- The RCBC Plaza was designed by Skidmore, Owings & Merrill, LLP.
- Skidmore, Owings & Merrill, LLP cooperated with W.V. Coscolluela & Associates.
- The structural design was provided by Skilling Ward Magnusson Barkshire.
- Skilling Ward Magnusson Barkshire cooperated with R.S. Caparros Associates & Company.
- Project management services was provided by Bovis Lend Lease.
- Construction management works were provided by Pacific Orient Consultants & Management, Inc.
- The Main Contractor was ECW Joint Venture.
- ECW Joint Venture consisted of EEI Corporation (Philippines).
- ECW Joint Venture consisted of Concrete Constructions (Australia).
- ECW Joint Venture consisted of Walter Bau (Germany).
- ECW JV self performed the superstructure construction works.
- EEI Corporation is a part of the Yuchengco Group of Companies.

# Richmond Area Employers

Richmond, Virginia
- Other Fortune 500 companies have a major presence in the area.
- SunTrust Bank is based in Atlanta.
- Capital One Financial Corporation is officially based in McLean, Virginia.
- Capital One was founded in Richmond.
- Capital One has its operations center in the Richmond area.
- Capital One has most of its employees in the Richmond area.
- McKesson is based in San Francisco.
- Capital One and Philip Morris USA are two of the largest private Richmond-area employers.
- DuPont maintains a production facility in South Richmond.
- The production facility is known as the Spruance Plant.
- UPS Freight has its corporate headquarters in Richmond.
- UPS Freight is the less-than-truckload division of UPS.
- UPS Freight was formerly known as Overnite Transportation.
- WKHK is a Country formatted broadcast radio station.
- WKHK is licensed to Colonial Heights, Virginia.
- WKHK serves Richmond and Petersburg in Virginia.
- WKHK is owned and operated by SummitMedia.
- WKHK's studios and offices are located west of Richmond proper in unincorporated Chesterfield County.
- WKHK's transmitter is located in Bensley, Virginia.

# Ring Road (Afghanistan)

Highway 1 (Afghanistan)
- National Highway 01 is formally called the Ring Road.
- National Highway 01 is also known as NH01.
- It is an ancient two-lane road network inside Afghanistan.
- It connects Kabul, Maidan Shar, Ghazni, Kandahar, Delaram, Herat, Maymana, Sheberghan, Mazari Sharif, and Puli Khumri (clockwise).
- It was originally built and renovated by the Mauryan Empire.
- It was a part of the Grand Trunk Road project.
- It was well documented by Greek and Buddhist sources in the 4th century BCE.
- It was renovated by Sher Shah Suri.
- It was renovated by the Mughal Empire.
- It was renovated by the British Empire.
- It has extensions that connect Jalalabad.
- It has extensions that connect Bamyan.
- It has extensions that connect Khost

# Rock Climbing's Origins

Rock climbing was an important component of Victorian mountaineering in the Alps.
Rock climbing began in the last quarter of the 19th century.
Rock climbing began in the Elbe Sandstone Mountains near Dresden.
Rock climbing began in the north of England.
Rock climbing began in the Peak district.
Rock climbing began in the Lake District.
Rock climbing began in the Dolomites in Italy.
Rock climbing evolved gradually from an alpine necessity to an athletic sport.
It is imprudent to cite a primogenitor of rock climbing in each of the three locales.
There is some general agreement on the following facts.
- As of 2017, 22 performers have been inducted twice or more.
- Fourteen performers have been recognized as a solo artist and with a band.
- Seven performers have been inducted with two separate bands.
- Eric Clapton is the only one to be inducted three times.
- Clyde McPhatter was the first to ever be inducted twice.
- Clyde McPhatter is one of three artists to be inducted first as a solo artist and then as a member of a band.
- Neil Young is one of three artists to be inducted first as a solo artist and then as a member of a band.
- Rod Stewart is one of three artists to be inducted first as a

# Rohana Wijeweera

Rohana Wijeweera
- Rohana Wijeweera was born on 14 July 1943.
- Rohana Wijeweera died on 13 November 1989.
- Rohana Wijeweera was a Sri Lankan Marxist politician.
- Rohana Wijeweera was a revolutionary.
- Rohana Wijeweera was the founding leader of the Janatha Vimukthi Peramuna.
- Rohana Wijeweera led the party in two unsuccessful insurrections in Sri Lanka.
- The insurrections occurred in 1971 and 1987 to 1989.
- Rohana Wijeweera's name is also written as Patabendi Don Jinadasa Nandasiri Wijeweera.
- Dimuthu Bandara Abayakoon is a Sri Lankan politician.
- Dimuthu Bandara Abayakoon belongs to the Janatha Vimukthi Peramuna.
- Dimuthu Bandara Abayakoon was born on September 6, 1971.
- Dimuthu Bandara Abayakoon was elected as a representative of Kandy District in the Parliament of Sri Lanka in the 2004 election.
- Dimuthu Bandara Abayakoon stood as a United People's Freedom Alliance candidate.
- Dimuthu Bandara Abayakoon resides in Kandy.

# RuPaul Andre Charles

RuPaul Andre Charles was born on November 17, 1960.
RuPaul is known professionally by the mononym RuPaul.
RuPaul is an American actor.
RuPaul is a drag queen.
RuPaul is a television personality.
RuPaul is a singer / songwriter.
RuPaul has produced the reality competition series RuPaul's Drag Race since 2009.
RuPaul has hosted RuPaul's Drag Race since 2009.
RuPaul received two Primetime Emmy Awards for RuPaul's Drag Race.

# Sam's Casting Challenges

Casablanca (film)
* Dooley Wilson played Sam.
* Dooley Wilson was one of the few American-born members of the cast.
* Dooley Wilson had to fake playing the piano.
* Wallis considered dubbing over Dooley Wilson's voice for the songs.
* Wallis considered changing the character to a woman.
* Wallis considered casting Hazel Scott.
* Wallis considered casting Lena Horne.
* Wallis considered casting Ella Fitzgerald.

# Sant Martí d'Empúries

Sant Martí d'Empúries
- Sant Martí d'Empúries is an entity of the town of L'Escala.
- It is located next to the ruins of Empúries or Empòrion.
- Ancient Greeks established the settlement in the 6th century BC.
- It was the county seat until 1079.
- Empúries moved to Castelló d'Empúries in 1079.
- Empúries moved to Castelló d'Empúries place less exposed to attack.

# Saulkrasti Municipality

Saulkrasti Municipality
- Saulkrasti Municipality is in Vidzeme, Latvia.
- The municipality was formed in 2009.
- The municipality was formed by reorganization of Saulkrasti town with its countryside territory.
- The administrative centre of the municipality is Saulkrasti.
- In 2010 Saulkrasti parish was created.
- Saulkrasti parish was created from the countryside territory of Saulkrasti town.
- Hylestad is in Aust-Agder county, Norway.
- Hylestad is in the southern part of the present-day municipality of Valle.
- Hylestad is in the traditional region of Setesdal.
- Hylestad existed from 1915 until 1962.
- The administrative centre was the village of Rysstad.
- The Hylestad Church was located in Rysstad.
- Saulkrasti Municipality () is a municipality in Vidzeme, Latvia.
- The municipality was formed in 2009 by reorganization of Saulkrasti town with its countryside territory, with the administrative centre being Saulkrasti.
- In 2010 Saulkrasti parish was created from the countryside territory of Saulkrasti town.
- Steinshamn is the administrative centre of Sandøy Municipality.
- Steinshamn is in Møre og Romsdal county, Norway.
- The village is located at the northern end of the island of Harøya.
- There is a causeway that connects Steinshamn to the neighboring island of Finnøya to the northeast.

# Scariest Places on Earth (TV series)

Scariest Places on Earth
- Scariest Places on Earth is an American paranormal reality television series.
- The show originally aired from October 23, 2000, to October 29, 2006.
- It originally aired on Fox Family.
- It later aired on ABC Family.
- The show was hosted by Linda Blair.
- Zelda Rubinstein provided narration.
- The show featured reported cases of the paranormal.
- The show detailed the location's history.
- The show sent an ordinary family to visit the location in a reality TV-style vigil.

# Schlage Locks

Schlage
- Schlage was founded in 1920 by Walter Schlage.
- Schlage is a lock manufacturer.
- Schlage was headquartered in San Francisco from its inception.
- Schlage relocated to Colorado Springs, Colorado in 1997.
- Schlage produces Primus key and cylinder lines.
- Schlage produces Everest key and cylinder lines.
- Schlage produces Everest Primus XP key and cylinder lines.
- Schlage is a popular brand of consumer and commercial locks in the United States.
- Medical Center of the Rockies is located in Loveland, Colorado.
- Medical Center of the Rockies is a sister hospital of Poudre Valley Hospital.
- Poudre Valley Hospital is located in Fort Collins, Colorado.
- Both Medical Center of the Rockies and Poudre Valley Hospital are operated by UCHealth.
- Medical Center of the Rockies is home to a regional heart center.
- Open heart surgery is performed at Medical Center of the Rockies.
- Medical Center of the Rockies is home to a regional neurosciences center.
- Medical Center of the Rockies cares for victims of head and back injury.
- Medical Center of the Rockies cares for victims of stroke.
- Medical Center of the Rockies cares for victims of

# School's Out (song)

- School's Out is a 1972 song
- School's Out is the title track single of Alice Cooper's fifth album
- The song was written by Alice Cooper, Michael Bruce, Glen Buxton, Dennis Dunaway and Neal Smith

# Season 5 Cast Members

Saturday Night Live (season 5)
- Lorne Michaels upgraded writers to featured cast member status.
- Peter Aykroyd joined the cast.
- Jim Downey joined the cast.
- Brian Doyle-Murray joined the cast.
- Don Novello joined the cast.
- Tom Schiller joined the cast.
- Alan Zweibel joined the cast.
- Paul Shaffer joined the cast.
- Paul Shaffer became the first person from the "SNL" band to become a cast member.
- Harry Shearer joined the show as a featured cast member.
- Harry Shearer was promoted to repertory status during the season.
- Brittany Petros was born September 9, 1974.
- Brittany Petros is an American actress.
- Brittany Petros is an American producer.
- Brittany Petros is an American television personality.
- Brittany Petros first rose to fame as a cast member on the first season of the reality-television competition "Big Brother" (2000).
- Brittany Petros has appeared as an actress in various roles.
- Brittany Petros has done extensive work in production and casting roles.
- Rob Kardashian is mentioned.
- Kris Jenner is mentioned.
- Bruce Jenner (now known as Caitlyn Jenner) is mentioned.
- Kendall and Kylie Jenner are mentioned.
- Scott Disick is mentioned.
- Lamar Odom developed a major position as part of the supporting cast in the fourth season.
- Lamar Odom was not a regular cast member in following seasons.
- Lamar Odom rarely appeared in season eight while attempting to fix his marriage with Khloé.
- Kanye West became a recurring cast members after dating Kim then marrying her in season nine.
- Caitlyn's children Brody and Brandon, and Brandon's wife, Leah became recurring cast members in seasons eight and nine.
- Paul Bohill is a cast member.
- Steve Pinner is a cast member.
- Mike Allonby is a cast member.
- Terry Jones is a cast member.
- Steve Wood is a cast member.
- Mike Allonby died aged 47 at his home in Wales.
- Terry Jones only appeared in the first series.
- Steve Wood only appeared in the first series.
- Bohill and Pinner appeared in series two.
- Episodes four and five placed at second and third, respectively.
- The first three episodes became the most watched programme on the channel that week.
- The sixth season of ``Basketball Wives LA ''was confirmed by VH1.
- The sixth season of ``Basketball Wives LA ''has a premiere date of April 17, 2017.
- Filming started in October 2016.
- Evelyn Lozada returned as a former cast member.
- Jennifer Williams was spotted filming with cast member Tami Roman.
- Aja Metoyer is a new cast member.
- Keonna Green is a new cast member.
- Bonnie - Jill Laflil is a new cast member.
- Angel Brinks is a departing cast member.
- LaTosha Duffey is a departing cast member.
- Angel Love
- Season six is the final season for original cast members Chad Michael Murray and Hilarie Burton.
- Their characters, Lucas and Peyton, leave Tree Hill with their newborn baby in the finale.

# Shiromaniam Madhavan

Shiromaniam Madhavan
- Shiromaniam Madhavan (1944 - 29 June 1994)
- He was the son of a founding member of the National Federation Party (NFP).
- He served in the Labasa Town Council.
- He served in the House of Representatives.
- He contested numerous elections for different political parties.

# Sicilian Pizza Characteristics

Sicilian pizza
- Sicilian pizza originated in Sicily, Italy.
- Sicilian pizza is also known as "sfincione" or focaccia with toppings.
- In the United States, "Sicilian pizza" is often synonymous with thick-crust pizza.
- This type of pizza became popular in western Sicily by the mid-19th century.
- It was the type of pizza usually consumed in Sicily until the 1860s.
- The version with tomatoes was not available prior to the 17th century.
- It reached North America in a slightly altered form.
- It has a thicker crust.
- It has a rectangular shape.
- Pizza Hut is an American restaurant chain.

# SICRAL 1B Satellite

SICRAL 1B
- It is a military communications satellite
- It was built by Thales Alenia Space
- It was built for Italian Armed Forces
- It is a dual-use spacecraft
- Telespazio will use some of its transmission capacity
- The Italian defense ministry will use some of its transmission capacity
- NATO will use some of its transmission capacity
- It is based on the Italsat 3000 bus
- It includes one EHF/Ka band transponder
- It includes three UHF-band transponders
- It includes five active SHF-band transponders
- It is designed to be operable for 13 years
- Commer was a British manufacturer of commercial vehicles from 1905 until 1979.
- Commer vehicles included car-derived vans, light vans, medium to heavy commercial trucks, military vehicles and buses.
- The company also designed and built some of its own diesel engines for its heavy commercial vehicles.

# Sjernarøy (Municipality)

- Sjernarøy is a former municipality in Rogaland county, Norway.
- Sjernarøy existed from 1868 until 1965.
- Sjernarøy was located in the Boknafjorden.
- Sjernarøy was in the present-day municipality of Finnøy.
- The administrative centre was on the island of Kyrkjøy.
- The Sjernarøy Church is located on the island of Kyrkjøy.

# SMECO Electric Cooperative

Southern Maryland Electric Cooperative
- The Southern Maryland Electric Cooperative is an electric distribution cooperative.
- The Southern Maryland Electric Cooperative is headquartered in Hughesville, Maryland.
- SMECO serves approximately 161,000 customers.
- SMECO serves Calvert County.
- SMECO serves Charles County.
- SMECO serves Prince George's County.
- SMECO serves St. Mary's counties of southern Maryland.
- SMECO is a nonprofit cooperative.
- SMECO passes on its costs to its customer-members without markup or profit.
- Southern California Edison is a subsidiary of Edison International.
- Southern California Edison provides electricity to 14 million people.
- Southern California Edison’s service territory is approximately 50,000 square miles.
- The Los Angeles Department of Water and Power serves portions of southern California.
- San Diego Gas & Electric serves portions of southern California.
- Imperial Irrigation District serves portions of southern California.
- Pacific Gas & Electric Company of San Francisco serves the northern part of the state.
- Hughesville is a census-designated place (CDP) in Charles County, Maryland, United States.
- The population of Hughesville was 2,197 at the 2010 census.
- Truman's Place was listed on the National Register of Historic Places in 1988.

# SModcast Pictures

- SModcast Pictures is an American film distribution company.
- SModcast Pictures is a film and television production company.
- Kevin Smith founded SModcast Pictures in 2011.
- Kevin Smith announced at the 2011 Sundance Film Festival that he would release "Red State" under SModcast Pictures.
- Kevin Smith planned to tour "Red State" instead of having a traditional release.
- Yankovic and Levey wrote the film.
- The film was written after Yankovic's second studio album.
- The film aimed to apply Yankovic's parody and comedy to film.
- George was portrayed as a straight man with a vivid imagination.
- The film included parodies.
- They struggled to find a film production company for financing.
- Orion Pictures supported the film.
- They stated they could keep the film costs under $5 million.
- Principal filming took place around Tulsa, Oklahoma.
- Many extras were from the Tulsa and Dallas, Texas areas.
- David Copperfield is an illusionist.
- David Copperfield played the character The Magician in the 1980s horror film Terror Train.
- David Copperfield had an uncredited appearance in the 1994 film Prêt - à - Porter.
- Most of David Copperfield's media appearances have been through television specials and guest spots on television programs.
- David Copperfield made the Learjet disappear in 1981.
- David Copperfield made the Statue of Liberty vanish and reappear in 1983.
- David Copperfield levitated over the Grand Canyon in 1984.
- David Copperfield walked through the Great Wall of China in
- Passion Pictures' core business is in commercial and animation output.
- Passion Pictures has done work for Cartoon Network.
- Passion Pictures has created music videos for Gorillaz.
- Passion Pictures created the Compare the Market.com commercial campaign featuring Aleksandr Orlov (meerkat).
- Passion Australia produced "The Lost Thing".
- Andrew Ruhemann directed "The Lost Thing".
- Shaun Tan directed "The Lost Thing".
- "The Lost Thing" won an Academy Award for Best Animated Short Film in 2011.
- Trotta is a 1971 West German film.
- Johannes Schaaf directed Trotta.
- Trotta is based on the 1938 novel "Die Kapuzinergruft" ("The Emperor's Tomb").
- Joseph Roth wrote "Die Kapuzinergruft" ("The Emperor's Tomb").
- Trotta was West Germany's official submission to the 45th Academy Awards for Best Foreign Language Film.
- Trotta did not receive a nomination for the 45th Academy Awards.
- Trotta was entered into the 1972 Cannes Film Festival.
- Dana MacDuff and Brandon R. MacDuff are brothers.
- Brandon R. MacDuff was born in 1954.
- Brandon R. MacDuff graduated from Blair High School in 1972.
- Dana MacDuff and Brandon R. MacDuff have formed Oakdale Pictures.
- Oakdale Pictures is a production company in Reno.

# Snow White Characters

Snow White and the Huntsman
- Kristen Stewart is Snow White
- Raffey Cassidy is young Snow White
- Chris Hemsworth is Eric the Huntsman
- Charlize Theron is Queen Ravenna
- Izzy Meikle - Small is young Ravenna
- Sam Claflin is William
- Sam Spruell is Finn
- Elliot Reeve is young Finn
- Vincent Regan is Duke Hammond
- Lily Cole is Greta
- Noah Huntley is King Magnus
- Liberty Ross is Queen Eleanor
- Chris Obi is the voice of Mirror Man
- Rachael Stirling is Anna
- Hattie Gotobed is Lily
- Greg Hicks is Black Knight
- Peter Ferdinando is Black Knight
- Anastasia Hille is Ravenna's Mother
- Beauty and the Beast was resurrected as a project for a satellite animation studio in London, England.
- The project was for the satellite animation studio working on Who Framed Roger Rabbit.
- Richard Williams declined to direct Beauty and the Beast.
- Richard Williams recommended Richard Purdum to direct.
- Don Hahn produced Beauty and the Beast.
- The original version of Beauty and the Beast was non-musical.
- The original version of Beauty and the Beast was set in 19th-century France.
- Michael Eisner was the Disney CEO.
- Beauty and the Beast was the first Disney animated film to use a screenwriter.
- Linda Woolverton wrote the original draft of the story.
- Emma Snyder is an As the World Turns character.
- Kathleen Widdoes portrayed Emma Snyder.
- Emma Snyder first appeared in July 1985.
- Emma Snyder last appeared on June 29, 2010.
- Emma Snyder is a farmer.
- Emma Snyder resides at The Snyder Farm RR # 2, Box 600 Luther's Corners, IL 61324.
- Emma Snyder's spouse is Harvey Snyder.
- Emma Snyder has sons Seth Snyder, Caleb Snyder, and Holden Snyder.
- Emma Snyder has daughters Ellie Snyder and Meg Snyder.
- Emma Snyder has adoptive daughters Iva Snyder.
- Emma Snyder has grandchildren Lily
- Cult of Chucky is a 2017 American supernatural psychological slasher film.
- Don Mancini wrote and directed Cult of Chucky.
- Cult of Chucky is the seventh installment of the franchise.
- Fiona Dourif stars in Cult of Chucky.
- Alex Vincent stars in Cult of Chucky.
- Jennifer Tilly stars in Cult of Chucky.
- Summer H. Howell stars in Cult of Chucky.
- Brad Dourif stars as Chucky in Cult of Chucky.
- All of the actors listed are returning cast members from the previous six installments.

# Socialist Resistance of Kazakhstan

Socialist Resistance of Kazakhstan was established in 2002.
It was established by Kazakh members of the Committee for a Workers International.
A conference held in Russia established the organisation.
One member was detained en route to the conference.
Members reported being attacked as they gathered for the conference.
The organisation came under attack by authorities from its inception.

# Sołtan argument

Sołtan argument
- It is an astrophysical theory.
- It was outlined in 1982.
- It was outlined by Polish astronomer Andrzej Sołtan.
- It maintains that quasars were powered by accretion onto a supermassive black hole.
- It states that supermassive black holes must exist in our local universe.
- It calls these supermassive black holes "dead" quasars.

# Southeast Asian Child Labour

Child Labour
- Child labour was rationalised as a cultural tradition in southeast Asian colonies like Hong Kong.
- Mui Tsai was a form of child labour in Hong Kong.
- British authorities ignored child labour in southeast Asian colonies.
- Dutch East India Company officials rationalised child labour abuses by saying "it is a way to save these children from a worse fate."
- Christian mission schools in Zambia and Nigeria required work from children.
- Christian mission schools provided religious education, not secular education, in exchange for child labour.
- Canadian Dominion Statutes stipulated jail terms for uncooperative child workers.
- The Breaches of Contract Act was a form of Canadian Dominion Statutes.
- Child convicts were occasionally sent to Australia from European settlement in 1888.
- Child labour was not as excessive in Australia as in Britain.
- Australia did not have significant industry until the later part of the 20th century.
- From the 1870s Child labour was restricted by compulsory schooling.
- ILO helped lead the Worst Forms Convention 182 (C182).
- Worst Forms Convention 182 (C182) has been signed upon and domestically ratified by 151 countries including the United States.
- Worst Forms of child labour includes all forms of slavery and slavery-like practices.
- Worst Forms of child labour includes child trafficking, debt bondage, and forced labour.
- Worst Forms of child labour includes forced recruitment of children into armed conflict.
- Worst Forms of child labour includes the use of a child for prostitution or the production of pornography.
- Worst Forms of child labour includes child labour in illicit activities such as drug production and trafficking.
- Both the Worst
- In developing countries, with high poverty and poor schooling opportunities, child labour is still prevalent.
- In 2010, sub-saharan Africa had the highest incidence rates of child labour, with several African nations witnessing over 50 percent of children aged 5–14 working.
- Worldwide agriculture is the largest employer of child labour.
- Vast majority of child labour is found in rural settings and informal urban economy.
- Children are predominantly employed by their parents, rather than factories.
- Poverty and lack of schools are considered as the primary cause of child labour.
- Child labour accounts for 22% of the workforce in Asia.
- Child labour accounts for 32% of the workforce in Africa.
- Child labour accounts for 17% of the workforce in Latin America.
- Child labour accounts for 1% of the workforce in the US, Canada, Europe and other wealthy nations.
- The proportion of child labourers varies greatly among countries and even regions inside those countries.
- Africa has the highest percentage of children aged 5–17 employed as child labour.
- Asia has the largest number of children employed as child labour at about 114 million.
- Latin America and Caribbean region have lower overall population density, but at
- Brazil was colonized on April 22, 1550 by Pedro Álvares Cabral.
- Work that children took part in was not always visible, legal, or paid.
- Free or slave labour was a common occurrence for many youths in Brazil.
- There has been little historical documentation of child labour in Brazil during the colonial period.
- Children were forcibly working on tasks that exceeded their emotional and physical limits in indigenous societies and slave labour.
- Armando Dias died in November 1913, a victim of an electric shock in the textile industry.
- Boys and girls were victims of industrial accidents on a daily basis.

# Southwest City, Missouri

Southwest City, Missouri
- Southwest City is a city in McDonald County, Missouri.
- Southwest City is in the United States.
- The population was 937 at the 2010 census.
- At the 2010 census, it was a town.
- It is part of the Fayetteville–Springdale–Rogers, AR-MO Metropolitan Statistical Area.
- It is located in the southwestern corner of the state of Missouri.
- Baljev Dol is a village in the municipality of Dimitrovgrad, Serbia.
- The population of Baljev Dol was 8 people according to the 2002 census.
- Many relations of Ivo Karlović fled the area following unrest after the dissolution of Yugoslavia.
- Eldon is a city in Miller County, Missouri.
- Eldon is located thirty miles southwest of Jefferson City.
- The population was 4,567 at the 2010 census.

# Stadio Leonardo Garilli

- Piacenza Calcio 1919 plays home matches at Stadio Leonardo Garilli
- Stadio Leonardo Garilli has a capacity of 21,668
- Stadio Leonardo Garilli is located in Piacenza
- Piacenza Calcio plays home matches at Stadio Leonardo Garilli
- Stadio Is Arenas is currently under renovation
- Cagliari relocated out of their former home venue, Stadio Sant'Elia
- The renovation is to comply with Serie A league standards
- The renovation is in time for the new season
- Stadio Comunale "Is Arenas" is a sports stadium in Quartu Sant'Elena, Sardinia, Italy.
- It is mostly used for football games.
- It was the home venue of Serie A club Cagliari Calcio for the 2012–13 season.
- Stadio Francesco Gabrielli is an arena in Rovigo, Italy.
- It is primarily used for football.
- It is the home to the Rovigo Calcio of the Serie D.
- It opened in 1893.
- It holds 3,500 spectators.
- Football Club Crotone is an Italian football club based in Crotone, Calabria.
- Football Club Crotone was founded in 1910.
- Football Club Crotone holds home games at Stadio Ezio Scida.
- Stadio Ezio Scida has a 16,547 - seat capacity.
- Football Club Crotone plays in Serie A after being promoted from Serie B in 2016.

# Stan Tekiela Naturalist

Stan Tekiela
- Stan Tekiela is a naturalist.
- Stan Tekiela is an author.
- Stan Tekiela is a wildlife photographer.
- Stan Tekiela has a Bachelor of Science degree in Natural History from the University of Minnesota.
- Stan Tekiela has been an active professional naturalist for more than 25 years.
- Stan Tekiela is a member of the Minnesota Ornithologists' Union.
- Stan Tekiela is a member of the North American Nature Photography Association.
- Stan Tekiela is a member of Canon Professional Services.
- Stan Tekiela studies and photographs wildlife throughout the United States.
- Stan Tekiela has received various national and regional awards for his books and photographs.
- Stan Tekiela is a columnist.
- Stan Tekiela is a radio personality.
- Stan Tekiela's syndicated column appears in more than 25 newspapers.
- Stan Tekiela can be heard on a number of Midwest radio

# Star Trek: Discovery Premiere

Star Trek: Discovery premiered on September 19, 2017.
Star Trek: Discovery premiered at ArcLight Hollywood.
Star Trek: Discovery debuted on CBS and All Access on September 24.
The first season has 15 episodes.
The first season episodes are streaming weekly on All Access.
The series' release led to record subscriptions for All Access.
Critics highlighted Martin-Green's performance.
A second season was ordered in October 2017.
- Positive reviews from critics highlighted Martin-Green's performance.
- WCCO-TV is a CBS owned-and-operated television station.
- WCCO-TV is licensed to Minneapolis, Minnesota.
- WCCO-TV serves the Twin Cities television market.
- WCCO-TV is owned by the CBS Television Stations subsidiary of CBS Corporation.
- WCCO-TV's studios are located on South 11th Street along Nicollet Mall in downtown Minneapolis.
- WCCO-TV's transmitter is located at the Telefarm complex in Shoreview, Minnesota.

# Steve Hillage - Green Album

Green (Steve Hillage album)
- It is the fourth studio album by Steve Hillage.
- It was written in spring 1977.
- It was written at the same time as "Motivation Radio" (1977).
- It was originally going to be released as "The Green Album".
- It was intended as a companion to "The Red Album".
- "The Red Album" was the originally intended name for "Motivation Radio".
- It was recorded primarily in Dorking, Surrey.
- It was recorded in London.
- It was recorded after a US tour in late 1977.
- The inspiration for the song was John F. Kennedy's daughter, Caroline.
- Diamond sang the song to Caroline at her 50th birthday celebration in 2007.
- A magazine cover photo of Caroline Kennedy on a horse with her parents inspired the song.
- Diamond said the song was about his then - wife Marcia in 2014.
- Diamond needed a three - syllable name to fit the melody.
- The picture was seen about five years before the song was written.

# Stracimir and His Brothers

Stracimir Zavidović
- In 1167/1168, Stracimir was expelled to Byzantium.
- Stracimir was a brother of Tihomir.
- Stracimir was a brother of Miroslav.
- Stracimir continued to rule his lands.
- Stracimir attacked the forces of Doclean ruler Mihailo.
- Stracimir and Miroslav attacked the forces of Doclean ruler and kinsman Mihailo.
- Catherine was born in Kraków.
- Catherine was the youngest daughter of King Sigismund I the Old of the Polish-Lithuanian Commonwealth and his wife Bona Sforza of Milan.
- Catherine became the spouse of King John III of Sweden.
- Catherine was the mother of Sigismund III Vasa, King of Poland.
- Catherine and her sisters Anna and Sophia moved to Masovia with their mother after the death of their father in 1548.
- Catherine and her sisters lived in Masovia alone after their mother's departure to Italy in 1558.
- Catherine's sisters were Anna and Sophia.
- Catherine's brother was

# Sufi Interpretations of Quran

Quran
- Sulami (d. 1021) is an author of esoteric interpretation.
- Haqaiq al-tafsir is a book named by Sulami.
- Haqaiq al-tafsir is a compilation of commentaries of earlier Sufis.
- Qushayri (d. 1074) wrote commentaries from the 11th century onwards.
- Daylami (d. 1193) wrote commentaries from the 11th century onwards.
- Shirazi (d. 1209) wrote commentaries from the 11th century onwards.
- Suhrawardi (d. 1234) wrote commentaries from the 11th century onwards.
- Maybudi (d. 1135) wrote in Persian.
- Kash al-asrar is a work written by Maybudi.
- Kash al-
- Islamic education is rooted in the teachings of the Quran.
- Islamic education and Muslim education are not the same.
- Islamic education has epistemological integration founded on Tawhid.
- Tareq M Zayed wrote "A Qur’anic Methodology for Integrating Knowledge and Education: Implications for Malaysia’s Islamic Education Strategy".
- Tareq M Zayed authored "Knowledge of Shariah and Knowledge to Manage ‘Self’ and ‘System’: Integration of Islamic Epistemology with the Knowledge and Education".
- Rumi (d. 1273) wrote a vast amount of mystical poetry in his book Mathnawi.
- Rumi makes heavy use of the Quran in his poetry.
- Some translations of Rumi's work omit the feature of Rumi making heavy use of the Quran.
- A large number of Quranic passages can be found in Mathnawi.
- Some consider Mathnawi a kind of Sufi interpretation of the Quran.
- Rumi does mention Quran more frequently than others.
- Simnani (d. 1336) wrote two influential works of esoteric exegesis on the Quran.
- Simnani reconciled notions of God's manifestation through

# Sunnyboys Band History

Sunnyboys
- Sunnyboys first formed in 1979.
- Sunnyboys broke up in June 1984.
- Jeremy Oxley formed various incarnations of the band throughout the 1980s.
- Jeremy Oxley was the only original member in the band's incarnations.
- The original line-up reunited for a one-off show in 1998.
- The 1998 reunion was for the Mushroom 25 Concert.
- The original line-up reunited for a surprise show in 2012.
- The 2012 reunion was in Sydney.
- The 2012 reunion was part of the Dig It Up concert series.
- The 2012 reunion was billed as "Kids In Dust".
- The original line-up played sporadic shows in 2013.
- The original line-up continues to
- Jeremy Saxon Oxley was born in 1961.
- Jeremy Saxon Oxley was born in Kingscliff, New South Wales.
- Jeremy Saxon Oxley is a songwriter.
- Jeremy Saxon Oxley is a singer.
- Jeremy Saxon Oxley is a guitarist.
- Jeremy Saxon Oxley fronted the band Sunnyboys.

# Supervisory Board Meetings

- The Supervisory Board meets twice a month.
- The Supervisory Board discusses, plans and carries out the ECB’s supervisory tasks.
- The Supervisory Board proposes draft decisions to the Governing Council.
- The Supervisory Board uses the non-objection procedure.
- The Chair is appointed for a non-renewable term of five years.
- The Vice-Chair is chosen from among the members of the ECB’s Executive Board.
- The Supervisory Board is composed of four ECB representatives.
- The Supervisory Board is composed of representatives of national supervisors.
- If a national supervisory authority is not an NCB, the representative can be accompanied by an NCB representative.
- The two representatives are considered as one member for the voting procedure.

# Susan Aglukark - This Child

This Child
- This Child is the second album by Susan Aglukark
- This Child was released in 1995
- This Child was Susan's commercial breakthrough in Canada
- The album spawned chart hits with "O Siem"
- The album spawned chart hits with "Hina Na Ho (Celebration)"
- Susan was the first Inuk performer ever to have a Top 40 hit

# Swan Miara, Mansehra District

Swan Miara
- Swan Miara is a village.
- Swan Miara is a union council.
- Swan Miara is in Mansehra District.
- Swan Miara is in Khyber-Pakhtunkhwa province.
- Swan Miara is located south of the district.
- Swan Miara borders Abbottabad District.
- Swan Miara is an administrative subdivision.
- Swan Miara is an administrative subdivision.

# Take It to the Limit

Take It to the Limit (Eagles song)
- The song was written by Randy Meisner, Don Henley and Glenn Frey.
- Randy Meisner sang lead on the song.
- Meisner says the song began as his solo composition.
- Henley and Frey assisted Meisner in completing the song.
- The song was to be included on the One of These Nights album.
- Meisner's performance of the song was popular with the audience in Eagles' concerts.
- Disputes over Meisner's reluctance to perform it would directly lead to Meisner's departure from the band.

# Taktin Oey Biography

Taktin Oey
- He graduated from West Windsor-Plainsboro High School North in 2004.
- He graduated from Harvard University in 2008.
- He received the 1999 ASCAP First Prize.
- He received the 1996 ASCAP First Prize.
- He won First Prize for his Piano Quartet in the European Region’s Young Composers’ Competition in 2000.
- He was born in Hugo, Oklahoma, February 5, 1933.
- He is an American writer, author, poet, and photojournalist.
- He has received numerous awards, prizes, and

# Tanzania

- The text does not contain any facts about Tanzania.

# Taputapuatea Commune

Taputapuatea
- Taputapuatea is a commune of French Polynesia.
- French Polynesia is an overseas territory of France.
- Taputapuatea is located in the Pacific Ocean.
- Taputapuatea is located on the island of Raiatea.
- Taputapuatea is located in the Leeward Islands.
- The Leeward Islands are part of the Society Islands.
- In 2017, Taputapuatea had a population of 4,792.
- In 2017, Taputapuatea and Taputapuatea marae were inscribed on the UNESCO World Heritage Sites list.
- Poum is a commune in the North Province of New Caledonia.
- New Caledonia is an overseas territory of France.
- Poum is located in the Pacific Ocean.
- The town of Poum is located at Latitude: 20° 13' 59" south, longitude: 164° 1' 23" east.
- Poum is located on the southern part of Banare Bay.
- Mouac Island is just offshore from Poum.
- Taputapuatea along with Taputapuatea marae were inscribed on the UNESCO World Heritage Sites list.
- At the 2017 census it had a population of 4,792.
- Taputapuatea is a commune of French Polynesia, an overseas territory of France in the Pacific Ocean.
- The commune of Taputapuatea is located on the island of Raiatea, in the administrative subdivision of the Leeward Islands, themselves part of the Society Islands.
- In 2017 Taputapuatea along with Taputapuatea marae were inscribed on the UNESCO World Heritage Sites list.

# Tathlina Lake

- Tathlina Lake is a large lake
- Tathlina Lake is a shallow lake
- Tathlina Lake is located in the Northwest Territories, Canada
- An outcropping of the Kakisa Formation occurs along the side of Tathlina Lake
- Kakisa Lake is fed by the Kakisa River
- Kakisa Lake is near the community of Kakisa

# Teletubbies setting

Teletubbies
- The programme takes place in a grassy, floral landscape.
- Rabbits populate the landscape.
- Bird calls are audible in the background.
- The main shelter of the four Teletubbies is an earth house.
- The earth house is known as the ``Tubbytronic Superdome''.
- The Tubbytronic Superdome is implanted in the ground.
- The Tubbytronic Superdome is accessed through a hole at the top.
- The Tubbytronic Superdome is accessed through a semicircular door at the dome's foot.
- The Teletubbies co-exist with strange contraptions.
- The Noo-noo is an anthropomorphic blue vacuum cleaner.
- The Noo-noo is the group's vacuum cleaner.
- The show has Voice Trumpets.
- The setting was designed to appeal to the attention spans of infants.
- The setting was designed

# Tennis on CBS Branding

Tennis on CBS
- It is the branding used for broadcasts of professional tennis tournaments.
- It was produced by CBS Sports.
- CBS Sports is the sports division of the CBS television network.
- CBS held the broadcast rights to the U.S. Open.
- CBS held the broadcast rights to the U.S. Open Series.
- CBS held the broadcast rights to the Sony Ericsson Open.
- CBS also televised the French Open from 1980 to 1982.
- CBS had broadcast agreements with the United States Tennis Association (USTA).
- The network's broadcast agreements with the USTA ended in 2014.

# The Bruce Lee Band

Bruce Lee Band is also known as B. Lee Band.
The Bruce Lee Band includes Mike Park and his backing band.
The backing band has included Less Than Jake.
The backing band has included the Rx Bandits.

# The Dream Life of Balso Snell

The Dream Life of Balso Snell
- The Dream Life of Balso Snell is a novel.
- The novel was published in 1931.
- The author is Nathanael West.
- Nathanael West is an American author.
- It presents a young man's search for meaning.
- The search takes place in a series of dreamlike encounters.
- The encounters take place inside the entrails of the Trojan Horse.
- It is West's first novel.

# The FBI Story

The FBI Story
- The FBI Story is a 1959 American drama film.
- The film stars James Stewart.
- The film was produced and directed by Mervyn LeRoy.
- The screenplay was written by Richard L. Breen and John Twist.
- The screenplay is based on a book by Don Whitehead.
- Elmer, the Great is a 1933 American pre-Code comedy film.
- The film is directed by Mervyn LeRoy.
- The film stars Joe E. Brown.
- The film stars Patricia Ellis.
- Father Brown, Detective is a 1934 American mystery film.
- The film is directed by Edward Sedgwick.
- The film stars Walter Connolly.
- The film stars Paul Lukas.
- The film stars Gertrude Michael.
- It is based on the Father Brown story "The Blue Cross" by G.K. Chesterton.
- A story which also informed the 1954 film "Father Brown" with Alec Guinness and Peter Finch.
- French Connection II is a 1975 action thriller film.
- French Connection II stars Gene Hackman.
- French Connection II is directed by John Frankenheimer.
- It is a fictional sequel to "The French Connection".
- The film expands on the central character of Det. Jimmy "Popeye" Doyle.
- Det. Jimmy "Popeye" Doyle travels to Marseille, France.
- He is attempting to track down Alain Charnier.
- Alain Charnier is a French drug-dealer.
- Hackman won an Academy Award for Best Actor for "The French Connection".
- Fernando Rey is a returning cast member.

# The Great Lakes Group

- The Great Lakes Group is an American full-service marine-related transportation company.
- The Great Lakes Group is headquartered in Cleveland, Ohio.
- The Great Lakes Group is the parent company to The Great Lakes Towing Company.
- The Great Lakes Group is the parent company to Great Lakes Shipyard.
- The Great Lakes Group is the parent company to Tugz International L.L.C.
- The Great Lakes Group is the parent company to Puerto Rico Towing & Barge Co.
- The Great Lakes Group is the parent company to Soo Linehandling Services.
- The Great Lakes Group is the parent company to Admiral Towing and Barge Company.
- The Great Lakes Group is the parent company to Wind Logistics, Inc.
- Black Wolf Lodge was founded in 1997 by brothers Jack and Andrew ``Turk ''Waterman.
- Brothers Jack and Andrew ``Turk ''Waterman were the original owners of Noah's Ark water park in Wisconsin Dells, Wisconsin.
- Black Wolf Lodge was purchased by The Great Lakes Company in 1999.
- Marc Vaccaro and Bruce Neviaser changed the name to Great Wolf Lodge in 1999.
- The company headquarters were established in Madison, Wisconsin in 1999.
- The company built a second location in Sandusky, Ohio in 2001.
- The second location was named Great Bear Lodge in 200

# The Grey Griffins Series

The Revenge of the Shadow King is the first volume of the Grey Griffins series.
The Grey Griffins series is written by Derek Benz and J.S. Lewis.
Derek Benz is an American author.
J.S. Lewis is an American author.
The Revenge of the Shadow King is published by Orchard Books.
Orchard Books is an imprint of Scholastic Inc.
Four friends form The Order of the Grey Griffin.

# The Handmaid's Tale (series)

- The Handmaid's Tale is an American web television series.
- It was created by Bruce Miller.
- It is based on the 1985 novel by Margaret Atwood.
- It was ordered by Hulu.
- Hulu ordered 10 episodes.
- Production began in late 2016.
- The plot follows a dystopian future.
- A Second American Civil War occurred.
- Women are called ``Handmaids''.
- Handmaids are forced into sexual and child - bearing servitude.

# The Harry Quebert Affair

The Truth About the Harry Quebert Affair (miniseries)
- Patrick Dempsey plays Harry Quebert
- Ben Schnetzer plays Marcus Goldman
- Damon Wayans Jr. plays Sgt. Perry Gahalowood
- Kristine Froseth plays Nola Kellergan
- Kurt Fuller plays Chief Gareth Pratt
- Victoria Clark plays Jenny Quinn
- Tessa Mossey plays young Jenny Quinn
- Wayne Knight plays Benjamin Roth
- Don Harvey plays Bobbo Quinn
- Matt Frewer plays Reverend Kellergan
- Colm Feore plays Elijah Stern
- Josh Close plays Luther
- Caleb Craig Eldridge plays Travis
- Dawn Connor Price plays young Travis
- Virginia Madsen plays Tamara Quinn
- Marietta Edgecombe is cursed with pimples on her face.
- Marietta Edgecombe was betrayed the group to Umbridge.
- Dumbledore claimed responsibility for organising the group.
- Dumbledore escaped when Ministry officials attempted to arrest him.
- Ginny, Neville and Luna joined Harry, Ron and Hermione in the battle in the Department of Mysteries.
- Neville and Luna were distraught due to the fact that the D.A. no longer exists.
- When Hogwarts is invaded by Death Eaters, they are among the members who join the Order of the Phoenix.
- Llian is a brilliant chronicler.
- Llian is from the College of Histories in Chanthed.
- Karan owns the humble lands of Gothryme.
- "A Shadow on the Glass" was published in 1998.
- "A Shadow on the Glass" was published by Penguin Books.
- Missing Person is a novel by Patrick Modiano.
- Missing Person is the sixth novel by Patrick Modiano.
- Missing Person was published on 5 September 1978.
- Missing Person was awarded the Prix Goncourt in 1978.
- An English translation by Daniel Weissbort was published in 1980.
- Rue des Boutiques Obscures is the name of a street in Rome.
- Modiano himself lived for some time in Rue des Boutiques Obscures.

# The Haves and Have Nots

The Haves and the Have Nots is a soap opera.
The Haves and the Have Nots is a crime thriller.
The Haves and the Have Nots was created by Tyler Perry.
The Haves and the Have Nots was written by Tyler Perry.
The Haves and the Have Nots was directed by Tyler Perry.
The Haves and the Have Nots stars Tika Sumpter.
The Haves and the Have Nots stars Crystal Fox.
The Haves and the Have Nots stars Tyler Lepley.
The Haves and the Have Nots stars Renee Lawless.
The Haves and the Have Nots stars Aaron O'Connell.
The Haves and the Have Nots stars Peter Parros.
The Haves and the Have Nots stars Angela Robinson.
The Haves and the Have Nots stars Gavin Houston.
The Haves and the Have Nots stars Eva Tamargo.
- The Young and the Restless is an American television soap opera.
- The Young and the Restless was created by William J. Bell and Lee Phillip Bell.
- The Young and the Restless first aired on March 26, 1973.
- Doug Davidson portrays private investigator Paul Williams.
- Doug Davidson has portrayed Paul Williams since May 23, 1978.
- Jeanne Cooper portrayed Katherine Chancellor.
- Jeanne Cooper portrayed Katherine Chancellor from November 1973 until her death in May 2013.
- Melody Thomas Scott portrays Nikki Newman.
- Eric Braeden portrays Victor Newman.
- Melody Thomas Scott joined in February 197

# The Key to the Golden Firebird

The Key to the Golden Firebird is a novel by Maureen Johnson.
Maureen Johnson is a young adult author.
The book was first published in 2004.
The American Library Association listed it as a Best Books for Young Adults in 2005.
- The Shadow of Saganami is a science fiction novel.
- David Weber is an American writer.
- The book was published in 2004.
- It is set in the Honorverse.
- It has been billed as the first in the "Saganami Island" series.
- The book is spun off from the main Honor Harrington series.
- The book debuted at #16 on "The New York Times" best seller list for hardcover fiction.

# The Learning Company

The Learning Company was owned by Houghton Mifflin Harcourt.
The Learning Company produced a grade-based system of learning software.
The Learning Company produced tools to improve productivity.
Products for preschoolers through second graders included "Reader Rabbit".
Software for more advanced students included "The ClueFinders".
The Learning Company published licensed educational titles featuring Arthur.
The Learning Company published licensed educational titles featuring Scooby-Doo.
The Learning Company published licensed educational titles featuring "Zoboomafoo".
The Learning Company published licensed educational titles featuring "Caillou".

# The Odd Life of Timothy Green

The Odd Life of Timothy Green
- The Odd Life of Timothy Green is a 2012 American fantasy comedy-drama film.
- The film stars Jennifer Garner, Joel Edgerton, Dianne Wiest, CJ Adams, Rosemarie DeWitt, Ron Livingston, David Morse and Common.
- The film was written and directed by Peter Hedges.
- The film was produced by Walt Disney Pictures.
- The film is based on a concept by Ahmet Zappa.
- The film is about a magical pre-adolescent boy.
- The boy's personality and naïveté have profound effects on the people in his town.
- The film was released theatrically on August 15, 2012.
- The film received mixed reviews from critics.
- The film earned $55.3 million on a $25 million budget.
- CJ Adams won a Young Artist Award for Best Performance in a Feature Film
- The Timothy Files is a 1987 best selling work of fiction by Lawrence Sanders.
- The Timothy Files consists of linked stories.
- The stories feature Timothy Cone.
- Timothy Cone works as an investigator.
- Timothy Cone is a hard-boiled type investigator.
- Timothy Cone is a scruffy character.
- Timothy Cone is rough of mouth.
- Timothy Cone is rough of demeanor.
- Timothy Cone is pure of heart.
- Timothy Cone has trouble with relationships.
- Timothy Cone has a rough-edged on-going affair with his supervisor.
- Timothy Cone has an only slightly softer relationship with his cat Cleo.
- The stories deal with
- The Anderson Tapes is a crime fiction novel by Lawrence Sanders.
- The Anderson Tapes was published in 1970.
- The story revolves around a burglary of an upscale New York apartment building.
- The burglary is under wiretap and camera surveillance.
- NYPD police detective Edward X. Delaney is a character in the story.
- Edward X. Delaney became Sander's protagonist in his "Deadly Sin" series of novels.
- The book earned Sanders the Mystery Writers of America Edgar Award for best first mystery novel.
- The book was adapted into a film directed by Sidney Lumet.
- Sean Connery played the title role in the film.
- Halfway Tree is the second album by Jamaican reggae artist Damian "Jr. Gong" Marley.
- The name "Halfway Tree" comes from his mother, Cindy Breakspeare, being from the rich part of town, and his father, Bob Marley, coming from the poor part of town.
- Halfway Tree is a well-known landmark that marks the cultural center of Half-Way-Tree.
- The clock tower that stands where the historical eponymous cotton tree once stood is featured prominently behind Marley on the cover of the album.
- The album was released on September 11, 2001.
- The album received the 2002 Grammy Award for Best Reggae Album.

# The Open Boat

The Open Boat (Story)
- The story "The Open Boat" was published in "Scribner's Magazine".
- The story is told from the point of view of an anonymous correspondent.
- Crane is the implied author of the story.
- The action closely resembles the author's experiences after a shipwreck.
- A volume titled "The Open Boat and Other Tales of Adventure" was published in the United States in 1898.
- An edition entitled "The Open Boat and Other Stories" was published simultaneously in England.
- Contemporary critics praised the story for its innovation.
- The story is considered an exemplary work of literary Naturalism.
- The story is one of the most frequently discussed works in Crane's canon.
- The story is notable for its use of imagery.
- The story is notable for its use of irony.
- The story is notable for its use of symbolism.
- The story explores

# The Painter's Honeymoon

The Painter's Honeymoon
- The Painter's Honeymoon is a painting by Frederic Leighton, 1st Baron Leighton.
- The painting is currently housed at the Museum of Fine Arts, Boston.
- Frederic Leighton was 1st Baron Leighton.
- Portrait of a Young Englishman ("Portrait of a Young Man with Grey Eyes") is a 1540–45 portrait by Titian.
- The painting is now held in the Palazzo Pitti.
- Its subject is unidentified.
- The subject may be Henry Howard.
- The subject may be Ottavio Farnese.
- The subject may be Ippolito Rominaldi.
- Mother with a Child and a Chambermaid is an oil on canvas painting
- Mother with a Child and a Chambermaid is by the Dutch painter Pieter de Hooch
- Mother with a Child and a Chambermaid is an example of Dutch Golden Age painting
- Mother with a Child and a Chambermaid is part of the collection of the Amsterdam Museum.

# The Stranglers' "Strange Little Girl"

Strange Little Girl (song)
- "Strange Little Girl" was released in the UK in 1982.
- The song was released as a single by the Stranglers.
- The Stranglers were signed to Liberty Records (part of EMI) at the time.
- The Stranglers had decided to leave Liberty Records for Epic Records by the time of release.
- The single was part of a severance deal.
- The severance deal also included the compilation album, "The Collection 1977-1982".

# The Village of Waiting

The Village of Waiting
- George Packer wrote The Village of Waiting.
- George Packer served with the Peace Corps in Togo in 1982–1983.
- The book chronicles Packer's time as an English teacher in the village of Lavie.
- Lavie means "wait a little longer."
- Packer visited the capital Lomé.
- Packer visited several other African countries.
- The book mixes anecdotes about the people he met in Togo with political observations.
- George Packer criticized Togolese President Gnassingbe Eyadema.
- Packer reflects upon the changes Togo has experienced since his time there in the 2001 edition.
- Packer was terminated early from the Peace Corps.
- Packer left Togo six months prior to the end of his contracted period of service.
- Packer chose not to mention his early termination in the book.

# The White Rabbit

White Rabbit
- The White Rabbit is a fictional character in "Alice's Adventures in Wonderland".
- He appears at the beginning of the book, in chapter one.
- He is wearing a waistcoat.
- He mutters "Oh dear! Oh dear! I shall be too late!"
- Alice follows him down the rabbit hole into Wonderland.
- He mistakes Alice for his housemaid Mary Ann.
- Alice grows too large and becomes trapped in his house.
- He appears as a herald-like servant of the King and Queen of Hearts.
- Flemish Giant Rabbits weigh 15 pounds on average.
- The biggest ones can weigh up to 22 lb.
- The longest one on record measured about 4 feet 3 inches long.
- It holds the record for the longest rabbit in the world of any kind.
- School for Secrets is also known as Secret Flight.
- It is a 1946 British black and white film.
- It was written and directed by Peter Ustinov.
- It stars Ralph Richardson.
- David Tomlinson, Raymond Huntley, Finlay Currie, Richard Attenborough, John Laurie and Michael Hordern are in leading supporting roles.
- The film celebrates the discovery of radar.
- It was developed with the full cooperation of the Air Ministry.

# Theotokos and Orthodox Tradition

Mary, Mother of Jesus
- Orthodox Christianity has traditions regarding the Ever Virgin Mary.
- Orthodox Christians believe she was a virgin before and after Christ's birth.
- Theotokia are an essential part of the Divine Services in the Eastern Church.
- Theotokia are hymns to the Theotokos.
- The Theotokos is in the most prominent place after Christ in the liturgical sequence.
- The order of the saints in the Orthodox tradition begins with The Theotokos.
- The Theotokos has precedence over the angels.
- She is proclaimed as the "Lady of the Angels".

# Thirukkanur Village

- Thirukkanur is a village.
- Thirukkanur is in the union territory of Puducherry, India.
- Thirukkanur is one of 16 villages.
- Thirukkanur is located in Mannadipet commune panchayat.
- Thirukkanur is in Villianur taluk.
- Thirukkanur is bordered by the state of Tamil Nadu to the east.
- Thirukkanur is bordered by the state of Tamil Nadu to the west.
- Pettai is a panchayat village.
- Pettai is a revenue village.
- Pettai is in Pondicherry Union Territory, India.
- Pettai is under the Thirunallar Taluk.
- Pettai was formerly under the Thirunallar Commune Panchayat.
- Pettai is in Karaikal District, Pondicherry Union Territory.
- Pettai is situated on the banks of the Arasalar River.
- Pettai is to the west of Karaikal town.
- Pettai is south of Thirunallar.
- Banjevac is a village in Serbia.
- Banjevac is in the Krupanj municipality.
- Banjevac is in the Mačva District of Central Serbia.
- The village had a Serb ethnic majority.
- The village had a population of 500 in 2002.
- Donja Borina is a village in Serbia.
- Donja Borina is in the Mali Zvornik municipality.
- Donja Borina is in the Mačva District of Central Serbia.
- The village has a Serb ethnic majority.
- The village had a population of 1,731 in 2002.
- Thirukkanur is bordered by the state of Tamil Nadu both to the east and west.

# Thomas Nabbes Biography

Thomas Nabbes was born in Worcestershire.
Thomas Nabbes was educated at Exeter College, Oxford in 1621.
Thomas Nabbes left the university without taking a degree.
Thomas Nabbes began a career in London as a dramatist around 1630.
Thomas Nabbes was employed at some point in the household of a nobleman near Worcester.
Thomas Nabbes seemed to have been of a convivial disposition.
Thomas Nabbes had at least two children, Bridget and William.
Bridget died within two years of Thomas Nabbes' death.
William died within two years of Thomas Nabbes' death.
Thomas Nabbes, Bridget, and William were buried at St Giles in the Fields.
- François Ponsard was a French dramatist.
- François Ponsard was a poet.
- François Ponsard was an author.
- François Ponsard was a member of the Académie française.
- François Ponsard was born on 1 June 1814.
- François Ponsard died on 7 July 1867.

# Timothy P. Williams

Timothy P. Williams
- Timothy P. Williams is a United States Army major general.
- Timothy P. Williams is the Adjutant General of Virginia.
- He commands the Virginia Army National Guard.
- He commands the Virginia Air National Guard.
- He commands the Virginia Defense Force.
- He is the co-author of, "Let’s Go! The History of the 29th Infantry Division 1917-2001".
- Timothy Township is in Crow Wing County, Minnesota.
- The population of Timothy Township was 147 at the 2000 census.
- The township may be named for its Timothy-grass.
- The Boys on the Bus (1973) is author Timothy Crouse's seminal non-fiction book detailing life on the road for reporters covering the 1972 United States presidential campaign.
- Virginia is located in Lempira Honduras.
- Many Virginians travel to El Salvador to do their shopping.
- The Honduran cities are far away from Virginia.
- Ralph W. Tyler (1902–1994) was an American educator.
- He worked in the field of assessment and evaluation.
- He served on or advised a number of bodies that set guidelines for the expenditure of federal funds.
- He influenced the underlying policy of the Elementary and Secondary Education Act of 1965.
- He chaired the committee that developed the National Assessment of Educational Progress (NAEP).
- He has been called by some as "the father of educational evaluation and assessment".
- "Shake Ya Ass" is a single by Mystikal.
- "Shake Ya Ass" is from the album "Let's Get Ready B".
- "Shake Ya Ass" has a B-side called "Shake It Fast".
- "Shake Ya Ass" was released on July 18, 2000.
- "Shake Ya Ass" is available in Vinyl and CD format.
- "Shake Ya Ass" was recorded at Master Sound Studios in Virginia Beach, Virginia.
- "Shake Ya Ass" is a hip hop song.
- "Shake Ya Ass" is 4:20 in length.
- "Shake Ya Ass" is released on the Jive label.
- "Tootsee Roll" is a single by 69 Boyz.
- "Tootsee Roll" is from the album "199Quad".
- "Tootsee Roll" was released on May 27, 1994.
- "Tootsee Roll" was recorded.
- "Tootsee Roll" is a hip hop song.
- "Tootsee Roll" is a Southern hip hop song.
- "Tootsee Roll" is a Miami bass song.
- "Tootsee Roll" is 4:18 in length.
- "Tootsee Roll" was written by Albert V Bryant and Pat Hicks.

# Tip Top Bakeries

- Tip Top Bakeries is an Australasian manufacturer of bread products
- Tip Top Bakeries is owned by George Weston Foods
- George Weston Foods is a subsidiary of Associated British Foods
- Associated British Foods is a multinational food giant

# Tom Benson Buys Saints

- John Mecom was the owner of the New Orleans Saints for almost 20 years.
- There was speculation that a new owner might move the Saints to Jacksonville, Florida.
- Tom Benson bought the team on May 31, 1985.
- Tom Benson is a native New Orleanian.
- Tom Benson owned numerous car dealerships in the New Orleans area.
- Anna Benson was born February 12, 1976.
- Anna Benson is an American model.
- Anna Benson is a former stripper.
- Anna Benson is an ex-wife of Kris Benson.
- Kris Benson is a former Major League Baseball pitcher.
- Gale Ann Benson (nee Plugge) was born November 4, 1944.
- Gale Ann Benson died January 2, 1972.
- Gale Ann Benson was a British model.
- Gale Ann Benson was a socialite.
- Gale Ann Benson was the daughter of Leonard Plugge.
- Leonard Plugge was a Conservative MP.
- Michael X was an activist.
- Michael X was a member of a Black Power group.
- Michael X and members of his Black Power group murdered Gale Ann Benson.
- Michael X and members of his Black Power group buried Gale Ann Benson alive.
- Trinidad was where Gale Ann Benson was murdered.
- Trinidad was

# Tour of Qatar 2008

- The 2008 Tour of Qatar was held from 27 January to 1 February 2008.
- The event took place in Qatar.
- It is a multiple stage road cycling race.
- The race took part over six stages.
- The total distance was 712.5 kilometres.
- It is part of the 2007–2008 UCI Asia Tour.

# Tumaraa Commune, Raiatea

- Tumaraa is a commune of French Polynesia.
- French Polynesia is an overseas territory of France.
- Tumaraa is located in the Pacific Ocean.
- The commune of Tumaraa is located on the island of Raiatea.
- Raiatea is in the Leeward Islands.
- The Leeward Islands are part of the Society Islands.
- In the 2017 census, Tumaraa had a population of 3,721.
- Tumaraa is the least populous commune on Raiatea.
- At the 2017 census it had a population of 3,721, making it the least populous commune on Raiatea.
- Tumaraa is in the administrative subdivision of the Leeward Islands.
- Each page has a short title (2 to 5 words) about a single topic
- The content is a list of facts in bullets, one fact per line, with no repetition
- Do not make up information that is not in the given text
- Always write in English and keep names exactly as they appear in the text
- If the text only mentions a name/topic in passing, without real facts about it,
- Hörnli mountain is located on the territory of the community of Fischenthal.
- Hörnli mountain is in the Zürcher Oberland.
- Hörnli mountain is in the eastern part of canton of Zürich.
- Hörnli mountain is in Switzerland.
- It is high.
- Tumaraa is a commune of French Polynesia, an overseas territory of France in the Pacific Ocean.
- The Leeward Islands, themselves part of the Society Islands.

# Tyrion Lannister Character

Tyrion Lannister
- Tyrion Lannister is a character in A Song of Ice and Fire.
- Tyrion Lannister is a character in Game of Thrones.
- Peter Dinklage portrays Tyrion in Game of Thrones.
- Tyrion first appeared in the novel A Game of Thrones (1996).
- Tyrion first appeared in the television show ``Winter Is Coming`` (2011).
- Tyrion first appeared in the video game ``Iron From Ice`` (2014).
- Tyrion was created by George R.R. Martin.
- Peter Dinklage voices Tyrion in the video game.
- Tyrion is nicknamed The Imp.
- Tyrion is nicknamed The Halfman.
- Tyrion is nicknamed Yollo.
- Tyrion is nicknamed Hugor Hill.
- Tyrion is male.
- Tyrion's title is Hand of the King.
- Tyrion'
- Don Draper is a character in Mad Men.
- Jon Hamm portrays Don Draper.
- Don Draper first appeared in ``Smoke Gets in Your Eyes`` (1.01).
- Don Draper last appeared in ``Person to Person`` (7.14).
- Don Draper was created by Matthew Weiner.
- Don Draper's full name is Donald Francis Draper.
- Don Draper's nickname is Don.
- Don Draper's nickname is Dick.
- Don Draper's alias is Richard Whitman (birth name).
- Don Draper is a Senior Partner and Creative Director at Sterling Cooper & Partners.
- Don Draper is a Founding Partner at Sterling Cooper Draper Pryce.
- Don Draper

# United States Naval Institute

United States Naval Institute
- It is based in Annapolis, Maryland
- It is a private, non-profit, professional military association
- It seeks to offer independent, nonpartisan forums for debate of national defense and security issues
- It publishes magazines and books
- It holds several annual conferences
- In the Shadow of Greatness is a 2012 book.
- It was written by 33 members of the United States Naval Academy Class of 2002.
- The United States Naval Institute published it.
- The authors describe how their lives were shaped by their experiences at the Academy, the September 11 attacks, and events following graduation.
- It is an international initiative developed by United States Naval Forces Europe-Africa
- It works cooperatively with U.S. and international partners
- It aims to improve maritime safety and security in Africa
- It is part of US Africa Command's Security Cooperation program

# UNO-96 Alliance

- UNO-96 Alliance was a center-right Nicaraguan political party
- UNO-96 Alliance was founded in 1996
- Alfredo César Aguirre founded UNO-96 Alliance
- Alfredo César Aguirre was a member of the National Opposition Union
- Alfredo César Aguirre was a campaign advisor to Violeta Barrios de Chamorro
- UNO-96 Alliance obtained a seat in the National Assembly in the 1996 Nicaraguan general elections

# US Borders and Geography

United States Geography
- The United States shares a land border with Canada (to the north)
- The United States shares a land border with Mexico (to the south)
- The United States shares a territorial water border with Russia in the northwest
- The United States shares two territorial water borders in the southeast between Florida and Cuba
- The United States shares two territorial water borders in the southeast between Florida and the Bahamas
- The contiguous forty-eight states are bounded by the Pacific Ocean on the west
- The contiguous forty-eight states are bounded by the Atlantic Ocean on the east
- The contiguous forty-eight states are bounded by the Gulf of Mexico to the southeast
- Alaska borders the Pacific Ocean to the south
- Alaska borders the Bering Strait to the west
- Alaska borders the Arctic Ocean to the north
- Hawaii lies far to the southwest of the mainland in the Pacific Ocean
- Oak Lawn is a suburb of Chicago
- It is located southwest of Chicago
- It shares borders with the city in two areas
- It is surrounded mostly by other suburbs
- The Canada -- United States border is the longest international border in the world between two countries.
- The Canada -- United States border is officially known as the International Boundary.
- The terrestrial boundary is 8,891 kilometres (5,525 mi) long.
- Canada's border with Alaska is 2,475 kilometres (1,538 mi) long.
- Eight Canadian provinces and territories are located along the border: Yukon, British Columbia, Alberta, Saskatchewan, Manitoba, Ontario, Quebec, and New Brunswick.
- Thirteen U.S. states are located along the border: Alaska, Washington, Idaho, Montana, North Dakota, Minnesota,
- Mount Bosworth is located in the Canadian Rockies.
- Mount Bosworth is on the border of Alberta and British Columbia.
- Mount Bosworth is situated immediately northwest of Kicking Horse Pass.
- Mount Bosworth straddles the shared border of Banff National Park with Yoho National Park.
- Mount Bosworth was named in 1903 after George Morris Bosworth.
- George Morris Bosworth was an executive and long-time employee of the Canadian Pacific Railway.
- The Canada -- United States border is shared between Canada and the United States.
- Eight Canadian provinces and territories (Yukon, British Columbia, Alberta, Saskatchewan, Manitoba, Ontario, Quebec, and New Brunswick) are located along the border.
- Thirteen U.S. states (Alaska, Washington, Idaho, Montana, North Dakota, Minnesota, Michigan, Ohio, Pennsylvania, New York, Vermont, New
- Imperial is a census-designated place (CDP)
- Imperial is in Pecos County, Texas
- The population of Imperial was 278 at the 2010 census.
- John Blair Smith Todd was a Delegate from Dakota Territory to the United States House of Representatives.
- John Blair Smith Todd was a general in the Union Army during the American Civil War.
- John Blair Smith Todd’s birth date was April 4, 1814.
- John Blair Smith Todd’s death date was January 5, 1872.
- Utqiaġvik, Alaska is the northernmost incorporated place in all U.S. territory.
- The population of Utqiaġvik, Alaska is about 4,000.
- The Homeland Security Act was signed into law by U.S. President George W. Bush.
- The Homeland Security Act was signed on 25 November 2002.
- The Coast Guard was designated to be placed under the U.S. Department of Homeland Security by the Homeland Security Act.
- The transfer of administrative control from the U.S. Department of Transportation to the U.S. Department of Homeland Security was completed on 1 March 2003.
- The United States Bankruptcy Court for the Southern District of New York is within the United States District Court for the Southern District of New York.
- The Southern District of New York is a major venue for bankruptcy.
- The Southern District of New York has jurisdiction over the corporate headquarters and major financial institutions located in Manhattan.
- The Northeast blackout of 2003 occurred on Thursday, August 14, 2003.
- The Northeast blackout of 2003 affected parts of the Northeastern and Midwestern United States.
- The Northeast blackout of 2003 affected the Canadian province of Ontario.
- The Northeast blackout of 2003 began just after 4:10 p.m. EDT.
- The Stars and Stripes Forever is the national march of the United States.
- The lyrics of The Stars and Stripes Forever were written by John Philip Sousa in May 1897.
- The music of The Stars and Stripes Forever was written by John Philip Sousa in December 1896.
- The Stars and Stripes Forever was adopted in 1987.
- The Stars and Stripes Forever was adopted 31 years ago.
- Pine Springs is an unincorporated community.
- Pine Springs is in Culberson County, Texas.
- Pine Springs is the closest settlement to the headquarters of Guadalupe Mountains National Park.
- Guadalupe Peak, the highest point in the state of Texas, is in Guadalupe Mountains National Park.
- Pine Springs is located on U.S. Routes 62 and 180.
- The last population read 51 residents.
- Hawaii lies far to the southwest of the mainland in the Pacific Ocean.
- The contiguous forty-eight states are otherwise bounded by the Pacific Ocean on the west, the Atlantic Ocean on the east, and the Gulf of Mexico to the southeast.
- The United States shares land borders with Canada (to the north) and Mexico (to the south).
- The United States shares a territorial water border with Russia in the northwest.
- The United States shares two territorial water borders in the southeast between Florida and Cuba.
- The United States shares two territorial water borders in the southeast between Florida and the Bahamas.
- The United States shares a territorial water border with Russia in the northwest.
- The Canada -- United States border is known as the International Boundary.
- The Canada -- United States border is the second- and fourth-largest countries by area, respectively.
- Thirteen U.S. states (Alaska, Washington, Idaho, Montana, North Dakota, Minnesota, Michigan, Ohio, Pennsylvania, New York, Vermont, New Hampshire, and Maine) are located along the border.
- 2,475 kilometres (1,538 mi) is Canada's border with Alaska.
- The Badigeru swamp lies in South Sudan.
- The Badigeru swamp lies in the Central Equatoria and Eastern Equatoria states.
- The Badigeru swamp lies between Terekeka and Lafon.
- The Badigeru swamp is also known as Bedigeru or Badingilu.
- The Canada -- United States border is known as the International Boundary (French: Frontière internationale).
- The terrestrial boundary (including portions of maritime boundaries in the Great Lakes, and on the Atlantic, Pacific, and Arctic
- Virginia is located in Lempira Honduras.
- Virginia shares a border with El Salvador.
- Many Virginians travel to El Salvador to do their shopping.
- Honduran cities are far away from Virginia.
- The United States Marijuana Party is a cannabis political party in the United States.
- The United States Marijuana Party was founded in 2002 by Loretta Nall.
- The United States Marijuana Party was founded specifically to end the war on drugs and to legalize cannabis.
- The party is active in Vermont.
- The party has local chapters in several other states.
- The party is affiliated with international cannabis political parties.
- The United States Marijuana Party (officially the U.S. Marijuana Party™) is the full name of the party.
- The party holds socially libertarian positions.
- Alaska borders the Bering Strait to the west.
- Alaska borders the Arctic Ocean to the north.
- The contiguous forty-eight states are otherwise bounded by the Pacific Ocean on the west.
- The contiguous forty-eight states are otherwise bounded by the Atlantic Ocean on the east.
- The contiguous forty-eight states are otherwise bounded by the Gulf of Mexico to the southeast.
- The Canada -- United States border is known as the Frontière entre le Canada et les États - Unis (French).
- The Canada -- United States border is shared between Canada and the United States, the second - and fourth - largest countries by area, respectively.
- The terrestrial boundary (including portions of maritime boundaries in the Great Lakes, and on the Atlantic, Pacific, and Arctic coasts) is 8,891 kilometres (5,525 mi) long.
- The Canada -- United States border is known as the Frontière internationale (French).
- The Great Basin and Columbia Plateau (the Intermontane Plateaus) are arid or semiarid regions.
- The Great Basin and Columbia Plateau (the Intermontane Plateaus) lie in the rain shadow of the Cascades and Sierra Nevada.
- Precipitation averages less than 15 inches (38 cm) in the Great Basin and Columbia Plateau.
- The Southwest is a hot desert.
- Temperatures in the Southwest exceed 100 °F (37.8 °C) for several weeks at a time in summer.
- The Southwest is affected by the monsoon from the Gulf of California from July to September.
- The Great Basin is affected by the monsoon from the Gulf of California from
- Northwest Territories is located in northern Canada.
- The territory borders Yukon to the west.
- The territory borders Nunavut to the east.
- The territory borders British Columbia to the southwest.
- The territory borders Alberta to the south.
- The territory borders Saskatchewan to the south.
- It possibly meets Manitoba at a quadripoint to the extreme southeast.
- The land area of Northwest Territories is 1,183,085 km2 (456,792 sq mi).
- Geographical features include Great Bear Lake.
- Great Bear Lake is the largest lake entirely within Canada.
- Geographical features include Great Slave Lake.
- Great Slave Lake is the deepest body of
- The U.S. Constitution uses but does not define the phrase ``natural born Citizen ''
- Many scholars have also concluded that those who meet the legal requirements for U.S. citizenship`` at the moment of birth'', regardless of place of birth, are also natural - born citizens.
- Every president to date was either a citizen at the adoption of the Constitution in 1789 or was born in the United States.
- Seven presidents had at least one parent who was not born on U.S. soil.

# Utah State Route 264

State Route 264 connects Sanpete County to Carbon County.
State Route 264 runs through Flat Canyon.
State Route 264 runs through Boulger Canyon.
State Route 264 runs through Upper Huntington Canyon.
State Route 264 runs through Eccles Canyon.
State Route 264 is part of The Energy Loop.
State Route 264 is a state highway.
State Route 264 is in central Utah.
The Energy Loop is a National Scenic Byway.

# Vagina and Birth Canal

- The vagina is a fibromuscular canal.
- The vagina leads from the outside of the body to the cervix of the uterus.
- The vagina is also referred to as the birth canal in the context of pregnancy.
- The vagina accommodates the male penis during sexual intercourse.
- Semen containing spermatazoa is ejaculated from the male into the vagina.
- Fertilization of the egg cell (ovum) can potentially take place in the vagina.
- La naissance d'Osiris is an one-act opera by Jean-Philippe Rameau.
- The opera was first performed on 12 October 1754 at Fontainebleau.
- The opera was performed to celebrate the birth of the future King Louis XVI.
- The libretto is by Louis de Cahusac.
- Louis de Cahusac was a frequent collaborator of Jean-Philippe Rameau.
- Cahusac styled the work a "ballet allégorique" ("allegorical ballet").
- The work is usually categorised as an "acte de ballet".
- The plot tells of Jupiter's announcement to a group of Egyptian shepherds of the birth of the god
- The Census of Quirinius was a census of Judea.
- The census was taken by Publius Sulpicius Quirinius, Roman governor of Syria.
- The census took place in 6 CE.
- The Gospel of Luke uses the census to establish the birth of Jesus.
- The Gospel of Luke places the census within the reign of Herod the Great.
- Herod the Great died 9 years earlier.
- Most scholars think the author of the gospel made an error.

# Van Buren Township, Brown County

Van Buren Township
- Van Buren Township is one of four townships in Brown County, Indiana.
- As of the 2010 census, its population was 2,008.
- It contained 941 housing units.
- The township includes the southern portion of Brown County State Park.
- Liberty Township is one of the twelve townships of Van Wert County, Ohio, United States.
- The 2000 census found 1,696 people in the township.
- 912 of those people lived in the unincorporated portions of the township.
- Culberson County-Allamoore Independent School District is a public school district.
- The district is based in Van Horn, Texas (USA).
- The district serves all of Culberson County.
- The district serves eastern portions of Hudspeth County.
- The district was created in 1995.
- The district was created by the consolidation of the Culberson County and Allamore districts.

# Varjak Paw Novel

Varjak Paw
- Varjak Paw (2003) is a novel.
- The author of Varjak Paw is S. F. Said.
- The illustrator of Varjak Paw is Dave McKean.
- The illustrations have a dark "gothic" quality.
- Varjak Paw received the 2003 Smarties Gold Award for the 6–8 years range.
- Varjak Paw has been adapted for other media.
- Varjak Paw (2003) is a novel by the British author S. F. Said.
- The illustrations in this book have a dark "gothic" quality.
- The novel received the 2003 Smarties Gold Award for the 6–8 years range, and has been adapted for other media.

# Vermont Lady Voltage Soccer

Vermont Lady Voltage
- Vermont Lady Voltage was a professional American women’s soccer team.
- The team was founded in 2005.
- The team is a member of the United Soccer Leagues W-League.
- Voltage played in the Northern Division of the Central Conference.
- They play their home games at the Collins-Perley Sports Complex.
- The Collins-Perley Sports Complex is in St. Albans, Vermont.
- St. Albans, Vermont is 27 miles north of Burlington.
- Burlington is the state's largest city.
- The team's colors are black and white, and gold and blue.
- The team was a sister organization of the Vermont Voltage team.
- The Vermont Voltage team plays in the USL Premier Development League.
- Jenny Benson was born on January 25, 1978.
- Jenny Benson was born in Fountain Valley, California.
- Jenny Benson is a retired American soccer midfielder/defender.
- Jenny Benson was a member of the United States women's national soccer team.

# Vice Admiral Christy

Harley H. Christy
- Harley Hannibal Christy was born on 18 September 1870.
- Harley Hannibal Christy died on 4 June 1950.
- Harley Hannibal Christy served in the United States Navy.
- Harley Hannibal Christy served in the Spanish–American War.
- Harley Hannibal Christy served in World War I.

# Videodrome film

Videodrome
- Videodrome is a 1983 Canadian science fiction body horror film
- It was written by David Cronenberg
- It was directed by David Cronenberg
- It stars James Woods
- It stars Sonja Smits
- It stars Deborah Harry
- It is set in Toronto during the early 1980s
- It follows the CEO of a small UHF television station
- He stumbles upon a broadcast signal featuring extreme violence and torture
- Layers of deception and mind-control conspiracy unfold
- He uncovers the signal's source
- He loses touch with reality
- He experiences increasingly bizarre and violent organic hallucinations
- Studio 60 on the Sunset Strip is a television series
- The series takes place behind the scenes of a live sketch comedy show
- The show-within-a-show is called "Studio 60 on the Sunset Strip"
- NBS (National Broadcasting System) is a fictional television network
- NBS (National Broadcasting System)'s format is similar to "Saturday Night Live"
- National Broadcasting System is owned by the TMG Corporation
- Matt Albie (Matthew Perry) is an executive producer
- Danny Tripp (Bradley Whitford) is an executive producer
- Matt is the head writer
- Danny produces the show
- The Miracle Child is a 1932 French science fiction film
- The Miracle Child is based on a play of the same name by Robert Charvay and Paul Gavault
- Blanche Montel is a widow
- Blanche Montel endeavours to find a man with whom to produce a child
- Blanche Montel wants to pretend the child was her late husband's
- Blanche Montel wants to inherit a fortune
- A few characters interrupt a Spiritualist séance
- The characters are subsequently believed to be ghosts
- Ginette Leclerc had a minor role in "The Miracle Child"
- Ginette Leclerc's role was one of her first acting roles
- Ginette Leclerc had a long and successful career
- François Leterrier was born 26 May 1929 in Margny-lès-Compiègne.
- François Leterrier is a French film director and actor.
- He was cast in Robert Bresson's film "A Man Escaped".
- He became a director.

# Viscount Exmouth (1811-1876

- Edward Pellew, 3rd Viscount Exmouth was born on 14 February 1811.
- Edward Pellew, 3rd Viscount Exmouth died on 11 February 1876.
- Edward Pellew, 3rd Viscount Exmouth was a British peer.
- Edward Pellew, 3rd Viscount Exmouth inherited the title of Viscount Exmouth from his father.
- Edward Pellew, 3rd Viscount Exmouth held the title for 42 years.
- Edward Pellew, 3rd Viscount Exmouth was the grandson of Edward Pellew, 1st Viscount Exmouth.

# Vocal Instrumentation Emulation

A cappella
- Some a cappella singers emulate instrumentation.
- Some a cappella singers reproduce instrumental sounds with their vocal cords and mouth.
- The Mills Brothers were early practitioners of emulating instrumentation.
- The Mills Brothers’ early recordings from the 1930s stated instrumentation was done vocally.
- "Twilight Zone" by 2 Unlimited was sung a cappella to the instrumentation on Tompkins Square.
- The theme song for The New Addams Family series on Fox Family Channel (now ABC Family) emulates instrumentation.
- Vocal Sampling emulates Latin rhythms a cappella.
- Undivided emulates Latin rhythms a cappella.
- The Swingle Singers emulated musical instruments to Baroque and Classical music in the 1960s.
- Bobby McFerrin is a vocal artist famous for instrumental emulation.
- Naturally Seven recreates entire songs using vocal tones for every instrument.

# Vuk Obradović Biography

- Vuk Obradović was born on April 11, 1947.
- Vuk Obradović was born in the village of Kondželj, Serbia.
- Vuk Obradović died on February 13, 2008.
- Vuk Obradović died in Belgrade.
- Vuk Obradović was a Serbian general.
- Vuk Obradović was a politician.
- Vuk Obradović was one of the leaders of the Democratic Opposition of Serbia.
- Vuk Obradović participated in the Bulldozer Revolution in October 2000.
- Boris Tadić was born on January 15, 1958.
- Boris Tadić is a Serbian politician.
- Boris Tadić served as President of Serbia from 2004 to 2012.
- Boris Tadić was elected to his first term on June 27, 2004.
- Boris Tadić was re-elected for a second term on February 3, 2008.
- Boris Tadić resigned on April 5, 2012.
- Boris Tadić served as the last Minister of Telecommunications of the Federal Republic of Yugoslavia.
- Boris Tadić served
- He is widely considered as one of the most important figures of Serbian history.
- Saint Sava is venerated by the Serbian Orthodox Church as its founder.
- Many artistic works from the Middle Ages to modern times have interpreted his career.
- He is the patron saint of Serbia, Serbs, and Serbian education.
- The Church of Saint Sava in Belgrade is dedicated to him.
- The Ottomans burnt his remains in 1594.
- The Serbs used icons of Sava as their war flags during an uprising in 1594.
- The Church of Saint Sava in Belgrade is one of the largest church buildings in the world.

# Wagner Manufacturing Company

Wagner Manufacturing Company
- The Wagner Manufacturing Company was a family-owned manufacturer.
- It was based in Sidney, Ohio, US.
- It manufactured cast iron and aluminum products.
- It made products for domestic use.
- Products for domestic use included frying pans.
- Products for domestic use included casseroles.
- Products for domestic use included kettles.
- Products for domestic use included baking trays.
- It also made metal products other than cookware.
- Wagner was active between 1891 and 1952.
- It once dominated the cookware market.
- It sold products in Europe.
- It sold products in the US.
- The purchasers of the company in 1952 continued the brand.
- Wagner products are still manufactured today.
- The original items are prized by collectors.

# Watercolor, Florida Community

WaterColor, Florida
- WaterColor is an unincorporated master-planned community.
- It is located in Seagrove Beach.
- It is located on the Northwest Gulf Coast of Florida.
- It is near Destin.
- It was planned by Cooper, Robertson & Partners.
- It was planned under the direction of The St. Joe Company.
- The St. Joe Company has owned the land since 1927.
- It is located in Walton County.
- Benson Junction is located in southwest Volusia County, Florida.
- Benson Junction is within the city limits of DeBary.
- It is the former location of the Ox Fibre Brush Company.
- It is presently an industrial location.
- It is located just west of U.S. Highway 17-92 (Charles Richard Beall Blvd.).
- It is located along Benson Junction Road.

# Week - Seven Days

Week
- A week is a time unit equal to seven days.
- A week is used for cycles of rest days in most parts of the world.
- A week is used alongside the Gregorian calendar.

# Weird Shadows Over Innsmouth (anthology)

Weird Shadows Over Innsmouth
- It is an anthology of Cthulhu Mythos stories.
- It was edited by Stephen Jones.
- It was published by Fedogan & Bremer.
- It was published in 2005.
- The edition size was 2,100 copies.
- 100 of the copies were signed.
- It contains a discarded draft of "The Shadow Over Innsmouth."
- It contains stories by other authors.
- The stories are sequels to "The Shadow Over Innsmouth."
- Eight of the stories are original to this collection.
- Other stories first appeared in "The Acolyte."
- Other stories first appeared in "The Spook."
- Other stories first appeared in anthologies.
- Insanely Twisted Shadow Planet is a shooter puzzle video game.
- It was developed by Shadow Planet Productions (Fuelcell Games/Gagne International).
- It was published by Microsoft Studios.
- It was released for Xbox 360 and Microsoft Windows.
- A self-published DRM-free version with soundtrack included was featured in the Humble Indie Bundle 13.

# WFAN-FM Radio Station

- WFAN-FM is licensed to New York City.
- WFAN-FM broadcasts on 101.9 MHz.
- WFAN-FM is also known as "Sports Radio 66 and 101.9 FM".
- WFAN-FM is also known as "The Fan".
- WFAN-FM is owned and operated by Entercom.
- WFAN-FM is simulcast with WFAN (660 AM).
- WFAN-FM's studios are located in the Hudson Square neighborhood of Manhattan.
- WFAN-FM's transmitter is located at the Empire State Building.
- WZEI (101.5 FM) is an American licensed radio station.
- WZEI's studios are located in Bow, New Hampshire.
- The station is owned by Dirk Nadon, through licensee Lakes Media, LLC.
- WZEI is licensed to serve the community of Meredith, New Hampshire.
- WZEI has coverage of central New Hampshire, particularly the Lakes Region area.
- WZEI is an affiliate of the WEEI Sports Radio Network, based in WEEI-FM in Boston.
- WKDM 1380 is a United States ethnic brokered radio station.
- WKDM is licensed to New York City.
- The station is owned by Multicultural Broadcasting.
- WKDM airs programming in Mandarin Chinese, 24 hours a day from Monday to Friday.
- WKDM broadcasts in Mexican Spanish on the weekends.
- WKDM's transmitting facility is located in Carlstadt, New Jersey.
- WRNX (100.9 FM) is an American radio station.
- WRNX is licensed to serve the community of Amherst, Massachusetts.
- The station is owned by iHeartMedia.
- The broadcast license is held by CC Licenses, LLC.
- WRGV (107.3 FM) is a radio station licensed to serve the community of Pensacola, Florida, United States.
- The station is currently owned by iHeartMedia, Inc.
- The broadcast license is held by Clear Channel Broadcasting Licenses, Inc.
- WRGV broadcasts an urban contemporary music format to the greater Pensacola, Florida, and Mobile, Alabama, area.
- Its studios are located inside the building of unrelated television station WKRG on Broadcast Drive in Mobile.
- The transmitter is near Robertsdale, Alabama.
- WHOS (800 AM) is known as "The Big Talker".
- WHOS is licensed to serve Decatur, Alabama, United States.
- WHOS is owned by iHeartMedia, Inc.
- The broadcast license for WHOS is held by Capstar TX Limited Partnership.
- WHOS is one of five stations in the Huntsville, Alabama, market owned by iHeartMedia, Inc..
- WHOS is simulcast on WBHP at 1230 AM in Huntsville.
- WHOS is simulcast on a 106.5 FM broadcast translator in Huntsville.
- WHOS is simulcast on WQRV-HD2 (HD Radio).
- WH
- WRLS-FM (92.3 FM) is a radio station licensed to serve the community of Hayward, Wisconsin, United States.
- The station's broadcast license is held by Vacationland Broadcasting, Inc.
- KPRM (870 AM) is a radio station in Park Rapids, Minnesota.
- KPRM has a hybrid classic country/conservative talk radio format.
- KPRM broadcasts the popular "Coffee Talk" morning show.
- KPRM is currently simulcasted on KDKK and KAKK.
- KPBD (89.3 FM) is a defunct American non-commercial educational radio station.
- KPBD was licensed to serve the community of Big Spring, Howard County, Texas.
- The station's broadcast license was held by Paulino Bernal Evangelism.
- The station began broadcasting in June 2005.
- The station went dark in May 2009.
- The station's broadcast license was cancelled in June 2011.
- WJYM is an American radio station licensed to broadcast from Bowling Green, Ohio.
- Its studios and transmitter are located in Lime City near Perrysburg.
- The station serves the Toledo metropolitan area.
- KOLL (106.3 FM, "La Zeta") is a radio station licensed in Lonoke, Arkansas.
- KOLL broadcasts to the Little Rock, Arkansas, area.
- KOLL airs a Regional Mexican music format.
- The station's studios are located in West Little Rock.
- The transmitter tower is located near Pettus.
- KFRU (1400 AM) is located in Columbia, Missouri.
- KFRU broadcasts with 1 kW of power.
- KFRU's programming format consists primarily of news, talk and sports.
- The station is licensed to Cumulus Media.
- WGFX is a radio station broadcasting on the FM band at 104.5 MHz.
- WGFX is licensed to the city of Gallatin, Tennessee.
- WGFX serves the Nashville market.
- WGFX is branded as 104.5 The Zone.
- WGFX broadcasts a sports talk format.
- WGFX is owned by Cumulus Media.
- WGFX operates out of studios in Nashville's Music Row district.
- WGFX's transmitter is located just north of downtown Nashville.
- WRMN (1410 AM) is an American radio station.
- The station's broadcast license is held by Elgin Community Broadcasting LLC.
- WRMN is licensed to serve the community of Elgin, Illinois.
- WNDE (1260 AM) is a Sports formatted broadcast radio station.
- WNDE is licensed to Indianapolis, Indiana.
- WNDE serves the Indianapolis metropolitan area.
- WNDE began broadcasting in 1924.
- WNDE is owned and operated by iHeartMedia.
- The WNDE broadcast license is held by Capstar TX LLC.
- CJXY-FM is a Canadian radio station.
- CJXY-FM broadcasts at 107.9 FM.
- CJXY serves the Hamilton, Ontario market.
- CJXY is licensed to Burlington.
- CJXY broadcasts an active rock format as "Y108".
- CJXY's studios are located on Main Street West in Hamilton.
- CJXY's transmitter is located atop the Niagara Escarpment near Burlington.
- KAPE is licensed to serve the community of Cape Girardeau, Missouri.
- KAPE (1550 AM) is known as "Cape Radio 1550".
- The station is owned by Withers Broadcasting.
- The broadcast license is held by Withers Broadcasting Company of Missouri, LLC.
- WHRZ-LP (104.1 FM) is also known as The Z.
- WHRZ-LP is located in Spartanburg, South Carolina.
- WHRZ-LP is a non-commercial low-power FM radio station.
- The station is licensed by the FCC to broadcast with an ERP of 47 watts (.047 kW).
- KFGY is a commercial radio station.
- KFGY is licensed to Healdsburg, California.
- KFGY broadcasts to the Santa Rosa, California area.
- KFGY's programming is also broadcast on translator K300AO at 107.9 MHz.
- K300AO is licensed to Santa Rosa.
- Couzin Ed (real name Michael Andrews, born 1968) is an American bar manager and former radio disc jockey.
- Couzin Ed resides in Philadelphia, Pennsylvania.
- In 2002 he received a Billboard/Airplay Monitor Radio Award as local air personality of the year at a mainstream rock station.

# Whiston, Merseyside

- Whiston is a large village
- Whiston is a civil parish
- Whiston is within the Metropolitan Borough of Knowsley
- Whiston is in Merseyside, England
- The population of Whiston was 13,629 in 2001
- In 2001, 6,560 males lived in Whiston
- In 2001, 7,069 females lived in Whiston
- The population of Whiston was 14,263 in 2011
- Steven Gerrard MBE was born in Whiston, England.
- Steven George Gerrard is Steven Gerrard's full name.
- Steven Gerrard's date of birth is 30 May 1980.
- Steven Gerrard is 37 years old (as of 2017).
- Steven Gerrard is 6 ft 0 in (1.83 m) tall.
- Steven Gerrard plays as a Midfielder.
- Steven Gerrard had a youth career from 1989 to 1998 at Liverpool.
- Steven Gerrard played for Liverpool from 1998 to 2015, appearing 504 times and scoring 120
- Woolhampton is a village
- Woolhampton is a civil parish
- Woolhampton is in West Berkshire, England
- Woolhampton straddles the London to Bath (A4) road
- The village is between Reading (8 miles) and Newbury (6 miles)
- The village homes are clustered
- The village homes are on the northern side of the plain of the River Kennet
- The Berkshire Downs rise through the fields and woods of the village northwards

# Windjammer Cable Company

Windjammer Cable serves 80,000 customers.
Windjammer Cable serves rural areas.
Windjammer Communications formed Windjammer Cable.
Time Warner Cable acquired systems from Adelphia.
Adelphia was bankrupt.
MAST Capital Management is a Boston private-equity concern.
Communications Construction Services (CCS) is based in Jupiter, Fla.
Windjammer Cable was formed specifically for this deal.
Windjammer Cable consists of 25 systems.
Windjammer Communications is a small cable company.